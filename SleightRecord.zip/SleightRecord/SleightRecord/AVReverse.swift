//
//  AVReverse.swift
//  Prophesy Voice
//
//  Created by Lee Lerner on 10/23/15.
//  Copyright © 2015 Lee Lerner. All rights reserved.
//

import Foundation
import AVFoundation

class AVUtilities : NSObject {
    func assetByReversingAsset(asset: AVAsset!, outputURL : NSURL!) -> AVAsset{
        //Initialize the reader
        do {
            let reader = try AVAssetReader(asset: asset)
            let audioTrack = asset.tracksWithMediaType(AVMediaTypeAudio)
            
            let recordSettings : [String : AnyObject] =
            [
                AVFormatIDKey: NSNumber(unsignedInt: kAudioFormatMPEG4AAC),
                AVEncoderAudioQualityKey : AVAudioQuality.Max.rawValue as NSNumber,
                AVEncoderBitRateKey : 320000 as NSNumber,
                AVNumberOfChannelsKey: 2 as NSNumber,
                AVSampleRateKey : 44100.0 as NSNumber
            ]
            
            let readerOutput = AVAssetReaderTrackOutput(track: audioTrack[0], outputSettings: recordSettings)
            reader.addOutput(readerOutput)
            reader.startReading()
            
            let samples : NSMutableArray = []
            var sample : CMSampleBufferRef = readerOutput.copyNextSampleBuffer()!
            
            while(reader.status != AVAssetReaderStatus.Completed){
                sample = readerOutput.copyNextSampleBuffer()!
                samples.addObject(sample)
                
            }
            
            //Initialize the Writer
            
            
            //this class is not finished
            
            
        } catch {
            print("Could not initialize")
        }
        
        
        
        
        let test :AVAsset = asset
        return test
    }
}