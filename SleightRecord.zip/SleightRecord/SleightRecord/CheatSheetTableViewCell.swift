//
//  CheatSheetTableViewCell.swift
//  Prophesy Voice
//
//  Created by Lee Lerner on 11/17/15.
//  Copyright © 2015 Lee Lerner. All rights reserved.
//

import UIKit

class CheatSheetTableViewCell: UITableViewCell {
    
    @IBOutlet weak var pinNumber : UILabel!
    @IBOutlet weak var fileName : UILabel!
    @IBOutlet weak var outName : UILabel!

    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }
    
    override func prepareForReuse() {
        self.pinNumber.text = nil
        self.fileName.text = nil
        self.outName.text = nil
    }

}
