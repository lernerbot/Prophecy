//
//  ViewController.swift
//  SleightRecord
//
//  Created by Lee Lerner on 10/20/14.
//  Copyright (c) 2014 Lee Lerner. All rights reserved.
//

import UIKit
import AVFoundation
import AudioToolbox
import CoreData


class ViewController: UIViewController, AVAudioRecorderDelegate, AVAudioPlayerDelegate, setBackgroundDelegate, ABPadLockScreenSetupViewControllerDelegate, ABPadLockScreenViewControllerDelegate, writeValueBackDelegate {
    
    @IBOutlet weak var recordPauseButton: UIButton!                 //Start/stop audio recording
    @IBOutlet weak var stopButton:UIButton!                         //Ends recording sequence
    @IBOutlet weak var settingsButton : UIButton!                   //Launches settings page segue
    @IBOutlet weak var playbackButton : UIButton!                   //Launches playback page seque
    @IBOutlet weak var launchLockScreenButton : UIButton!           //Launches fake lock screen, in use after stopButton pressed
    @IBOutlet weak var lockScreenImage : UIImageView!               //Background image
    @IBOutlet weak var slideToUnlockLabel : UILabel!                //Label for text "slide to unlock"
    @IBOutlet weak var lockTime : UILabel!                          //Time label that is presented on fake lock screen
    @IBOutlet weak var lockDate : UILabel!                          //Date label that is present on fake lock screen
    @IBOutlet weak var backButton: UIButton!                        //Used to undo last audio sequence
    @IBOutlet weak var multipleOutButton : UIButton!                //Used to launch multiple out trick, skips audio recording, goes to fake lock screen
    
    var rewind : Bool = false
    var recordingURLs : [NSURL] = []
    var recordingEndingTimes : [NSTimeInterval] = []
    var recordingTimes:[NSTimeInterval] = []
    var mySettings : SettingsTableViewController!
    var newRecording : Bool = false
    var abortTrick : Bool = false
    var doubleTapGesture : UITapGestureRecognizer!
    var swipeGesture : UISwipeGestureRecognizer!
    var fetchResultController:NSFetchedResultsController!
    var append : Bool!
    var hide : Bool = true
    var resetOrigin : CGFloat!
    var didSwipe : Bool!
    var panGesture : UIPanGestureRecognizer = UIPanGestureRecognizer()
    var swipeR : UISwipeGestureRecognizer!
    var recorder : AVAudioRecorder!
    var player : AVAudioPlayer!
    var session : AVAudioSession!
    var soundFileURL: NSURL!
    var recordSetting: NSMutableDictionary!
    var audioAsset:AVURLAsset!
    var firstColon:String!
    var secondColon:String!
    var recordingTitle:String!
    var recordingDate:String!
    var isRecording: Bool!
    var fakeRecordingName:String!
    var dayComponent: NSDateComponents!
    var theCalendar: NSCalendar!
    //var olderDate: NSDate!
    var weekDayPrefix: String!
    var myCalendar:NSCalendar!
    @IBOutlet weak var mainImageView:UIImageView!
    var tap:UITapGestureRecognizer!
    var viewAbove : UIView!
    var settingsTap : UITapGestureRecognizer!
    var outName : String!
    var outFile : String!
    var multipleOutFlag : Bool = false

    @IBOutlet weak var lockDateCenter: NSLayoutConstraint!
    @IBOutlet weak var slideTounlockCenter: NSLayoutConstraint!
    @IBOutlet weak var lockTimeCenter: NSLayoutConstraint!
    
    
    var recordSettings = [AVSampleRateKey : NSNumber(float: Float(44100.0)),
        AVFormatIDKey : NSNumber(int: Int32(kAudioFormatMPEG4AAC)),
        AVNumberOfChannelsKey : NSNumber(int: 1),
        AVEncoderAudioQualityKey : NSNumber(int: Int32(AVAudioQuality.Medium.rawValue))]
    
    var memo:Memo!
    var path:String!
    var fullpath:String!
    
    var memos:[Memo] = []
    
    private(set) var thePin: String?
    var blurEffectView : UIVisualEffectView!
    
    

    override func viewDidLoad() {
        super.viewDidLoad()

        let fontName = UIFont.systemFontOfSize(14).fontName
        print("Font name is \(fontName)")

        //stopButton.enabled = false
        //playButton.enabled = false
        
        //Setup gesture recognizer
        //self.tap = UITapGestureRecognizer(target: self, action: "doubleTap:")
        //self.tap.numberOfTouchesRequired = 2
        //self.recordPauseButton.addGestureRecognizer(self.tap)
        //self.view.addGestureRecognizer(self.tap)
        
        
        //Hide navigation bar
        self.navigationController?.setNavigationBarHidden(true , animated: false)
        
        //Hide buttons
        self.recordPauseButton.enabled = false
        self.recordPauseButton.hidden = false
        self.recordPauseButton.setTitle("Begin Recording", forState: .Normal)
        self.recordPauseButton.titleLabel?.textAlignment = NSTextAlignment.Center
        self.stopButton.hidden = false                                                // A/B Test
        self.stopButton.setTitle("Finish", forState: UIControlState.Normal)
        //self.backButton.hidden = false
        self.backButton.setTitle("Back", forState: .Normal)
        self.launchLockScreenButton.hidden = true
        self.lockScreenImage.hidden = true
        self.slideToUnlockLabel.hidden = true
        self.lockDate.hidden = true
        self.lockTime.hidden = true
        self.resetOrigin = self.lockTimeCenter.constant
        
        //Put borders on settings and playback
        self.playbackButton.layer.borderColor = UIColor.whiteColor().CGColor
        self.playbackButton.layer.borderWidth = 1.0
        self.playbackButton.setTitle("Playback", forState: UIControlState.Normal)
        self.settingsButton.layer.borderColor = UIColor.whiteColor().CGColor
        self.settingsButton.layer.borderWidth = 1.0
        self.settingsButton.setTitle("Settings", forState: UIControlState.Normal)
        self.stopButton.layer.borderColor = UIColor.whiteColor().CGColor
        self.stopButton.layer.borderWidth = 1.0
        self.stopButton.hidden = true
        self.backButton.layer.borderColor = UIColor.whiteColor().CGColor
        self.backButton.layer.borderWidth = 1.0
        self.backButton.hidden = true
        self.multipleOutButton.layer.borderColor = UIColor.whiteColor().CGColor
        self.multipleOutButton.layer.borderWidth = 1.0
        
        
        //for appending purposes
        self.append = false
        
        self.isRecording = false
        self.didSwipe = false
        
        
        
        
        //Set initial background
        if let defaults = NSUserDefaults(suiteName: "group.prophesy"){
            
            //initialize cheat sheet to first value
            defaults.setInteger(0, forKey: "multipleOutChoice")
            defaults.synchronize()
            
            
            //eliminate simple mode
            defaults.setBool(true, forKey: "subtleMode")
            
            defaults.setBool(false, forKey: "appendState")
            defaults.setInteger(0, forKey: "appendCount")
            defaults.synchronize()
            
            let useBackground = defaults.boolForKey("useBackgroundImage")
            if useBackground == true {
                print("use image for background")
                
                let fetchRequest = NSFetchRequest(entityName: "Images")
                //fetchRequest.predicate = NSPredicate(format: "name contains[c] %@", originalRecordingName)
                let sortDescriptor = NSSortDescriptor(key: "backgroundImage", ascending: true)
                fetchRequest.sortDescriptors = [sortDescriptor]
                
                if let managedObjectContext = (UIApplication.sharedApplication().delegate as! AppDelegate).managedObjectContext {
                    fetchResultController = NSFetchedResultsController(fetchRequest: fetchRequest, managedObjectContext: managedObjectContext, sectionNameKeyPath: nil, cacheName: nil)
                    
                    do {
                        try fetchResultController.performFetch()
                        let returnedItems = fetchResultController.fetchedObjects as! [Images]
                        print("Number of total Images: \(returnedItems.count)")
                        
                        if returnedItems.count == 0 {
                            print("Warning: Unable to retrieve from memory")
                        } else {
                            
                            let backgroundImage = UIImage(data: returnedItems[0].backgroundImage)
                            mainImageView.image = backgroundImage
                            self.recordPauseButton.enabled = true

                        }
                        
                    } catch  {
                        print("Failed to retrieve anything from core data")
                        return
                    }
                }
                
            } else {
                //Background image not set, do not let trick start
                self.recordPauseButton.enabled = false
                self.recordPauseButton.titleLabel?.lineBreakMode = NSLineBreakMode.ByWordWrapping
                self.recordPauseButton.titleLabel?.textAlignment = NSTextAlignment.Center
                self.recordPauseButton.setTitle("To start performing, go to settings, read the instructions and add a background photo", forState: .Normal)
                self.recordPauseButton.titleLabel?.font = UIFont(name: "HelveticaNeue-Bold", size: 24)
                
                //self.settingsTap = UITapGestureRecognizer(target: self, action: "launchSettings")
                //self.viewAbove = UIView(frame: CGRectMake(0, 0, self.view.bounds.width, self.view.bounds.height))
                //self.viewAbove.addGestureRecognizer(self.settingsTap)
                //self.view.addSubview(self.viewAbove)
                
                
            }
            
        }
        

        //Setup File Name
        let date = NSDate()
        let formatter = NSDateFormatter()
        formatter.dateFormat = "yyyy-MM-dd_hh_mm_ss"
        recordingDate = formatter.stringFromDate(date)
        
        path = NSSearchPathForDirectoriesInDomains(.DocumentDirectory, .UserDomainMask, true)[0] as NSString as String
        recordingTitle = "recording_" + recordingDate + ".m4a"
        fullpath = path + "/" + recordingTitle
        
        print("String is \(path)")
        
    }
    
    override func viewWillAppear(animated: Bool) {
        print("View will appear")
        // Have to hide navigation bar after going to memo list
        super.viewWillAppear(animated)
        
        if (!multipleOutFlag){
            self.multipleOutButton.hidden = !self.checkMultipleOutCount()
        }
        
        
        if let defaults = NSUserDefaults(suiteName: "group.prophesy"){
            let useBackground = defaults.boolForKey("useBackgroundImage")
            print("use background is \(useBackground)")
            if useBackground == false {
                self.settingsTap = UITapGestureRecognizer(target: self, action: "launchSettings")
                self.viewAbove = UIView(frame: CGRectMake(0, 0, self.view.bounds.width, self.view.bounds.height))
                self.viewAbove.addGestureRecognizer(self.settingsTap)
                self.view.addSubview(self.viewAbove)
            }
        }
        
        self.newRecording = true
        
        /*self.stopButton.alpha = 1.0
        self.stopButton.titleLabel?.font = UIFont(name: "Helvetica Neue Bold", size: 24)
        self.recordPauseButton.alpha = 1.0
        self.recordPauseButton.titleLabel?.font = UIFont(name: "Helvetica Neue Bold", size: 24)*/
        
        //Set initial bavkground
        
        
        self.navigationController?.setNavigationBarHidden(true , animated: false )
        
        // If we aren't recording, let's get ready to record again
        if isRecording == false {
            //Setup File Name
            let date = NSDate()
            let formatter = NSDateFormatter()
            formatter.dateFormat = "yyyy-MM-dd_hh_mm_ss"
            recordingDate = formatter.stringFromDate(date)
            
            path = NSSearchPathForDirectoriesInDomains(.DocumentDirectory, .UserDomainMask, true)[0] as NSString as String
            recordingTitle = "recording_" + recordingDate + ".m4a"
            fullpath = path + "/" + recordingTitle
            
            print("String is \(path)")
            
            // Setup Audio Session
            soundFileURL = NSURL(fileURLWithPath: fullpath)
            session = AVAudioSession.sharedInstance()
            do {
                //try session.setCategory("AVAudioSessionCategoryPlayAndRecord")
                try session.setCategory("AVAudioSessionCategoryPlayAndRecord", withOptions: AVAudioSessionCategoryOptions.AllowBluetooth)
                if let inputs = session.availableInputs {
                    //print("Available inputs: \(inputs[0])")
                    //print("Available inputs: \(inputs)")
                    
                    for index in inputs {
                        let device = index.portType
                        print("input: \(device)")
                        if device == "BluetoothHFP"{
                            print("bluetooth found")
                            try session.setPreferredInput(index)
                        }
                        
                    }
                }
                
                //try session.setPreferredInput(inputs![1])
                recorder = try AVAudioRecorder(URL: soundFileURL, settings: recordSettings)
                recorder.delegate = self
                recorder.meteringEnabled = true
                recorder.prepareToRecord() // creates/overwrites the file at soundFileURL
                self.recordingTimes.append(self.recorder.currentTime)
                print("Ready to record!")
                
                //start of bluetooth test section
                //let allowBluetoothInput : UInt32 = 1
                //let stat : OSStatus = session.inputAvailable
                //end of bluetooth test section
                
            } catch _ {
                print("Session failed to setup")
                recorder = nil
            }
            
            
            /*do {
                try session.setCategory("AVAudioSessionCategoryPlayAndRecord")
            } catch _ {
            }
            
            
            var error: NSError?
            do {
                recorder = try AVAudioRecorder(URL: soundFileURL, settings: recordSettings)
            } catch var error1 as NSError {
                error = error1
                recorder = nil
            }
            if let e = error {
                print(e.localizedDescription)
            } else {
                recorder.delegate = self
                recorder.meteringEnabled = true
                recorder.prepareToRecord() // creates/overwrites the file at soundFileURL
                isRecording = true
                print("Ready to record!")
            }*/
        }
        

    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    override func prefersStatusBarHidden() -> Bool {
        print("func prefersStatusBarHidden")
        if self.hide == true {
            return true
        } else {
            return false
        }
        
    }
    
    @IBAction func recordPauseTapped(recordButton: UIButton!){
        print("func recordPauseTapped")
        self.multipleOutFlag = false
        self.recordPauseButton.alpha = 1.0
        self.stopButton.alpha = 1.0
        self.backButton.alpha = 1.0
        //self.recordPauseButton.setTitle("Recording", forState: .Normal)
        if recorder.recording == false {
            
            //start the recording
            self.isRecording = true
            print("1: \(self.recorder.currentTime)")
            self.recorder.record()
            print("2: \(self.recorder.currentTime)")
            
            if self.newRecording == true {
                //set up double tap gesture to reset trick
                //self.doubleTapGesture = UITapGestureRecognizer(target: self, action: "resetTrick")
                
                //self.doubleTapGesture.numberOfTapsRequired = 2
                self.swipeGesture = UISwipeGestureRecognizer(target: self, action: "resetTrick")
                //self.swipeGesture = UISwipeGestureRecognizer(target: self, action: "goBack")
                self.swipeGesture.numberOfTouchesRequired = 2
                self.swipeGesture.direction = UISwipeGestureRecognizerDirection.Left
                self.view.addGestureRecognizer(self.swipeGesture)
                //self.view.addGestureRecognizer(doubleTapGesture)
                print("Gesture added")
                self.newRecording = false
            }
            
            //set the screen
            self.recordPauseButton.setTitle("Recording", forState: .Normal)
            self.recordPauseButton.alpha = 1.0
            self.stopButton.alpha = 1.0
            self.backButton.alpha = 1.0
            
            self.multipleOutButton.hidden = true
            self.settingsButton.hidden = true
            self.playbackButton.hidden = true
            self.stopButton.hidden = false
            self.stopButton.enabled = true
            //self.backButton.hidden = false
            //self.backButton.enabled = false
            
            if let defaults = NSUserDefaults(suiteName: "group.prophesy"){
                let subtleMode = defaults.boolForKey("subtleMode")
                if subtleMode == true {
                    print("Subtle Mode Active")
                    self.mainImageView.hidden = true
                    self.recordPauseButton.titleLabel?.font = UIFont(name: "HelveticaNeue-Bold", size: 10)
                    
                    self.stopButton.titleLabel?.font = UIFont(name: "HelveticaNeue-Bold", size: 10)
                    self.stopButton.layer.borderWidth = 0.0
                    
                    self.backButton.titleLabel?.font = UIFont(name: "HelveticaNeue-Bold", size: 10)
                    self.backButton.layer.borderWidth = 0.0
                    //self.recordPauseButton.titleLabel?.textAlignment = .Top
                }
            }
        }
        
        //
        //playButton.enabled = false
        print("End of recordPauseTapped")
        
    }

    @IBAction func pauseRecording ( recordButton: UIButton!){
        print("func pauseRecording")
        recorder.pause()
        print("3: \(self.recorder.currentTime)")
        self.recordingTimes.append(self.recorder.currentTime)
        print("4: \(self.recordingTimes)")
        recordPauseButton.setTitle("Hold to Resume", forState: .Normal)
        recordPauseButton.titleLabel?.lineBreakMode = NSLineBreakMode.ByWordWrapping
        recordPauseButton.titleLabel?.numberOfLines = 0
        
        UIView.animateWithDuration(0.3, delay: 1.0,  options: UIViewAnimationOptions.AllowUserInteraction, animations: {
            print("fade out button text")
            self.recordPauseButton.alpha = 0.05
            self.stopButton.alpha = 0.05
            self.backButton.alpha = 0.05
            
            
            }, completion: { finished in
                
                print("animation completed")
                
        })
        
        
        
    }
    
    @IBAction func startMultipleOut(){
        print("Func startMultipleOut")
        
        self.multipleOutFlag = true
        self.multipleOutButton.hidden = true
        self.recordPauseButton.hidden = true
        self.mainImageView.hidden = true
        self.settingsButton.hidden = true
        self.settingsButton.layer.borderWidth = 0.0
        self.playbackButton.hidden = true
        self.recordPauseButton.alpha = 1.0
        self.playbackButton.setTitle("", forState: UIControlState.Normal)
        self.playbackButton.layer.borderWidth = 0.0
        self.stopButton.hidden = true
        self.backButton.hidden = true
        
        if let defaults = NSUserDefaults(suiteName: "group.prophesy"){
            let subtleMode = defaults.boolForKey("subtleMode")
            if subtleMode == true {
                self.launchLockScreenButton.hidden = false
                
            } else {
                self.playbackButton.hidden = false
            }
            
        }
        
        let storyboard = UIStoryboard(name: "Main", bundle: nil)
        let multipleOutListVC = storyboard.instantiateViewControllerWithIdentifier("multipleOutList") as! MultipleOutViewController
        multipleOutListVC.delegate = self
        let navigationController = UINavigationController(rootViewController: multipleOutListVC)
        self.presentViewController(navigationController, animated: true, completion: nil)
    }
    
    @IBAction func stopTapped(){
        print("func stopTapped")
        //Handle how the screen looks
        //self.view.removeGestureRecognizer(self.doubleTapGesture)
        self.view.removeGestureRecognizer(self.swipeGesture)
        
        
        
        //self.settingsButton.hidden = false
        self.settingsButton.layer.borderWidth = 0.0
        self.playbackButton.hidden = true
        self.recordPauseButton.alpha = 1.0
        self.playbackButton.setTitle("", forState: UIControlState.Normal)
        self.playbackButton.layer.borderWidth = 0.0
        self.stopButton.hidden = true
        self.backButton.hidden = true
        
        if let defaults = NSUserDefaults(suiteName: "group.prophesy"){
            let subtleMode = defaults.boolForKey("subtleMode")
            if subtleMode == true {
                self.launchLockScreenButton.hidden = false
                
            } else {
                self.playbackButton.hidden = false
            }
            
        }
        
        print("Recording Finished")
        recorder.stop()
        /*session = AVAudioSession.sharedInstance()
        do {
            try session.setActive(false)
        } catch  {
        }*/
        isRecording = false
        
        if self.rewind == true {
            
            //save recorder URL
            self.recordingURLs.append(self.recorder.url)
            
            //save end time
            self.recordingEndingTimes.append(self.recordingTimes[self.recordingTimes.count - 1])
            
            appendAll()
            self.rewind = false
            AudioServicesPlaySystemSound(1352)
            return
            
        }
        
        
        //If this is a new recording save to core data. If this is an appended file create new file with new recording appended to end of old
        if self.append == true {
            print("Append if true")
            //time to append
            
            
            
            //Get original file URL from defaults
            if let defaults = NSUserDefaults(suiteName: "group.prophesy"){
                let originalRecordingPath = defaults.objectForKey("fileToAppend") as! String
                print("Original path is \(originalRecordingPath)")
                let originalRecordingName = defaults.objectForKey("nameToAppend") as! String
                print("Original name is \(originalRecordingName)")
                let fullOriginalPath = self.path + "/" + originalRecordingPath
                
                
                //Check if file exists and it is safe to proceed
                let filemgr = NSFileManager.defaultManager()
                
                if filemgr.fileExistsAtPath(fullOriginalPath) {
                    print("File exists")
                    let originalRecordingURL = NSURL(fileURLWithPath: fullOriginalPath)
                    
                    // Grab the two audio tracks that need to be appended
                    
                    let originalRecording = AVURLAsset(URL: originalRecordingURL, options: nil)
                    let newRecording = AVURLAsset(URL: recorder.url, options: nil)
                    
                    
                    
                    // Grab the first audio track and insert it into our appendedAudioTrack
                    let tracks = originalRecording.tracksWithMediaType(AVMediaTypeAudio)
                    let originalTrack : AVAssetTrack = tracks[0] 
                    let timeRange = CMTimeRangeMake(kCMTimeZero, originalRecording.duration)
                    // Create a new audio track we can append to
                    let composition = AVMutableComposition()
                    let appendedAudioTrack : AVMutableCompositionTrack = composition.addMutableTrackWithMediaType(AVMediaTypeAudio, preferredTrackID: CMPersistentTrackID())
                    do {
                        try appendedAudioTrack.insertTimeRange(timeRange, ofTrack: originalTrack, atTime: kCMTimeZero)
                    } catch _ {
                        print("Couldnt append audio track")
                    }
                    
                    
                    
                    // Grab the second audio track and insert it at the end of the first one
                    let tracks2 = newRecording.tracksWithMediaType(AVMediaTypeAudio)
                    let newTrack : AVAssetTrack = tracks2[0] 
                    let timeRange2 = CMTimeRangeMake(kCMTimeZero, newRecording.duration)
                    do {
                        try appendedAudioTrack.insertTimeRange(timeRange2, ofTrack: newTrack, atTime: originalRecording.duration)
                    } catch _ {
                        print("Couldnt append audio track")
                    }
                    
                    
                    
                    // Create a new audio file using the appendedAudioTrack
                    var appendedAudioPath : String!
                    if let exportSession = AVAssetExportSession(asset: composition, presetName: AVAssetExportPresetAppleM4A) {
                        print("export session created")
                        let newFileName = "audio_\(NSDate.timeIntervalSinceReferenceDate()).m4a"
                        appendedAudioPath = self.path + "/" + newFileName
                        print("export path is \(appendedAudioPath)")
                        exportSession.outputURL = NSURL(fileURLWithPath: appendedAudioPath)
                        exportSession.outputFileType = AVFileTypeAppleM4A
                        exportSession.exportAsynchronouslyWithCompletionHandler({ finished in
                            
                            //export successful?
                            switch (exportSession.status){
                            case AVAssetExportSessionStatus.Failed:
                                print("Export failed \(exportSession.error)")
                                break
                            case AVAssetExportSessionStatus.Completed:
                                print("export successful")
                                //let documentsURL = filemgr.URLsForDirectory(.DocumentDirectory, inDomains: .UserDomainMask)[0] as! NSURL
                                //let directoryURLs = filemgr.contentsOfDirectoryAtURL(documentsURL, includingPropertiesForKeys: nil, options: NSDirectoryEnumerationOptions.SkipsSubdirectoryDescendants, error: nil)
                                //println("Documents: \(directoryURLs)")
                                break
                            case AVAssetExportSessionStatus.Waiting:
                                print("Still waiting \(exportSession.error)")
                                break
                            default:
                                print("default")
                                break
                            }
                            
                        })
                        
                        
                        
                        
                        //Now that we have the new file, lets replace the audio file location in the core data location and update the date
                        let originalRecordingName = defaults.objectForKey("nameToAppend") as! String
                        //let fetchedObjects = []
                        let fetchRequest = NSFetchRequest(entityName: "Memo")
                        fetchRequest.predicate = NSPredicate(format: "name contains[c] %@", originalRecordingName)
                        let sortDescriptor = NSSortDescriptor(key: "name", ascending: true)
                        fetchRequest.sortDescriptors = [sortDescriptor]
                        
                        if let managedObjectContext = (UIApplication.sharedApplication().delegate as! AppDelegate).managedObjectContext {
                            fetchResultController = NSFetchedResultsController(fetchRequest: fetchRequest, managedObjectContext: managedObjectContext, sectionNameKeyPath: nil, cacheName: nil)
                            //fetchResultController.delegate = self
                            
                            //let e: NSError?
                            var result: Bool
                            do {
                                try fetchResultController.performFetch()
                                result = true
                            } catch  {
                                print("Couldn't perform fetch")
                                result = false
                            }
                            memos = fetchResultController.fetchedObjects as! [Memo]
                            print("Number of total Memos: \(memos.count)")
                            if memos.count == 0 {
                                print("Warning: Unable to retrieve from memory")
                            } else {
                                //Set new file name
                                memos[0].file = newFileName
                            
                                let totalTime = CMTimeGetSeconds(composition.duration)
                                let dHours = floor(totalTime / 3600) as NSNumber
                                let dMinutes = floor(totalTime % 3600 / 60) as NSNumber
                                let dSeconds = floor(totalTime % 3600 % 60) as NSNumber
                                
                                if (Int(dMinutes) < 10) {
                                    firstColon = ":0"
                                } else {
                                    firstColon = ":"
                                }
                                
                                if (Int(dSeconds) < 10) {
                                    secondColon = ":0"
                                } else {
                                    secondColon = ":"
                                }
                                
                                memos[0].duration = dHours.stringValue + firstColon + dMinutes.stringValue + secondColon + dSeconds.stringValue
                                memos[0].durationValue = totalTime
                                
                                //Update Date
                                let dayChosen = defaults.integerForKey("recordingPrefix")
                                let date = NSDate()
                                let components = NSDateComponents()
                                components.setValue(-dayChosen, forComponent: NSCalendarUnit.Day)
                                let olderDate = NSCalendar.currentCalendar().dateByAddingComponents(components, toDate: date, options: NSCalendarOptions(rawValue: 0))
                                let formatter = NSDateFormatter()
                                formatter.dateStyle = .ShortStyle
                                memos[0].date = formatter.stringFromDate(olderDate!)
                                
                                
                                
                                
                                if result != true {
                                    print("Couldn't save")
                                    //print(e?.localizedDescription)
                                }
                                
                                do {
                                    try managedObjectContext.save()
                                } catch {
                                    fatalError("Failure to save context: \(error)")
                                }

                                defaults.setBool(true, forKey: "appendState")
                                defaults.synchronize()
                            }
                        }
                        
                    }
                    
                    
                } else {
                    print("File not found")
                }
                
            }
            
            self.append = false
            
            
            
            
        } else {
            // New recording, we will insert New Recording into table
            self.saveFile(self.recorder.url, savePath: self.fullpath, saveTitle: self.recordingTitle, multipleOut: false)
            
        }
        
        
        AudioServicesPlaySystemSound(1352)
        
        
        
    }
    
    func saveFile(recorderURL : NSURL!, savePath : String!, saveTitle : String!, multipleOut : Bool!){
        print("Func saveFile")
        print("Recorder URL is \(recorderURL)")
        print("Save Path is \(savePath)")
        print("Save Title is \(saveTitle)")
        if let managedObjectContext = (UIApplication.sharedApplication().delegate as! AppDelegate).managedObjectContext {
            
            //create new
            memo = NSEntityDescription.insertNewObjectForEntityForName("Memo", inManagedObjectContext: managedObjectContext) as! Memo
            
            //set the date of the recording to a value in the past determined in the settings
            var dayChosen : Int!
            if let defaults = NSUserDefaults(suiteName: "group.prophesy"){
                dayChosen = defaults.integerForKey("recordingPrefix")
            
                
            } else {
                dayChosen = 2
            }
            let date = NSDate()
            
            let components = NSDateComponents()
            components.setValue(-dayChosen, forComponent: NSCalendarUnit.Day)
            let olderDate = NSCalendar.currentCalendar().dateByAddingComponents(components, toDate: date, options: NSCalendarOptions(rawValue: 0))
            myCalendar = NSCalendar(calendarIdentifier: NSCalendarIdentifierGregorian)
            let myComponents = myCalendar.components(NSCalendarUnit.Weekday, fromDate: olderDate!)
            
            
            let weekDay = myComponents.weekday
            
            switch weekDay {
            case 1:  weekDayPrefix = "Sunday"
            case 2:  weekDayPrefix = "Monday"
            case 3:  weekDayPrefix = "Tuesday"
            case 4:  weekDayPrefix = "Wednesday"
            case 5:  weekDayPrefix = "Thursday"
            case 6:  weekDayPrefix = "Friday"
            case 7:  weekDayPrefix = "Saturday"
                
            default: break
                
            }
            
            //Create name based on predefined value in settings
            var recordingSuffix : String!
            if let defaults = NSUserDefaults(suiteName: "group.prophesy"){
                if let tempSuffix = defaults.objectForKey("recordingSuffix") as? String! {
                    if tempSuffix == nil {
                        recordingSuffix = "Prophecy"
                    } else {
                        recordingSuffix = tempSuffix
                    }
                }
                
                
            }
            
            
            if multipleOut == true {
                memo.name = self.outName
            } else {
                fakeRecordingName = weekDayPrefix + " " + recordingSuffix
                memo.name = fakeRecordingName
                
            }
            
            
            let formatter = NSDateFormatter()
            formatter.dateStyle = .ShortStyle
            memo.date = formatter.stringFromDate(olderDate!)
            
            memo.dateOrder = olderDate
            print("date order is \(memo.dateOrder)")
            //memo.duration = "0:00:01"
            audioAsset = AVURLAsset(URL: recorderURL, options: nil)
            let durationCM = audioAsset.duration
            let dTotalSeconds = CMTimeGetSeconds(durationCM)
            let dHours = floor(dTotalSeconds / 3600) as NSNumber
            let dMinutes = floor(dTotalSeconds % 3600 / 60) as NSNumber
            let dSeconds = floor(dTotalSeconds % 3600 % 60) as NSNumber
            
            if (Int(dMinutes) < 10) {
                firstColon = ":0"
            } else {
                firstColon = ":"
            }
            
            if (Int(dSeconds) < 10) {
                secondColon = ":0"
            } else {
                secondColon = ":"
            }
            
            memo.duration = dHours.stringValue + firstColon + dMinutes.stringValue + secondColon + dSeconds.stringValue
            memo.durationValue = dTotalSeconds
            memo.path = savePath
            memo.file = saveTitle
            //let fullFilePath = path + "/" + fakeRecordingName + ".m4a"
            //memo.file = fullFilePath
            memo.sliderValue = 0.0
            
            /*var e: NSError?
            if managedObjectContext.save() != true {
            print("insert error: \(e!.localizedDescription)")
            }*/
            
            do {
                try managedObjectContext.save()
            } catch {
                fatalError("Failure to save context: \(error)")
            }
            
            
        }
    }
    
    func appendAll(){
        print("Func appendAll")
        print("Recording URLs: \(self.recordingURLs)")
        print("Recording End Times: \(self.recordingEndingTimes)")
        
        let composition = AVMutableComposition()
        var appendedAudioTrack : AVMutableCompositionTrack!
        var atTimeValue : CMTime = kCMTimeZero
        
        for var i = 0; i < self.recordingURLs.count; i++ {
            let recordingAsset = AVURLAsset(URL: self.recordingURLs[i])
            let tracks = recordingAsset.tracksWithMediaType(AVMediaTypeAudio)
            let trackZero : AVAssetTrack = tracks[0]
            let cmEndTime = CMTimeMakeWithSeconds(self.recordingEndingTimes[i], 44100)
            let timeRange = CMTimeRangeMake(kCMTimeZero, cmEndTime)
    
            
            appendedAudioTrack = composition.addMutableTrackWithMediaType(AVMediaTypeAudio, preferredTrackID: CMPersistentTrackID())
            do {
                print("Appending: \(self.recordingURLs[i])")
                try appendedAudioTrack.insertTimeRange(timeRange, ofTrack: trackZero, atTime: atTimeValue)
            } catch _ {
                print("Couldnt append audio track")
            }
            
            atTimeValue = CMTimeAdd(atTimeValue, cmEndTime)
            print("Next time clip starts at: \(atTimeValue)")
        }
        
        // Create a new audio file using the appendedAudioTrack
        var appendedAudioPath : String!
        if let exportSession = AVAssetExportSession(asset: composition, presetName: AVAssetExportPresetAppleM4A) {
            print("export session created")
            let newFileName = "audio_\(NSDate.timeIntervalSinceReferenceDate()).m4a"
            appendedAudioPath = self.path + "/" + newFileName
            print("export path is \(appendedAudioPath)")
            exportSession.outputURL = NSURL(fileURLWithPath: appendedAudioPath)
            exportSession.outputFileType = AVFileTypeAppleM4A
            exportSession.exportAsynchronouslyWithCompletionHandler({ finished in
                
                //export successful?
                switch (exportSession.status){
                case AVAssetExportSessionStatus.Failed:
                    print("Export failed \(exportSession.error)")
                    break
                case AVAssetExportSessionStatus.Completed:
                    print("export successful")
                    //let documentsURL = filemgr.URLsForDirectory(.DocumentDirectory, inDomains: .UserDomainMask)[0] as! NSURL
                    //let directoryURLs = filemgr.contentsOfDirectoryAtURL(documentsURL, includingPropertiesForKeys: nil, options: NSDirectoryEnumerationOptions.SkipsSubdirectoryDescendants, error: nil)
                    //println("Documents: \(directoryURLs)")
                    self.saveFile(exportSession.outputURL, savePath: appendedAudioPath, saveTitle: newFileName, multipleOut: false)
                    break
                case AVAssetExportSessionStatus.Waiting:
                    print("Still waiting \(exportSession.error)")
                    break
                default:
                    print("default")
                    break
                }
                
            })
        }
        
        
        
    }
    
    @IBAction func launchLockScreen(){
        print("func launchLockScreen")
        
        self.hide = false
        self.prefersStatusBarHidden()
        
        
        self.launchLockScreenButton.hidden = true
    
        
        if let defaults = NSUserDefaults(suiteName: "group.prophesy"){
            
            let subtleMode = defaults.boolForKey("subtleMode")
            if subtleMode == true {
                
                //self.lockScreenImage.hidden = false
                let useLockImage = defaults.boolForKey("useLockImage")
                if useLockImage == true {
                    print("use image for lock screen")
                    
                    let fetchRequest = NSFetchRequest(entityName: "Images")
                    //fetchRequest.predicate = NSPredicate(format: "name contains[c] %@", originalRecordingName)
                    let sortDescriptor = NSSortDescriptor(key: "backgroundImage", ascending: true)
                    fetchRequest.sortDescriptors = [sortDescriptor]
                    
                    if let managedObjectContext = (UIApplication.sharedApplication().delegate as! AppDelegate).managedObjectContext {
                        fetchResultController = NSFetchedResultsController(fetchRequest: fetchRequest, managedObjectContext: managedObjectContext, sectionNameKeyPath: nil, cacheName: nil)
                        
                        do {
                            try fetchResultController.performFetch()
                            let returnedItems = fetchResultController.fetchedObjects as! [Images]
                            print("Number of total Images: \(returnedItems.count)")
                            
                            if returnedItems.count == 0 {
                                print("Warning: Unable to retrieve from memory")
                            } else {
                                
                                let backgroundImage = UIImage(data: returnedItems[0].lockScreenImage)
                                mainImageView.image = backgroundImage
                                
                                
                                //begin test of ABlockscreen
                                //ABPadLockScreenView.appearance().backgroundImage = backgroundImage
                                ABPadLockScreenView.appearance().backgroundColor = UIColor.clearColor()
                                ABPadLockScreenView.appearance().labelColor = UIColor.whiteColor()
                                
                                //let buttonLineColor = UIColor(red: 229/255, green: 180/255, blue: 46/255, alpha: 1)
                                let buttonLineColor = UIColor.whiteColor()
                                ABPadButton.appearance().backgroundColor = UIColor.clearColor()
                                ABPadButton.appearance().borderColor = buttonLineColor
                                ABPadButton.appearance().selectedColor = buttonLineColor
                                ABPinSelectionView.appearance().selectedColor = buttonLineColor
                                
                                
                                
                                //end test of ABlockscreen
                                
                            }
                            
                        } catch  {
                            print("Failed to retrieve anything from core data")
                            return
                        }
                    }
                    
                    //let imagePath2 = defaults.objectForKey("lockImage") as! String
                    //print("Lock Image is \(imagePath2)")
                    //let lockscreenImage = UIImage(contentsOfFile: imagePath2)
                    //self.lockScreenImage.image = lockscreenImage
                    //self.mainImageView.image = lockscreenImage
                    self.mainImageView.hidden = false
                    
                }
                
                
                self.slideToUnlockLabel.hidden = false
                self.lockTime.hidden = false
                self.lockDate.hidden = false
                self.swipeR = UISwipeGestureRecognizer(target: self, action: "unlockScreen")
                swipeR.direction = UISwipeGestureRecognizerDirection.Right
                //self.view.addGestureRecognizer(swipeR)
                
                //Add time
                let date = NSDate()
                let calendar = NSCalendar.currentCalendar()
                let flags: NSCalendarUnit = [.Day, .Month, .Year, .Hour, .Minute]
                let components = calendar.components(flags, fromDate: date)
                let hour = components.hour
                let minutes = components.minute
                var minutesText : String!
                
                var hourText : String!
                if hour > 12 {
                    let shortHour = hour % 12
                    hourText = String(shortHour)
                } else {
                    hourText = String(hour)
                }
                
                
                if minutes < 10 {
                   minutesText = "0" + String(minutes)
                } else {
                    minutesText = String(minutes)
                }
                let printText = hourText + ":" + minutesText
                print("PrintText is \(printText)")
                self.lockTime.text = hourText + ":" + minutesText
                
                print("String should be \(self.lockTime.text)")
                
                //Add Date
                let newCalendar = NSCalendar(calendarIdentifier: NSCalendarIdentifierGregorian)
                let dateComponents = newCalendar!.components(NSCalendarUnit.Weekday, fromDate: date)
                let weekDay = dateComponents.weekday
                let day = components.day
                let month = components.month
                var weekdayPrefix :String!
                switch weekDay {
                case 1:  weekdayPrefix = "Sunday"
                case 2:  weekdayPrefix = "Monday"
                case 3:  weekdayPrefix = "Tuesday"
                case 4:  weekdayPrefix = "Wednesday"
                case 5:  weekdayPrefix = "Thursday"
                case 6:  weekdayPrefix = "Friday"
                case 7:  weekdayPrefix = "Saturday"
                    
                default: break
                    
                }
                print("Month is \(month)")
                
                var monthText : String!
                switch month {
                case 1:  monthText = "January "
                case 2:  monthText = "February "
                case 3:  monthText = "March "
                case 4:  monthText = "April "
                case 5:  monthText = "May "
                case 6:  monthText = "June "
                case 7:  monthText = "July "
                case 8:  monthText = "August "
                case 9:  monthText = "September "
                case 10:  monthText = "October "
                case 11:  monthText = "November "
                case 12:  monthText = "December "
                    
                default: break
                    
                }
                
                self.lockDate.text = weekdayPrefix + ", " + monthText + String(day)
                print("String should be \(self.lockDate.text)")
                
                
                //Animate the slide to unlock label
                let gradientMask = CAGradientLayer(layer: self.view.layer)
                gradientMask.frame = self.view.bounds
                let gradientWidth = 100.0
                let gradientSize = CGFloat(gradientWidth) / view.frame.size.width
                let gradient = UIColor(white: 1.0, alpha: 0.1)
                //let superview = view.superview
                let startLocations = [0.0, gradientSize/2, gradientSize]
                let endLocations = [1.0 - gradientSize, 1.0 - (gradientSize/2), 1.0]
                let animation = CABasicAnimation(keyPath: "locations")
                
                gradientMask.colors = [gradient.CGColor, UIColor.blackColor().CGColor, gradient.CGColor]
                gradientMask.locations = startLocations
                gradientMask.startPoint = CGPointMake(0 - (gradientSize*2), 0.5)
                gradientMask.endPoint = CGPointMake(1 + gradientSize, 0.5)
                
                //self.slideToUnlockLabel.removeFromSuperview()
                self.slideToUnlockLabel.layer.mask = gradientMask
                //superview?.addSubview(self.slideToUnlockLabel)
                
                animation.fromValue = startLocations
                animation.toValue = endLocations
                animation.repeatCount = 1000000
                animation.duration = 3.0
                
                gradientMask.addAnimation(animation, forKey: "animateGradient")
                
                //Add pan gesture
                self.panGesture.addTarget(self, action: "updateView:")
                self.view.addGestureRecognizer(self.panGesture)
                
                
                
                
            }
        }
    }
    
    func launchSettings(){
        self.viewAbove.removeGestureRecognizer(self.settingsTap)
        self.viewAbove.removeFromSuperview()
        self.performSegueWithIdentifier("settingsSegue", sender: self)
    }
    
    func updateView(recognizer : UIPanGestureRecognizer!){
        print("func updateView")
        self.view.bringSubviewToFront(recognizer.view!)
        let origin = self.lockDateCenter.constant
        
        let velocity = recognizer.velocityInView(self.view)
        //let translation = recognizer.translationInView(self.view)
        
        
        
        switch(recognizer.state) {
        case .Began:
            print("Panning has begun!")
        case .Changed:
            print("Panning has changed!")
            if velocity.x > 0 {
                //to the right
                
                //Check for swipe
                if abs(velocity.x) > 1000 {
                    print("swiped right")
                    didSwipe = true
                } else {
                    didSwipe = false
                }
                
            } else {
                //to the left
    
                //Check for swipe
                if abs(velocity.x) > 1000 {
                    print("swiped left")
                    didSwipe = false
                } else {
                    didSwipe = false
                }
            }
            
            if !didSwipe{
                
                //self.lockTimeCenter.constant = origin + recognizer.translationInView(view).x
                self.lockDateCenter.constant = origin - recognizer.translationInView(view).x
                self.slideTounlockCenter.constant = origin - recognizer.translationInView(view).x
                self.lockTimeCenter.constant = -self.slideTounlockCenter.constant
                print("Current position = \(self.lockDateCenter.constant)")
                
                recognizer.setTranslation(CGPointZero, inView: view)
            }
            
            
        case .Ended:
            print("Panning has ended!")
            
            if didSwipe == true {
                
                if velocity.x > 0 {
                    //swipe right
                    
                    UIView.animateWithDuration(0.1, delay: 0.0,  options: UIViewAnimationOptions.CurveEaseOut, animations: {
                        print("animate off screen")
                        self.lockTimeCenter.constant = origin + 450
                        self.lockDateCenter.constant = origin - 450
                        self.slideTounlockCenter.constant = origin - 450
                        
                        
                        let blurEffect = UIBlurEffect(style: UIBlurEffectStyle.Dark)
                        self.blurEffectView = UIVisualEffectView(effect: blurEffect)
                        self.blurEffectView.frame = self.view.bounds
                        self.blurEffectView.autoresizingMask = [.FlexibleWidth, .FlexibleHeight]
                        
                        self.view.addSubview(self.blurEffectView)
                        
                        self.view.layoutIfNeeded()
                        
                        }, completion: { finished in
                            UIView.animateWithDuration(0.2, delay: 0.0, options: UIViewAnimationOptions.CurveLinear, animations: {
                                //self.lockScreenImage.alpha = 0.0
                                //self.mainImageView.alpha = 0.0
                                
                                
                                }, completion: { finished in
                                    //self.unlockScreen()
                                    //self.setPinSelected(self)
                                    self.lockAppSelected(self)
                            })
                            
                            
                        })
                    
                    
                } else {
                    //Animate back to center
                    UIView.animateWithDuration(0.3, delay: 0.0,  options: UIViewAnimationOptions.CurveLinear, animations: {
                        self.lockTimeCenter.constant = self.resetOrigin
                        self.lockDateCenter.constant = self.resetOrigin
                        self.slideTounlockCenter.constant = self.resetOrigin
                        self.view.layoutIfNeeded()
                        
                        }, completion: nil)
                }
            } else {
                if self.lockDateCenter.constant < (-view.bounds.size.width/2) {
                    //self.unlockScreen()
                    let blurEffect = UIBlurEffect(style: UIBlurEffectStyle.Dark)
                    self.blurEffectView = UIVisualEffectView(effect: blurEffect)
                    self.blurEffectView.frame = self.view.bounds
                    self.blurEffectView.autoresizingMask = [.FlexibleWidth, .FlexibleHeight]
                    
                    self.view.addSubview(self.blurEffectView)
                    self.lockAppSelected(self)
                    
                } else {
                    print("Wrong direction, animate back to center")
                    //Didnt move far enough to animate in next items
                    UIView.animateWithDuration(0.3, delay: 0.0,  options: UIViewAnimationOptions.CurveLinear, animations: {
                        self.lockTimeCenter.constant = self.resetOrigin
                        self.lockDateCenter.constant = self.resetOrigin
                        self.slideTounlockCenter.constant = self.resetOrigin
                        self.view.layoutIfNeeded()
                        
                        }, completion: nil)
                }
                
            }
            
            
        default:
            break
        }
        
        
    }

    func unlockScreen(){
        print("func unlockScreen")
        
        
        self.blurEffectView.removeFromSuperview()
        self.hide = true
        self.prefersStatusBarHidden()
        self.mainImageView.alpha = 1.0
        
        if let defaults = NSUserDefaults(suiteName: "group.prophesy"){
            let subtleMode = defaults.boolForKey("subtleMode")
            if subtleMode == true {
                
                let useBackground = defaults.boolForKey("useBackgroundImage")
                if useBackground == true {
                    print("use image for background")
                    //let imagePath = defaults.objectForKey("backgroundImage") as! String
                    //print("Background image is \(imagePath)")
                    //let backgroundImage = UIImage(contentsOfFile: imagePath)
                    //mainImageView.image = backgroundImage
                    
                    let fetchRequest = NSFetchRequest(entityName: "Images")
                    //fetchRequest.predicate = NSPredicate(format: "name contains[c] %@", originalRecordingName)
                    let sortDescriptor = NSSortDescriptor(key: "backgroundImage", ascending: true)
                    fetchRequest.sortDescriptors = [sortDescriptor]
                    
                    if let managedObjectContext = (UIApplication.sharedApplication().delegate as! AppDelegate).managedObjectContext {
                        fetchResultController = NSFetchedResultsController(fetchRequest: fetchRequest, managedObjectContext: managedObjectContext, sectionNameKeyPath: nil, cacheName: nil)
                        
                        do {
                            try fetchResultController.performFetch()
                            let returnedItems = fetchResultController.fetchedObjects as! [Images]
                            print("Number of total Images: \(returnedItems.count)")
                            
                            if returnedItems.count == 0 {
                                print("Warning: Unable to retrieve from memory")
                            } else {
                                
                                let backgroundImage = UIImage(data: returnedItems[0].backgroundImage)
                                mainImageView.image = backgroundImage
                                
                                
                            }
                            
                        } catch  {
                            print("Failed to retrieve anything from core data")
                            return
                        }
                    }
                    
                }
                
                
                self.lockTimeCenter.constant = resetOrigin
                self.lockDateCenter.constant = resetOrigin
                self.slideTounlockCenter.constant = resetOrigin
                self.lockScreenImage.hidden = true  
                self.slideToUnlockLabel.hidden = true
                self.lockDate.hidden = true
                self.lockTime.hidden = true
                self.view.removeGestureRecognizer(self.panGesture)
                self.mainImageView.hidden = false
                self.recordPauseButton.titleLabel?.font = UIFont(name: "HelveticaNeue-Bold", size: 24)
                self.stopButton.titleLabel?.font = UIFont(name: "HelveticaNeue-Bold", size: 24)
                self.backButton.titleLabel?.font = UIFont(name: "HelveticaNeue-Bold", size: 24)
                self.playbackButton.hidden = false
                
                
            }
        }
    }
    
    @IBAction func playTapped( playButton: UIButton!){
        print("func playTapped")
        if recorder.recording != true {
            player = try? AVAudioPlayer(contentsOfURL: recorder.url)
            player.delegate = self
            player.play()
            
        }
    }
    
    @IBAction func openVoiceMemosApp(sender: AnyObject) {
        let voiceMemoHooks = "voicememos://"
        let voiceMemosUrl = NSURL(string: voiceMemoHooks)
        if UIApplication.sharedApplication().canOpenURL(voiceMemosUrl!)
        {
            UIApplication.sharedApplication().openURL(voiceMemosUrl!)
            
        } else {
            //redirect to safari because the user doesn't have Instagram
            print("App not installed")
            //UIApplication.sharedApplication().openURL(NSURL(string: "https://itunes.apple.com/in/app/instagram/id389801252?m")!)
            
        }
        
    }
    
    func setBackground(backgroundImage: UIImage!) {
        print("func setBackground")
        UIApplication.sharedApplication().setStatusBarHidden(true, withAnimation: .None)
        mainImageView.image = backgroundImage
        mainImageView.contentMode = UIViewContentMode.Center
        mainImageView.contentMode = UIViewContentMode.ScaleAspectFit
        mainImageView.clipsToBounds = true
        
        if let defaults = NSUserDefaults(suiteName: "group.prophesy"){
            
            let useBackground = defaults.boolForKey("useBackgroundImage")
            if useBackground == true {
                self.recordPauseButton.enabled = true
                self.recordPauseButton.setTitle("Begin Recording", forState: .Normal)
                self.recordPauseButton.titleLabel?.font = UIFont(name: "HelveticaNeue-Bold", size: 24)
                
            } else {
                self.recordPauseButton.enabled = false
                self.recordPauseButton.titleLabel?.lineBreakMode = NSLineBreakMode.ByWordWrapping
                self.recordPauseButton.titleLabel?.textAlignment = NSTextAlignment.Center
                self.recordPauseButton.setTitle("To start performing, go to settings, read the instructions and add a background photo", forState: .Normal)
                self.recordPauseButton.titleLabel?.font = UIFont(name: "HelveticaNeue-Bold", size: 24)
            }
            
        }
    }
    
    func setLockImage(lockImage: UIImage!) {
        print("func setLockImage")
        UIApplication.sharedApplication().setStatusBarHidden(true, withAnimation: .None)
        mainImageView.image = lockImage
        //mainImageView.contentMode = UIViewContentMode.Center
        //mainImageView.contentMode = UIViewContentMode.Center
        mainImageView.clipsToBounds = true
    }
    
    func audioRecorderDidFinishRecording(recorder: AVAudioRecorder, successfully flag: Bool) {
        print("func audioRecorderDidFinishRecording abort is  \(self.abortTrick)")
        
        if self.rewind == true {
            recordPauseButton.setTitle("Hold to Resume", forState: .Normal)
            recordPauseButton.titleLabel?.lineBreakMode = NSLineBreakMode.ByWordWrapping
            recordPauseButton.titleLabel?.numberOfLines = 0
            
            UIView.animateWithDuration(0.3, delay: 1.0,  options: UIViewAnimationOptions.AllowUserInteraction, animations: {
                print("fade out button text")
                self.recordPauseButton.alpha = 0.05
                self.stopButton.alpha = 0.05
                self.backButton.alpha = 0.05
                
                
                }, completion: { finished in
                    
                    print("animation completed")
                    
            })
        } else {
            if self.abortTrick == true {
                self.recordPauseButton.setTitle("Begin Recording", forState: .Normal)
                self.recordPauseButton.titleLabel?.font = UIFont(name: "HelveticaNeue-Bold", size: 24)
                self.recordPauseButton.hidden = false
                self.abortTrick = false
                
            } else {
                self.recordPauseButton.setTitle("Begin Recording", forState: .Normal)
                self.recordPauseButton.hidden = true
                
            }
        }
        
        
        
        //playButton.enabled = true
        
        
    }
    
    func refresh(){
        print("func refresh")
        //self.viewWillAppear(false)
        self.view.setNeedsDisplay()
    }
    
    override func prepareForSegue(segue: UIStoryboardSegue, sender: AnyObject!) {
        print("func prepareForSegue")
        if segue.identifier == "segueMemoTable" {
            let svc = segue.destinationViewController as! MemoPlayTableViewController
            
            svc.recorder = recorder
            svc.session = session
            svc.path = path
            svc.stopButton = stopButton
            svc.isRecording = isRecording
            svc.audioAsset = audioAsset
            svc.fullpath = fullpath
            svc.recordingTitle = recordingTitle
            svc.fakeRecordingName = fakeRecordingName

            //svc.delegate = self
        }
        
        if segue.identifier == "settingsSegue" {
            let svc2 = segue.destinationViewController as! SettingsTableViewController
            //svc2.homeThumbnail.setImage(self.mainImageView.image, forState: .Normal)
            svc2.delegate = self
            
        }
        
    }
    
    func doubleTap(sender : AnyObject!){
        print("func doubleTap")
        self.stopTapped()
    }
    
    @IBAction func unwindController(segue : UIStoryboardSegue!){
        print("func unwindController")
        self.recordPauseButton.hidden = false
        self.stopButton.hidden = true
        self.backButton.hidden = true
        self.settingsButton.hidden = false
        self.settingsButton.layer.borderWidth = 1.0
        self.settingsButton.setTitle("Settings", forState: UIControlState.Normal)
        self.playbackButton.hidden = false
        self.playbackButton.layer.borderWidth = 1.0
        self.playbackButton.setTitle("Playback", forState: UIControlState.Normal)
        self.launchLockScreenButton.hidden = true
        self.recordingTimes = []
        self.recordingEndingTimes = []
        self.recordingURLs = []
        self.multipleOutButton.hidden = false
        
        
        //self.refresh()
    }
    
    @IBAction func unwindAndAppend(segue : UIStoryboardSegue!){
        print("func unwindAndAppend")
        self.recordPauseButton.hidden = false
        self.stopButton.hidden = true
        self.backButton.hidden = true
        self.settingsButton.hidden = false
        self.settingsButton.layer.borderWidth = 1.0
        self.settingsButton.setTitle("Settings", forState: UIControlState.Normal)
        self.playbackButton.hidden = false
        self.playbackButton.layer.borderWidth = 1.0
        self.playbackButton.setTitle("Playback", forState: UIControlState.Normal)
        self.launchLockScreenButton.hidden = true
        
        self.append = true
        
        
        self.refresh()
    }
    
    @IBAction func goBack(){
        print("Func goBack")
        AudioServicesPlaySystemSound(1352)
        self.rewind = true
        
        //stop recording
        recorder.stop()
        
        //save recorder URL
        self.recordingURLs.append(self.recorder.url)
        
        //save end time
        self.recordingEndingTimes.append(self.recordingTimes[self.recordingTimes.count - 2])
        
        //reset recordingTimes array
        self.recordingTimes = [NSTimeInterval(0)]
        
        //reset recording
        //Setup File Name
        let date = NSDate()
        let formatter = NSDateFormatter()
        formatter.dateFormat = "yyyy-MM-dd_hh_mm_ss"
        recordingDate = formatter.stringFromDate(date)
        
        path = NSSearchPathForDirectoriesInDomains(.DocumentDirectory, .UserDomainMask, true)[0] as NSString as String
        recordingTitle = "recording_" + recordingDate + ".m4a"
        fullpath = path + "/" + recordingTitle
        
        print("String is \(path)")
        
        // Setup Audio Session
        soundFileURL = NSURL(fileURLWithPath: fullpath)
        self.session = AVAudioSession.sharedInstance()
        do {
            try self.session.setCategory("AVAudioSessionCategoryPlayAndRecord")
            try self.session.setActive(true )
            recorder = try AVAudioRecorder(URL: soundFileURL, settings: recordSettings)
            recorder.delegate = self
            recorder.meteringEnabled = true
            recorder.prepareToRecord()
        } catch _ {
            print("Session failed to set")
            recorder = nil
        }

        
        //for debug
        print("URLs: \(self.recordingURLs) Times: \(self.recordingEndingTimes)")
    }
    
    func resetTrick(){
        print("func resetTrick")
        
        self.abortTrick = true
        self.newRecording = true
        
        //for debug purposes
        if self.recordPauseButton.hidden == true {
            print("Why is this hidden?")
        }
        
        
        //self.recordPauseButton.setTitle("Begin Recording", forState: .Normal)
        //self.recordPauseButton.titleLabel?.textAlignment = NSTextAlignment.Center
        //self.recordPauseButton.alpha = 1.0
        
        
        //remove gesture
        //self.view.removeGestureRecognizer(self.doubleTapGesture)
        //print("Gesture removed")
        
        //stop recording
        recorder.stop()
        isRecording = false

        
        //reset how the screen looks
        
        self.recordPauseButton.hidden = false
        self.stopButton.hidden = true
        self.backButton.hidden = true
        self.settingsButton.hidden = false
        self.settingsButton.layer.borderWidth = 1.0
        self.settingsButton.setTitle("Settings", forState: UIControlState.Normal)
        self.playbackButton.hidden = false
        self.playbackButton.layer.borderWidth = 1.0
        self.playbackButton.setTitle("Playback", forState: UIControlState.Normal)
        //self.launchLockScreenButton.hidden = true
        self.mainImageView.hidden = false
        self.multipleOutButton.hidden = false
        
 
        AudioServicesPlaySystemSound(1352)
        //self.refresh()
        
        //reset can have a delay in the first recording
        //let's prep the next recording ahead of time to mitigate the delay
        self.session = AVAudioSession.sharedInstance()
        do {
            try self.session.setCategory("AVAudioSessionCategoryPlayAndRecord")
            try self.session.setActive(true )
            recorder.prepareToRecord()
        } catch _ {
            print("Session failed to set")
        }
        
        /*do {
            try self.session.setActive(true )
        } catch _ {
        }
        recorder.prepareToRecord()*/
        
        
    }
    
    func deleteFile(filename : String!){
        print("func deleteFile")
        let localPath = NSSearchPathForDirectoriesInDomains(.DocumentDirectory, .UserDomainMask, true)[0] as NSString as String
        let fullFilePath = localPath + "/" + filename
        print("full path is \(fullFilePath)")
        
        var error: NSError?
        
        let filemgr = NSFileManager.defaultManager()
        
        do {
            try filemgr.removeItemAtPath(fullFilePath)
            print("Remove successful")
        } catch let error1 as NSError {
            error = error1
            print("Remove failed: \(error!.localizedDescription)")
        }
        
        let filelist: [AnyObject]?
        do {
            filelist = try filemgr.contentsOfDirectoryAtPath(localPath)
        } catch let error1 as NSError {
            error = error1
            filelist = nil
        }
        print("Current directory listing:")
        for filename in filelist! {
            print(filename)
        }
    }
    
    func audioRecorderEncodeErrorDidOccur(recorder: AVAudioRecorder, error: NSError?) {
        print("Audio Record Encode Error")
    }
    
    func getPinList() -> ([String], [String], [String]){
        var pinList : [String] = []
        var fileList: [String] = []
        var outNameList:[String] = []
        //Get sequences from core data
        let fetchRequest = NSFetchRequest(entityName: "Sequence")
        let sortDescriptor1 = NSSortDescriptor(key: "dateOrder", ascending: true)
        fetchRequest.sortDescriptors = [sortDescriptor1]
        
        if let managedObjectContext = (UIApplication.sharedApplication().delegate as! AppDelegate).managedObjectContext {
            fetchResultController = NSFetchedResultsController(fetchRequest: fetchRequest, managedObjectContext: managedObjectContext, sectionNameKeyPath: nil, cacheName: nil)
            //fetchResultController.delegate = self
            
            do {
                try fetchResultController.performFetch()
                let sequences = fetchResultController.fetchedObjects as! [Sequence]
                print("Number of total Sequences: \(sequences.count)")
                let filePaths = sequences.map{ sequence in sequence.filePaths}.map{fileString in fileString.componentsSeparatedByString(",").filter{$0 != "Empty"}}
                let outNames = sequences.map{sequence in sequence.name}
                
                for (index1, out) in filePaths.enumerate() {
                    for (index2, element) in out.enumerate() {
                        let value = 1000 + (100 * index1) + index2
                        pinList.append(String(value))
                        fileList.append(element)
                        outNameList.append(outNames[index1])
                    }
                    
                }
                
                print("pinList is \(pinList)")
                print("fileList is \(fileList)")
                print("outNameList is \(outNameList)")
                
                
                
            } catch  {
                print("Could not retrieve Sequences")
                pinList = ["9999"]
            }
        }
        
        
        return (pinList, fileList, outNameList)
    }
    
    func setOutForCheatSheet(index : Int!){
        if let defaults = NSUserDefaults(suiteName: "group.prophesy"){
            defaults.setInteger(index, forKey: "multipleOutChoice")
            defaults.synchronize()
        }
    }
    
    func checkMultipleOutCount() -> Bool {
        let fetchRequest = NSFetchRequest(entityName: "Sequence")
        let sortDescriptor1 = NSSortDescriptor(key: "dateOrder", ascending: true)
        fetchRequest.sortDescriptors = [sortDescriptor1]
        
        if let managedObjectContext = (UIApplication.sharedApplication().delegate as! AppDelegate).managedObjectContext {
            fetchResultController = NSFetchedResultsController(fetchRequest: fetchRequest, managedObjectContext: managedObjectContext, sectionNameKeyPath: nil, cacheName: nil)
            //fetchResultController.delegate = self
            
            do {
                try fetchResultController.performFetch()
                let sequences = fetchResultController.fetchedObjects as! [Sequence]
                print("Number of total Sequences: \(sequences.count)")
                if sequences.count > 0 {
                    return true
                } else {
                    return false
                }
            } catch  {
                print("Could not retrieve Sequences")
                return false
            }
        }
        return false
    }
    
    //MARK : Delegate methods for ABPADLOCK 
    //MARK: Action methods
    @IBAction func lockAppSelected(sender: AnyObject) {
        
        thePin = "2580"
        if thePin == nil {
            let alertController = UIAlertController(title: "You must set a pin first", message: nil, preferredStyle: UIAlertControllerStyle.Alert)
            alertController.addAction(UIAlertAction(title: "Ok", style: UIAlertActionStyle.Default, handler: nil))
            presentViewController(alertController, animated: true, completion: nil)
            return
        }
        
        let lockScreen = ABPadLockScreenViewController(delegate: self, complexPin: false)
        lockScreen.setAllowedAttempts(3)
        lockScreen.view.backgroundColor = UIColor.clearColor()
        lockScreen.modalPresentationStyle = UIModalPresentationStyle.OverCurrentContext
        lockScreen.modalTransitionStyle = UIModalTransitionStyle.CrossDissolve
        
        presentViewController(lockScreen, animated: true, completion: nil)
    }
    
    @IBAction func setPinSelected(sender: AnyObject) {
        let lockSetupScreen = ABPadLockScreenSetupViewController(delegate: self, complexPin: false, subtitleLabelText: "Select a pin")
        lockSetupScreen.tapSoundEnabled = true
        lockSetupScreen.errorVibrateEnabled = true
        lockSetupScreen.view.backgroundColor = UIColor.clearColor()
        lockSetupScreen.modalPresentationStyle = UIModalPresentationStyle.OverCurrentContext
        lockSetupScreen.modalTransitionStyle = UIModalTransitionStyle.CrossDissolve
        
        presentViewController(lockSetupScreen, animated: true, completion: nil)
    }
    
    //MARK: Lock Screen Setup Delegate
    func pinSet(pin: String!, padLockScreenSetupViewController padLockScreenViewController: ABPadLockScreenSetupViewController!) {
        thePin = pin
        dismissViewControllerAnimated(true, completion: nil)
    }
    
    func unlockWasCancelledForSetupViewController(padLockScreenViewController: ABPadLockScreenAbstractViewController!) {
        dismissViewControllerAnimated(true, completion: nil)
    }
    
    //MARK: Lock Screen Delegate
    func padLockScreenViewController(padLockScreenViewController: ABPadLockScreenViewController!, validatePin pin: String!) -> Bool {
        print("Validating Pin \(pin)")
        padLockScreenViewController.stopMotion()
        
        if (pin == "9999") || (pin == "2580") {
            thePin = pin
            return true
        } else {
            if self.multipleOutFlag == true {
                let (pinList, fileList, outNameList) = getPinList()
                let pinFound = pinList.indexOf(pin)
                
                if pinFound != nil {
                    thePin = pinList[pinFound!]
                    self.outFile = fileList[pinFound!]
                    self.outName = outNameList[pinFound!]
                    
                    print("Pin: \(thePin) Name: \(self.outName) File: \(self.outFile)")
                    self.multipleOutFlag = false
                    return true
                } else {
                    return false
                }
            } else {
                return false
            }
            
        }
        
    }
    
    func unlockWasSuccessfulForPadLockScreenViewController(padLockScreenViewController: ABPadLockScreenViewController!) {
        print("Unlock Successful!")
        dismissViewControllerAnimated(true, completion: nil)
        
        //This is the pin for regular trick
        if thePin == "2580" {
            self.unlockScreen()
            return
        }
        
        //This is the pin for aborting the trick
        if thePin == "9999" {
            self.unlockScreen()
            self.resetTrick()
        } else {
            //Here we copy the file to the playback page based on pin selected
            let path = NSSearchPathForDirectoriesInDomains(.DocumentDirectory, .UserDomainMask, true)[0] as NSString as String
            let fullPath = path + "/" + self.outFile
            print("fullPath os \(fullPath)")
            self.saveFile(NSURL(fileURLWithPath: fullPath), savePath: fullPath, saveTitle: self.outFile, multipleOut: true)
            self.unlockScreen()
        }
        
        
        
    }
    
    func unlockWasUnsuccessful(falsePin: String!, afterAttemptNumber attemptNumber: Int, padLockScreenViewController: ABPadLockScreenViewController!) {
        print("Failed Attempt \(attemptNumber) with incorrect pin \(falsePin)")
    }
    
    func unlockWasCancelledForPadLockScreenViewController(padLockScreenViewController: ABPadLockScreenViewController!) {
        print("Unlock Cancled")
        //dismissViewControllerAnimated(true, completion: nil)
    }
    



}

