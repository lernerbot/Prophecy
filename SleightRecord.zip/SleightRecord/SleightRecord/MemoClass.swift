//
//  MemoClass.swift
//  SleightRecord
//
//  Created by Lee Lerner on 10/21/14.
//  Copyright (c) 2014 Lee Lerner. All rights reserved.
//

import Foundation
import CoreData


class Memo:NSManagedObject {
    @NSManaged var name:String!
    @NSManaged var date:String!
    @NSManaged var duration:String!
    @NSManaged var path:String!
    @NSManaged var file:String!
    @NSManaged var sliderValue:NSNumber!
    @NSManaged var durationValue:NSNumber!
    @NSManaged var dateOrder:NSDate!

    
    /*init(name:String, date:String, duration:String, path:String) {
        self.name = name
        self.date = date
        self.duration = duration
        self.path = path
    }*/
    
    
}