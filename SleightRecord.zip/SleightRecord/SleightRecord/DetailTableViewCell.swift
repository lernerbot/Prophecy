//
//  DetailTableViewCell.swift
//  Prophesy Voice
//
//  Created by Lee Lerner on 10/29/15.
//  Copyright © 2015 Lee Lerner. All rights reserved.
//

import UIKit

class DetailTableViewCell: UITableViewCell {

    @IBOutlet weak var detailName : UILabel!
    @IBOutlet weak var detailNumber : UILabel!
    
    @IBOutlet weak var detailNumberRightConstraint: NSLayoutConstraint!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }
    
    override func prepareForReuse() {
        super.prepareForReuse()
        self.detailName.text = nil
        self.detailNumber.text = nil
    }

}
