//
//  sequenceClass.swift
//  Prophesy Voice
//
//  Created by Lee Lerner on 10/29/15.
//  Copyright © 2015 Lee Lerner. All rights reserved.
//

import Foundation
import CoreData

class Sequence:NSManagedObject {
    @NSManaged var dateOrder:NSDate!
    @NSManaged var name : String!
    @NSManaged var fileNames: String!
    @NSManaged var filePaths : String!
    
    //pre-core data testing
    //var fileNames = [String](count: 20, repeatedValue: "testName")
    //var filePaths = [String](count: 20, repeatedValue: "testFile")
    
    /*init(name : String, fileNames:[String], filePaths:[String]){
        self.name = name
        self.fileNames = fileNames
        self.fileNames = filePaths
    }*/
}
