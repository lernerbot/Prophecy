//
//  PushButtonView.swift
//  Graviato
//
//  Created by Lee Lerner on 5/4/15.
//  Copyright (c) 2015 Lee Lerner. All rights reserved.
//

import UIKit


@IBDesignable class PushButtonView: UIButton {
    
    @IBInspectable var fillColor: UIColor = UIColor.whiteColor()
    @IBInspectable var buttonColor : UIColor = UIColor.blackColor()
    @IBInspectable var buttonOutlineColor : UIColor = UIColor.blackColor()
    
    @IBInspectable var isAddButton: Bool = true
    @IBInspectable var isRecordButton : Bool = true {
        didSet {
            //animateChange()
            setNeedsDisplay()
        }
    }

    
    
    override func drawRect(rect: CGRect) {
        //set the background shape and fill color
        print("draw rect run")
        let backgroundPath = UIBezierPath(ovalInRect: rect)
        fillColor.setFill()
        backgroundPath.fill()
        
        let centerPoint = CGPoint(x: bounds.width/2, y: bounds.height/2)
        let overlayImage = UIImageView(image: UIImage(named: "microphone.png"))
        
        if isRecordButton {
            //Remove subview from stop button
            for view in self.subviews {
                view.removeFromSuperview()
            }
            
            let buttonPath = circlePathWithCenter(centerPoint, radius: bounds.width/2.5) 
            //set the stroke color
            buttonOutlineColor.setStroke()
            
            //set fill
            buttonColor.setFill()
            buttonPath.fill()
            
            //draw the stroke
            buttonPath.stroke()
            
            //add the mic pic
            
            overlayImage.center = CGPoint(x: bounds.width/4, y: bounds.height/4)
            self.addSubview(overlayImage)
            
            
        } else {
            //Remove subview of microphone image
            for view in self.subviews {
                view.removeFromSuperview()
            }
            
            let buttonPath = squarePathWithCenter(centerPoint, side: bounds.width/1.5)
            //set the stroke color
            buttonOutlineColor.setStroke()
            
            //set fill
            buttonColor.setFill()
            buttonPath.fill()
            
            //draw the stroke
            buttonPath.stroke()
            
        }
        

    }
    
    func animateChange(){
        print("animate change run")
        let centerPoint = CGPoint(x: bounds.width/2, y: bounds.height/2)
        let roundButtonPath = circlePathWithCenter(centerPoint, radius: bounds.width/2.5)
        let squareButtonPath = squarePathWithCenter(centerPoint, side: bounds.width/1.5)
        var fromPath : CGPathRef!
        var toPath : CGPathRef!
        
        if self.isRecordButton {
            //animate from square to circle
            fromPath = squareButtonPath.CGPath
            toPath = roundButtonPath.CGPath
        } else {
            //animate from circle to square
            fromPath = roundButtonPath.CGPath
            toPath = squareButtonPath.CGPath
        }
        
        let pathToAnimate = CAShapeLayer()
        pathToAnimate.path = toPath
        //pathToAnimate.fillColor = fillColor.CGColor
        self.layer.addSublayer(pathToAnimate)
        
        let animation = CABasicAnimation(keyPath: "path")
        animation.duration = 30
        
        animation.fromValue = fromPath
        animation.toValue = toPath
        //animation.removedOnCompletion = false
        //animation.fillMode = kCAFillModeForwards
        
        self.layer.addAnimation(animation, forKey: "pathToAnimate")
        
    }
    
    func circlePathWithCenter(center: CGPoint, radius: CGFloat) -> UIBezierPath {
        let circlePath = UIBezierPath()
        circlePath.addArcWithCenter(center, radius: radius, startAngle: -CGFloat(M_PI), endAngle: -CGFloat(M_PI/2), clockwise: true)
        circlePath.addArcWithCenter(center, radius: radius, startAngle: -CGFloat(M_PI/2), endAngle: 0, clockwise: true)
        circlePath.addArcWithCenter(center, radius: radius, startAngle: 0, endAngle: CGFloat(M_PI/2), clockwise: true)
        circlePath.addArcWithCenter(center, radius: radius, startAngle: CGFloat(M_PI/2), endAngle: CGFloat(M_PI), clockwise: true)
        circlePath.closePath()
        return circlePath
    }
    
    func squarePathWithCenter(center: CGPoint, side: CGFloat) -> UIBezierPath {
        let squarePath = UIBezierPath()
        let startX = center.x - side / 2
        let startY = center.y - side / 2
        squarePath.moveToPoint(CGPoint(x: startX, y: startY))
        squarePath.addLineToPoint(squarePath.currentPoint)
        squarePath.addLineToPoint(CGPoint(x: startX + side, y: startY))
        squarePath.addLineToPoint(squarePath.currentPoint)
        squarePath.addLineToPoint(CGPoint(x: startX + side, y: startY + side))
        squarePath.addLineToPoint(squarePath.currentPoint)
        squarePath.addLineToPoint(CGPoint(x: startX, y: startY + side))
        squarePath.addLineToPoint(squarePath.currentPoint)
        squarePath.closePath()
        return squarePath
    }
   
}

