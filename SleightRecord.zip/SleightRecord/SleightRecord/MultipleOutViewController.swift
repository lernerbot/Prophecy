//
//  MultipleOutViewController.swift
//  Prophesy Voice
//
//  Created by Lee Lerner on 12/2/15.
//  Copyright © 2015 Lee Lerner. All rights reserved.
//

import UIKit
import CoreData

protocol writeValueBackDelegate {
    func resetTrick()
    func setOutForCheatSheet(index : Int!)
}

class MultipleOutViewController: UIViewController, NSFetchedResultsControllerDelegate, UITableViewDataSource, UITableViewDelegate {
    
    var fetchResultController:NSFetchedResultsController!
    var pinList : [String] = []
    var outNameList : [String] = []
    @IBOutlet weak var tableView : UITableView!
    
    var delegate : writeValueBackDelegate!
    

    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        self.title = "Out List"
        let cancelButton : UIBarButtonItem = UIBarButtonItem(title: "Cancel", style: UIBarButtonItemStyle.Plain, target: self, action: "exitOutList")
        self.navigationItem.rightBarButtonItem = cancelButton
        
        (outNameList, pinList) = getOutList()
        tableView.dataSource = self
        tableView.delegate = self
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    func exitOutList(){
        self.navigationController?.dismissViewControllerAnimated(true, completion: nil)
        delegate.resetTrick()
    }
    
    func tableView(tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return self.outNameList.count
    }
    
    func tableView(tableView: UITableView, cellForRowAtIndexPath indexPath: NSIndexPath) -> UITableViewCell {
        let cellIdentifier = "Cell"
        let cell = tableView.dequeueReusableCellWithIdentifier(cellIdentifier) as! MultipleOutTableViewCell
        
        cell.pinNumber.text = pinList[indexPath.row]
        cell.outName.text = outNameList[indexPath.row]
        
        return cell
    }
    
    func tableView(tableView: UITableView, didSelectRowAtIndexPath indexPath: NSIndexPath) {
        delegate.setOutForCheatSheet(indexPath.row)
        self.navigationController?.dismissViewControllerAnimated(true, completion: nil)
    }
    
    func getOutList() -> ([String], [String]){
        var pinList : [String] = []
        var outNameList:[String] = []
        //Get sequences from core data
        let fetchRequest = NSFetchRequest(entityName: "Sequence")
        let sortDescriptor1 = NSSortDescriptor(key: "dateOrder", ascending: true)
        fetchRequest.sortDescriptors = [sortDescriptor1]
        
        if let managedObjectContext = (UIApplication.sharedApplication().delegate as! AppDelegate).managedObjectContext {
            fetchResultController = NSFetchedResultsController(fetchRequest: fetchRequest, managedObjectContext: managedObjectContext, sectionNameKeyPath: nil, cacheName: nil)
            //fetchResultController.delegate = self
            
            do {
                try fetchResultController.performFetch()
                let sequences = fetchResultController.fetchedObjects as! [Sequence]
                print("Number of total Sequences: \(sequences.count)")
                outNameList = sequences.map{sequence in sequence.name}
                
                for (index, out) in outNameList.enumerate() {
                    let valueToAppend = "1" + String(index) + "_ _"
                    pinList.append(valueToAppend)
                    
                }
                
                print("pinList is \(pinList)")
                print("outNameList is \(outNameList)")
                
                
                
            } catch  {
                print("Could not retrieve Sequences")
                pinList = ["9999"]
                outNameList = ["Error Retrieving Data"]
            }
        }
        
        
        return (outNameList, pinList)
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepareForSegue(segue: UIStoryboardSegue, sender: AnyObject?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
