//
//  PlayPauseButtonView.swift
//  SleightRecord
//
//  Created by Lee Lerner on 7/23/15.
//  Copyright (c) 2015 Lee Lerner. All rights reserved.
//

import UIKit

@IBDesignable class PlayPauseButtonView: UIButton {
    
    @IBInspectable var fillColor: UIColor = UIColor.redColor()
    @IBInspectable var buttonColor : UIColor = UIColor.blueColor()
    @IBInspectable var buttonOutlineColor : UIColor = UIColor.blueColor()
    
    @IBInspectable var isPlayButton : Bool = true {
        didSet {
            //animateChange()
            setNeedsDisplay()
        }
    }
    
    
    
    override func drawRect(rect: CGRect) {
        //set the background shape and fill color
        //println("draw rect run")
        
        //var backgroundPath = UIBezierPath(ovalInRect: rect)
        //fillColor.setFill()
        //backgroundPath.fill()
        
        //let centerPoint = CGPoint(x: bounds.width/2, y: bounds.height/2)
        
        if isPlayButton {
            
            //Draw Triangle
            let radius = ((bounds.width)/2 - 6)/2 as CGFloat
            let a = radius * sqrt(CGFloat(3.0)) / 2
            let b = radius / 2
            let trianglePath = UIBezierPath()
            trianglePath.moveToPoint(CGPointMake(0, -radius))
            trianglePath.addLineToPoint(CGPointMake(a, b))
            trianglePath.addLineToPoint(CGPointMake(-a, b))
            trianglePath.closePath()
            
            trianglePath.applyTransform(CGAffineTransformMakeRotation((90 * CGFloat(M_PI)) / 180.0))
            trianglePath.applyTransform(CGAffineTransformMakeTranslation(CGRectGetMidX(bounds), CGRectGetMidY(bounds)))
            
            //set the stroke color
            buttonOutlineColor.setStroke()
            
            //set fill
            buttonColor.setFill()
            trianglePath.fill()
            
            //draw the stroke
            trianglePath.stroke()

            
        } else {
            //Draw Parallel Lines for Pause Button
            let linePath = UIBezierPath()
            let linePath2 = UIBezierPath()
            let lineWidth : CGFloat = 3.0
            linePath.lineWidth = lineWidth
            linePath2.lineWidth = lineWidth
            
            //move to initial point of path to the start of the vertical stroke
            linePath.moveToPoint(CGPoint(x: (bounds.width/2 - 5) , y: bounds.height/3))
            linePath2.moveToPoint(CGPoint(x: (bounds.width/2 + 5)  , y: bounds.height/3))
            
            //add a point to the path at the end of the stroke
            linePath.addLineToPoint(CGPoint(x: (bounds.width/2 - 5) , y: bounds.height * (2/3)))
            linePath2.addLineToPoint(CGPoint(x: (bounds.width/2 + 5), y: bounds.height * (2/3)))
            
            buttonOutlineColor.setStroke()
            buttonColor.setFill()
            linePath.fill()
            linePath2.fill()
            linePath.stroke()
            linePath2.stroke()
            
            
            
            
        }
        
        
    }
    
    func animateChange(){
        print("animate change run")
        let centerPoint = CGPoint(x: bounds.width/2, y: bounds.height/2)
        let roundButtonPath = circlePathWithCenter(centerPoint, radius: bounds.width/2.5)
        let squareButtonPath = squarePathWithCenter(centerPoint, side: bounds.width/1.5)
        var fromPath : CGPathRef!
        var toPath : CGPathRef!
        
        if self.isPlayButton {
            //animate from square to circle
            fromPath = squareButtonPath.CGPath
            toPath = roundButtonPath.CGPath
        } else {
            //animate from circle to square
            fromPath = roundButtonPath.CGPath
            toPath = squareButtonPath.CGPath
        }
        
        let pathToAnimate = CAShapeLayer()
        pathToAnimate.path = toPath
        //pathToAnimate.fillColor = fillColor.CGColor
        self.layer.addSublayer(pathToAnimate)
        
        let animation = CABasicAnimation(keyPath: "path")
        animation.duration = 30
        
        animation.fromValue = fromPath
        animation.toValue = toPath
        //animation.removedOnCompletion = false
        //animation.fillMode = kCAFillModeForwards
        
        self.layer.addAnimation(animation, forKey: "pathToAnimate")
        
    }
    
    func circlePathWithCenter(center: CGPoint, radius: CGFloat) -> UIBezierPath {
        let circlePath = UIBezierPath()
        circlePath.addArcWithCenter(center, radius: radius, startAngle: -CGFloat(M_PI), endAngle: -CGFloat(M_PI/2), clockwise: true)
        circlePath.addArcWithCenter(center, radius: radius, startAngle: -CGFloat(M_PI/2), endAngle: 0, clockwise: true)
        circlePath.addArcWithCenter(center, radius: radius, startAngle: 0, endAngle: CGFloat(M_PI/2), clockwise: true)
        circlePath.addArcWithCenter(center, radius: radius, startAngle: CGFloat(M_PI/2), endAngle: CGFloat(M_PI), clockwise: true)
        circlePath.closePath()
        return circlePath
    }
    
    func squarePathWithCenter(center: CGPoint, side: CGFloat) -> UIBezierPath {
        let squarePath = UIBezierPath()
        let startX = center.x - side / 2
        let startY = center.y - side / 2
        squarePath.moveToPoint(CGPoint(x: startX, y: startY))
        squarePath.addLineToPoint(squarePath.currentPoint)
        squarePath.addLineToPoint(CGPoint(x: startX + side, y: startY))
        squarePath.addLineToPoint(squarePath.currentPoint)
        squarePath.addLineToPoint(CGPoint(x: startX + side, y: startY + side))
        squarePath.addLineToPoint(squarePath.currentPoint)
        squarePath.addLineToPoint(CGPoint(x: startX, y: startY + side))
        squarePath.addLineToPoint(squarePath.currentPoint)
        squarePath.closePath()
        return squarePath
    }
    
}
