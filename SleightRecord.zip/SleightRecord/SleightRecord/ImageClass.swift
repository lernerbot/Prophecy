//
//  ImageClass.swift
//  SleightRecord
//
//  Created by Lee Lerner on 9/21/15.
//  Copyright © 2015 Lee Lerner. All rights reserved.
//

import Foundation
import CoreData


class Images:NSManagedObject {
    
    @NSManaged var backgroundImage : NSData!
    @NSManaged var lockScreenImage : NSData!
    @NSManaged var backgroundThumbnail : NSData!
    @NSManaged var lockScreenThumbnail : NSData!
    
}
