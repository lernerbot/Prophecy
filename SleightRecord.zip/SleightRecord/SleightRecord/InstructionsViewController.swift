//
//  InstructionsViewController.swift
//  The Premonition
//
//  Created by Lee Lerner on 10/15/15.
//  Copyright © 2015 Lee Lerner. All rights reserved.
//

import UIKit

class InstructionsViewController: UIViewController, UIWebViewDelegate {
    @IBOutlet weak var myWebView : UIWebView!

    override func viewDidLoad() {
        super.viewDidLoad()
        self.title = "Instructions"

        // Do any additional setup after loading the view.
        let localfilePath = NSBundle.mainBundle().URLForResource("ThePremonitionInstructions 5", withExtension: "html");
        let myRequest = NSURLRequest(URL: localfilePath!);
        myWebView.loadRequest(myRequest);
        myWebView.delegate = self
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    func webViewDidFinishLoad(webView: UIWebView) {
        /*let contentSize = webView.scrollView.contentSize
        let viewSize = webView.bounds.size
        
        let rw = viewSize.width / contentSize.width
        
        webView.scrollView.minimumZoomScale = rw
        webView.scrollView.maximumZoomScale = rw
        webView.scrollView.zoomScale = rw*/
        
        

        
        webView.scalesPageToFit = true
        print("Frame width \(webView.scrollView.frame.size.width)")
        let scale = 100000/webView.scrollView.frame.size.width
        let jsString = NSString(format: "document.getElementsByTagName('body')[0].style.webkitTextSizeAdjust= '%f%%'", scale)
        webView.stringByEvaluatingJavaScriptFromString(jsString as String)
        
        
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepareForSegue(segue: UIStoryboardSegue, sender: AnyObject?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
