//
//  MultipleOutTableViewCell.swift
//  Prophesy Voice
//
//  Created by Lee Lerner on 12/2/15.
//  Copyright © 2015 Lee Lerner. All rights reserved.
//

import UIKit

class MultipleOutTableViewCell: UITableViewCell {

    @IBOutlet weak var outName : UILabel!
    @IBOutlet weak var pinNumber : UILabel!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }
    
    override func prepareForReuse() {
        self.pinNumber.text = nil
        self.outName.text = nil
    }

}
