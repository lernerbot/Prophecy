//
//  MemoPlayTableViewController.swift
//  SleightRecord
//
//  Created by Lee Lerner on 10/21/14.
//  Copyright (c) 2014 Lee Lerner. All rights reserved.
//

import UIKit
import CoreData
import AVFoundation
import AVKit

protocol DetailsDelegate {
    func stopTapped(uibutton: UIButton!)
}

class MemoPlayTableViewController: UIViewController, UITableViewDelegate, UITableViewDataSource, NSFetchedResultsControllerDelegate, UITextFieldDelegate {

    var fetchResultController:NSFetchedResultsController!
    var player : AVAudioPlayer!
    var soundFileURL: NSURL!
    var session: AVAudioSession!
    var recorder : AVAudioRecorder!
    var delegate: DetailsDelegate!
    var path: String!
    var stopButton:UIButton!
    var isRecording: Bool!
    var isPlaying: Bool!
    var isPaused: Bool!
    var startToPlay: Bool!
    var memo:Memo!
    var audioAsset:AVURLAsset!
    var firstColon:String!
    var secondColon:String!
    var fullpath:String!
    var fakeRecordingName:String!
    var currentPath:String!
    var memos:[Memo] = []
    var cells:[NSArray] = []
    
    
    var firstRun : Bool = true
    var padding : CGFloat = 0
    var offScreen : CGFloat = -51
    var renameFlag : Bool!
    var cropButtonOverview : UIView!
    var meterPlayButtonOverview : UIView!
    var  heightCounter : Int = 0
    var pathLayer : CAShapeLayer!
    var textToPresent : String!
    var recordingPaused : Bool = false
    var collapseCell : Bool = false
    var viewAbove : UIView!
    var viewBelow : UIView!
    var tapToCloseKeyboardView : UIView!
    var recordingOverview : UIView!
    var tableOverview : UIView!
    var tapToCollapse : UITapGestureRecognizer!
    var tapToCollapse2 : UITapGestureRecognizer!
    var appendCount : Int!
    var activityArray:[AnyObject!] = []
    var selectedCellIndexPath : NSIndexPath!
    var currentCellIndexPath : NSIndexPath!
    var editingCellIndexPath : NSIndexPath!
    var highlightedCellIndexPath : NSIndexPath!
    var timer : NSTimer!
    var recordingTimer : NSTimer!
    var timerCounter : Int!
    var timeLeft : Float!
    var audioSlider:UISlider!
    var thePlayerItem:AVPlayerItem!
    var currentValue: Float!
    var interval:Float!
    var currentTimeLabel:String!
    var timeLeftLabel:String!
    var duration:NSTimeInterval!
    var currentSliderValue: Float!
    var currentTextField : UITextField!
    var tap:UITapGestureRecognizer!
    var tap2: UITapGestureRecognizer!
    @IBOutlet weak var editButton : UIButton!
    @IBOutlet weak var speakerButton : UIButton!
    @IBOutlet weak var cropButton : UIImageView!
    @IBOutlet weak var meterPlayButton : UIImageView!
    var footerView : UIView!
    var speaker : Bool!
    
    var levelArray : [Float] = []
    var displayLink : CADisplayLink!
    @IBOutlet weak var recordingMeter: EnhancedRecordingMeter!
    
    var recordingTitle:String!
    var recordingDate:String!
    /*let recordSettings : [String : AnyObject!] = [AVFormatIDKey: kAudioFormatMPEG4AAC, AVEncoderAudioQualityKey : AVAudioQuality.Max.rawValue, AVEncoderBitRateKey : 320000,AVNumberOfChannelsKey: 2, AVSampleRateKey : 44100.0]*/
    
    var recordSettings = [AVSampleRateKey : NSNumber(float: Float(44100.0)),
        AVFormatIDKey : NSNumber(int: Int32(kAudioFormatMPEG4AAC)),
        AVNumberOfChannelsKey : NSNumber(int: 1),
        AVEncoderAudioQualityKey : NSNumber(int: Int32(AVAudioQuality.Medium.rawValue))]
    
    @IBOutlet var tableView : UITableView!
    @IBOutlet weak var recordButton : RecordButtonView!
    @IBOutlet weak var topView : UIView!
    @IBOutlet weak var topLabel : UILabel!
    @IBOutlet weak var backgroundView : UIView!
    
    @IBOutlet weak var newRecordingLabel : UILabel!
    @IBOutlet weak var newRecordingDateLabel : UILabel!
    @IBOutlet weak var newRecordingDurationLabel : UILabel!
    @IBOutlet weak var doneButton : UIButton!
    
    @IBOutlet weak var levelLabel1 : UILabel!
    @IBOutlet weak var levelLabel2 : UILabel!
    @IBOutlet weak var levelLabel3 : UILabel!
    @IBOutlet weak var levelLabel4 : UILabel!
    @IBOutlet weak var levelLabel5 : UILabel!
    @IBOutlet weak var levelLabel6 : UILabel!
    @IBOutlet weak var levelLabel7 : UILabel!
    @IBOutlet weak var levelLabel8 : UILabel!
    @IBOutlet weak var levelLabel9 : UILabel!
    @IBOutlet weak var levelLabel10 : UILabel!
    @IBOutlet weak var levelLabel11 : UILabel!
    @IBOutlet weak var levelLabel12 : UILabel!
    @IBOutlet weak var levelLabel13 : UILabel!
    @IBOutlet weak var levelLabel14 : UILabel!
    
    @IBOutlet weak var timeStamp0 : UILabel!
    @IBOutlet weak var timeStamp1 : UILabel!
    @IBOutlet weak var timeStamp2 : UILabel!
    @IBOutlet weak var timeStamp3 : UILabel!
    @IBOutlet weak var timeStamp4 : UILabel!
    @IBOutlet weak var timeStamp5 : UILabel!
    @IBOutlet weak var timeStamp6 : UILabel!
    
    
    @IBOutlet weak var playPauseHeight: NSLayoutConstraint!
    @IBOutlet weak var playPauseWidth: NSLayoutConstraint!
    
    
    
    @IBOutlet weak var topViewWidth: NSLayoutConstraint!
    @IBOutlet weak var topViewHeight: NSLayoutConstraint!
    @IBOutlet weak var tableViewHeight: NSLayoutConstraint!
    @IBOutlet weak var tableViewWidth: NSLayoutConstraint!
    @IBOutlet weak var topViewBottom: NSLayoutConstraint!
    @IBOutlet weak var tableViewTop: NSLayoutConstraint!
    @IBOutlet weak var cellToolBar: UIToolbar!
    
    @IBOutlet weak var timeStamp0Left: NSLayoutConstraint!
    @IBOutlet weak var timeStamp1Left: NSLayoutConstraint!
    @IBOutlet weak var timeStamp2Left: NSLayoutConstraint!
    @IBOutlet weak var timeStamp3Left: NSLayoutConstraint!
    @IBOutlet weak var timeStamp4Left: NSLayoutConstraint!
    @IBOutlet weak var timeStamp5Left: NSLayoutConstraint!
    @IBOutlet weak var timeStamp6Left: NSLayoutConstraint!
    var timeStampCounter : Int = 0
    
    var player2 = AVPlayer()
    
    
    
    
    @IBOutlet weak var recordingDurationLocation: NSLayoutConstraint!


    override func viewDidLoad() {
        super.viewDidLoad()
        
        print("Actual width of view is \(self.view.bounds.width)")
        print("Width of top view is \(self.topView.bounds.width)")
        print("Width of meter is \(self.recordingMeter.bounds.width)")
        
        //set size of play/pause button
        //self.playPauseHeight.constant = 25
        //self.playPauseWidth.constant = 25
        
        //set location of recording duration label
        self.recordingDurationLocation.constant = 5
        
        //set up delegates
        self.tableView.delegate = self
        self.tableView.dataSource = self
        
        self.isRecording = false
        //self.doneButton.hidden = true
        //self.doneButton.enabled = false
        //self.doneButton.titleLabel?.textColor = UIColor.darkGrayColor()
        self.renameFlag = false
        
        //Show navigation bar
        self.navigationController?.setNavigationBarHidden(true  , animated: true )
        
        //Show meter at start
        //Expand Top View
        let height : CGFloat = 280
        self.topViewHeight.constant = self.topViewHeight.constant + height
        
        //Move TableView Down
        self.tableViewTop.constant = self.tableViewTop.constant + height
        
        //Show recording meter
        self.recordingMeter.hidden = false
        
        self.doneButton.hidden = false
        self.doneButton.addTarget(self, action: "collapseOnce", forControlEvents: UIControlEvents.TouchUpInside)
        
        //Set recording label
        if let defaults = NSUserDefaults(suiteName: "group.prophesy") {
            let recordingNumber = defaults.integerForKey("recordingNumber")
            print("Recording Number is \(recordingNumber)")
            if recordingNumber == 0 {
                self.newRecordingLabel.text = "My Recording 1"
            } else {
                self.newRecordingLabel.text = "My Recording " + String(recordingNumber)
            }
            
        }
        
        //set recording date label
        let date = NSDate()
        let formatter = NSDateFormatter()
        formatter.dateStyle = .ShortStyle
        self.newRecordingDateLabel.text = formatter.stringFromDate(date)
        
        self.cropButton.hidden = true
        
        
        //Blue line
        let shapeView = CAShapeLayer()
        shapeView.path = self.createLinePath(CGFloat(2 * self.recordingMeter.counter)).CGPath
        //UIColor.blueColor().setStroke()
        shapeView.strokeColor = UIColor.blueColor().CGColor
        self.recordingMeter.layer.addSublayer(shapeView)
        
        //Blue circle attached to line on top
        let radius : CGFloat = 3.0
        let shapeView2 = CAShapeLayer()
        shapeView2.path = self.circlePathWithCenter(CGPoint(x:  11 + CGFloat(2 * self.recordingMeter.counter), y: 32 - radius), radius: radius).CGPath
        shapeView2.strokeColor = UIColor.blueColor().CGColor
        shapeView2.fillColor = UIColor.blueColor().CGColor
        self.recordingMeter.layer.addSublayer(shapeView2)
        
        //Blue circle attached to line on bottom
        let shapeView3 = CAShapeLayer()
        shapeView3.path = self.circlePathWithCenter(CGPoint(x: 11 + CGFloat(2 * self.recordingMeter.counter), y: self.recordingMeter.bounds.height - 8), radius: radius).CGPath
        shapeView3.fillColor = UIColor.blueColor().CGColor
        shapeView3.strokeColor = UIColor.blueColor().CGColor
        self.recordingMeter.layer.addSublayer(shapeView3)
        
        //Hide recording meter and labels
        /*self.recordingMeter.hidden = true
        self.levelLabel1.hidden = true
        self.levelLabel2.hidden = true
        self.levelLabel3.hidden = true
        self.levelLabel4.hidden = true
        self.levelLabel5.hidden = true
        self.levelLabel6.hidden = true
        self.levelLabel7.hidden = true
        self.levelLabel8.hidden = true
        self.levelLabel9.hidden = true
        self.levelLabel10.hidden = true
        self.levelLabel11.hidden = true
        self.levelLabel12.hidden = true
        self.levelLabel13.hidden = true
        self.levelLabel14.hidden = true
        self.cropButton.hidden = true
        self.meterPlayButton.hidden = true*/
        
        self.timeStamp0.hidden = true
        self.timeStamp1.hidden = true
        self.timeStamp2.hidden = true
        self.timeStamp3.hidden = true
        self.timeStamp4.hidden = true
        self.timeStamp5.hidden = true
        self.timeStamp6.hidden = true
        
        
        
        /*let distance = self.view.bounds.width / 6
        print("distance is \(distance)")
        self.timeStamp0Left.constant = 32
        self.timeStamp1Left.constant = 32 + (1 * distance)
        self.timeStamp2Left.constant = 32 + (2 * distance)
        self.timeStamp3Left.constant = 32 + (3 * distance)
        self.timeStamp4Left.constant = 32 + (4 * distance)
        self.timeStamp5Left.constant = 32 + (5 * distance)
        self.timeStamp6Left.constant = 32 + (6 * distance)*/
        
        
        
        print("width is \(self.view.bounds.width)")
        print("topView width is \(self.topView.bounds.width)")
        print("Recording Meter width is \(self.recordingMeter.width)")
        print("Left constraint is \(self.timeStamp0Left.constant)")
        
        
        
        
        do {
            try self.session.overrideOutputAudioPort(AVAudioSessionPortOverride.Speaker)
        } catch _ {
            print("Couldnt set output to speaker")
        }
        
        self.speaker = true
        
        isPlaying = false
        isPaused = false
        let fetchRequest = NSFetchRequest(entityName: "Memo")
        let sortDescriptor1 = NSSortDescriptor(key: "dateOrder", ascending: false)
        //let sortDescriptor2 = NSSortDescriptor(key: "name", ascending: true)
        fetchRequest.sortDescriptors = [sortDescriptor1]
        
        
        if let managedObjectContext = (UIApplication.sharedApplication().delegate as! AppDelegate).managedObjectContext {
            fetchResultController = NSFetchedResultsController(fetchRequest: fetchRequest, managedObjectContext: managedObjectContext, sectionNameKeyPath: nil, cacheName: nil)
            fetchResultController.delegate = self
            
            
            do {
                try fetchResultController.performFetch()
                
                memos = fetchResultController.fetchedObjects as! [Memo]
                print("Number of total Memos: \(memos.count)")
            } catch  {
                print("Could not retrieve memos")
            }
            
            
            
        }
        
        //setup footer
        //self.tableView.tableFooterView = UIView(frame: CGRectMake(0, 0, tableView.frame.size.width, tableView.frame.size.height - CGFloat((memos.count - 1) * 50)))
        //self.tableView.tableFooterView?.backgroundColor = UIColor.whiteColor()

        // Uncomment the following line to preserve selection between presentations
        // self.clearsSelectionOnViewWillAppear = false

        // Uncomment the following line to display an Edit button in the navigation bar for this view controller.
        // self.navigationItem.rightBarButtonItem = self.editButtonItem()
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

    override func preferredStatusBarStyle() -> UIStatusBarStyle {
        return .LightContent
    }
    
    // MARK: - Customized UITableView Methods

    func numberOfSectionsInTableView(tableView: UITableView) -> Int {
        // #warning Potentially incomplete method implementation.
        // Return the number of sections.
        return 1
    }
    
    func tableView(tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        // #warning Incomplete method implementation.
        // Return the number of rows in the section.
        return self.memos.count
    }
    
    func tableView(tableView: UITableView, cellForRowAtIndexPath indexPath: NSIndexPath) -> UITableViewCell {

        
        print("cell for row at index path")
        
        let cellIdentifier = "Cell"
        let cell = tableView.dequeueReusableCellWithIdentifier(cellIdentifier, forIndexPath: indexPath) as! CustomTableViewCell
        print("cell width is \(cell.frame.width)")
        //configure the cell
        if memos[indexPath.row].name != nil {
            cell.nameLabel.text = memos[indexPath.row].name
        } else {
            print("Memo \(indexPath.row) is \(memos[indexPath.row])")
        }
        
        cell.nameLabel.userInteractionEnabled = false
        cell.nameLabel.enabled = false
        cell.nameLabel.borderStyle = .None
        cell.nameLabel.enablesReturnKeyAutomatically = true
        cell.nameLabel.returnKeyType = UIReturnKeyType.Default
        cell.nameLabel.keyboardAppearance = UIKeyboardAppearance.Default
        cell.nameLabel.keyboardType = UIKeyboardType.Default
        //cell.nameLabel.resignFirstResponder()
        cell.nameLabel.delegate = self
        cell.nameLabel.tag = indexPath.row
       
        cell.durationLabel.text = memos[indexPath.row].duration
        cell.dateLabel.text = memos[indexPath.row].date
        currentSliderValue = Float(memos[indexPath.row].sliderValue)
        
        if isPlaying == true {
            print("cell for row is playing")
            isPaused = false
            //cell.pauseButton.hidden = false
            //cell.playButton.hidden = true
            cell.audioSlider.maximumValue = Float(duration)
            cell.currentTime.text = currentTimeLabel
            cell.timeLeft.text = timeLeftLabel
            
            cell.audioSlider.setValue(Float(player.currentTime), animated: false)
           
            //Animate Slider Bar
            /*if startToPlay == true {
                UIView.animateWithDuration(Double(player.duration) - Double(player.currentTime), delay: 0, options: .AllowUserInteraction, animations: {
                        cell.audioSlider.setValue(Float(self.player.currentTime), animated: true)
                        println("This should only get printed once")
                        self.startToPlay = false
                    }, completion: { _ in
                        cell.audioSlider.setValue(Float(self.player.currentTime), animated: true)})
            }*/
            
        } else if isPaused == true {
            print("cell for row is paused")
            //cell.pauseButton.hidden = true
            //cell.playButton.hidden = false
            cell.currentTime.text = currentTimeLabel
            cell.timeLeft.text = timeLeftLabel
            cell.audioSlider.setValue(Float(player.currentTime), animated: false)
            /*UIView.animateWithDuration(Double(player.duration) - Double(player.currentTime), delay: 0, options: .AllowUserInteraction | .BeginFromCurrentState, animations: {
                cell.audioSlider.setValue(Float(self.duration) - Float(self.player.currentTime), animated: true)
                }, completion: { _ in
                    cell.audioSlider.setValue(Float(self.player.currentTime), animated: true)})*/
        
        } else {
            print("cell for row else")
            //cell.pauseButton.hidden = true
            //cell.playButton.hidden = false
            cell.currentTime.text = "0:00"
            cell.timeLeft.text = "-0:00"
            cell.audioSlider.maximumValue = 10.0
            
            
        }

        //cell.playButton.tag = indexPath.row
        //cell.pauseButton.tag = indexPath.row
        cell.playPauseToggleButton.tag = indexPath.row
        cell.playPauseToggleButton.enabled = false
        cell.playPauseToggleButton.hidden = true
        cell.audioSlider.setThumbImage(UIImage(named: "thumbImage.png"), forState: UIControlState.Normal)
        cell.audioSlider.setMinimumTrackImage(UIImage(named: "barImage3.png"), forState: UIControlState.Normal)
        cell.audioSlider.setMaximumTrackImage(UIImage(named: "barImage3.png"), forState: UIControlState.Normal)
        cell.audioSlider.maximumValue = Float(memos[indexPath.row].durationValue)
        cell.audioSlider.minimumValue = 0.0
        cell.audioSlider.setValue(0, animated: false)
        

        
        //cell.audioSlider.continuous = true
        currentCellIndexPath = indexPath
        
        
        //cell.audioSlider.addTarget(self, action: "playTapped:", forControlEvents: UIControlEvents.ValueChanged)
        //cell.playButton.addTarget(self, action: "playTapped:", forControlEvents: UIControlEvents.TouchDown)
        //cell.pauseButton.addTarget(self, action: "pauseEnabled:", forControlEvents: UIControlEvents.TouchDown)
        
        //cell.recordButton.addTarget(self, action: "recordTapped:", forControlEvents: UIControlEvents.TouchDown)
        //cell.recordButton.addTarget(self, action: "pauseTapped:", forControlEvents: UIControlEvents.TouchUpInside)
        //cell.stopButton.addTarget(self, action: "stopTapped:", forControlEvents: UIControlEvents.TouchUpInside)
        cell.playPauseToggleButton.addTarget(self, action: "playPauseToggle:", forControlEvents: UIControlEvents.TouchDown)
        
        //actions for bar button items
        cell.shareButton.action = Selector("shareTapped:")
        cell.deleteButton.action = Selector("deleteFromBar:")
        cell.editButton.action = Selector("setupAppend:")
        
        cell.audioSlider.addTarget(self, action: "sliderTouched:", forControlEvents: UIControlEvents.TouchDown)
        cell.audioSlider.addTarget(self, action: "sliderDragged:", forControlEvents: UIControlEvents.TouchDragInside)
        
        return cell
        
    }

    func tableView(tableView: UITableView, didSelectRowAtIndexPath indexPath: NSIndexPath) {
        
        
        //check if top view is expanded, if so collapse
        print("Height of topview is \(self.topViewHeight.constant)")
        
        /*if self.topViewHeight.constant > 280 {
            CATransaction.setCompletionBlock {
                print("Collapse Meter First Run")
                //self.collapseMeter()
                self.quickCollapse()
            }
        }*/
        
        tableView.beginUpdates()
        let cell = tableView.cellForRowAtIndexPath(indexPath) as! CustomTableViewCell
        
        CATransaction.begin()
        if self.selectedCellIndexPath != nil {
            
            if self.selectedCellIndexPath.compare(indexPath) == NSComparisonResult.OrderedSame {
                print("selected same cell")
                //print("did you just finish renaming?")
                let frame = self.tableView.rectForRowAtIndexPath(indexPath)
                if frame.height < 100 {
                    print("collapsed cell")
                    CATransaction.setCompletionBlock {
                        print("Grey out")
                        self.greyOut()
                        
                    }
                } else {
                    print("expanded cell")
                }
            } else {
                self.isPaused = false
                cell.audioSlider.setValue(0, animated: false)
                cell.currentTime.text = "0:00"
                print("selected different cell")
                CATransaction.setCompletionBlock {
                    print("Grey out")
                    self.greyOut()
                    
                }
            }
        } else {
            print("first selection")
            cell.audioSlider.setValue(0, animated: false)
            cell.currentTime.text = "0:00"
            self.isPaused = false
            CATransaction.setCompletionBlock {
                print("Grey out")
                if (self.firstRun){
                    self.quickCollapse()
                    self.firstRun = false
                } else {
                    self.greyOut()
                }
                
                
                
            }
        }
        
        
        
        
        
        print("did select \(indexPath.row)")
        selectedCellIndexPath = indexPath
        currentCellIndexPath = indexPath
        
        
        
        //Add tap gesture recognizer
        self.tap2 = UITapGestureRecognizer(target: self, action: "minimizeCell")
        //tableView.addGestureRecognizer(tap2)
        
        
        
        //Enable text field editing
        cell.nameLabel.enabled = true
        cell.nameLabel.userInteractionEnabled = true
        cell.nameLabel.tag = indexPath.row
        
        //cell.audioSlider.setValue(0, animated: false)
        
        cell.audioSlider.hidden = false
        cell.timeLeft.hidden = false
        cell.currentTime.hidden = false
        cell.playPauseToggleButton.hidden = false
        cell.editButton.enabled = true
        cell.deleteButton.enabled = true
        cell.shareButton.enabled = true
        cell.toolBar.hidden = false
        cell.playPauseToggleButton.enabled = true
        cell.playPauseToggleButton.hidden = false
        
        
        //Hide Edit Button
        //self.editButton.hidden = true
        
        self.highlightedCellIndexPath = indexPath
        
        //Make footer grey
        /*self.tableView.tableFooterView?.backgroundColor = UIColor(red: 220/255, green: 220/255, blue: 220/255, alpha: 1)
        self.tableView.backgroundColor = UIColor(red: 220/255, green: 220/255, blue: 220/255, alpha: 1)
        if indexPath.row == 0 {
            self.backgroundView.backgroundColor = UIColor.whiteColor()
        } else {
            self.backgroundView.backgroundColor = UIColor(red: 220/255, green: 220/255, blue: 220/255, alpha: 1)
        }*/
        

        let totalCells = self.memos.count
        print("total cells \(totalCells)")


        
        tableView.endUpdates()
        print("Current index is \(currentCellIndexPath.row)")
        //self.greyOut()
        CATransaction.commit()
        
    }
    
    func tableView(tableView: UITableView, willBeginEditingRowAtIndexPath indexPath: NSIndexPath) {
        print("Editing has begun")
        tableView.beginUpdates()
        
        let cell = tableView.cellForRowAtIndexPath(indexPath) as! CustomTableViewCell
        cell.audioSlider.hidden = true
        cell.timeLeft.hidden = true
        cell.currentTime.hidden = true
        cell.playPauseToggleButton.hidden = true
        cell.editButton.enabled = false
        cell.deleteButton.enabled = false
        cell.shareButton.enabled = false
        cell.toolBar.hidden = true
        cell.nameLabel.enabled = false
        
        self.collapseCell = true
        
        tableView.endUpdates()
    }
    
    func tableView(tableView: UITableView, didDeselectRowAtIndexPath indexPath: NSIndexPath) {
        print("did deselect \(indexPath.row)")
        
        tableView.beginUpdates()
        
        let cell = tableView.cellForRowAtIndexPath(indexPath) as! CustomTableViewCell
        cell.nameLabel.enabled = false
        cell.nameLabel.userInteractionEnabled = false
        
        //Unhide Edit Button
        //self.editButton.hidden = false
        
        //Stop player if playing
        if self.player != nil {
            if self.player.playing {
                print("player stopped because new cell selected")
                self.player.stop()
                timer.invalidate()
                cell.audioSlider.setValue(0, animated: false)
                isPaused = false
                isPlaying = false
            }
        }
        
        
        //Make footer grey
        self.tableView.tableFooterView?.backgroundColor = UIColor.whiteColor()
        self.tableView.backgroundColor = UIColor.whiteColor()
        
        //revert cell color
        let totalCells = self.memos.count
        print("total cells \(totalCells)")
        //println("current selected is \(self.tableView.indexPathForSelectedRow())")
        self.backgroundView.backgroundColor = UIColor.whiteColor()
        for var i = 0; i < totalCells; i++ {
            let tempIndex = NSIndexPath(forRow: i, inSection: 0)
            //println("tempIndex is \(tempIndex)")
            let visible = tableView.indexPathsForVisibleRows
            if tempIndex != self.tableView.indexPathForSelectedRow {
                if let found = visible!.indexOf(tempIndex) {
                    print("Found is \(found)")
                    let tempCell = self.tableView.cellForRowAtIndexPath(tempIndex) as! CustomTableViewCell
                    tempCell.dateLabel.textColor = UIColor.blackColor()
                    tempCell.durationLabel.textColor = UIColor.blackColor()
                    tempCell.nameLabel.textColor = UIColor.blackColor()
                    tempCell.backgroundColor = UIColor.whiteColor()
                }
            }
            
        }
        
        tableView.endUpdates()
    }
    
    func tableView(tableView: UITableView, heightForRowAtIndexPath indexPath: NSIndexPath) -> CGFloat {
        
        if (selectedCellIndexPath != nil) && (self.collapseCell == false) && (selectedCellIndexPath.compare(indexPath) == NSComparisonResult.OrderedSame) {
            print("height for cell \(indexPath.row) will be 140")
            let test1 = (selectedCellIndexPath != nil)
            let test2 = (self.collapseCell == false)
            let test3 = (selectedCellIndexPath.compare(indexPath) == NSComparisonResult.OrderedSame)
            
            print("Test 1 \(test1), test 2 \(test2), test 3 \(test3)")
            
            return 140
        } else {
            print("height for cell \(indexPath.row) will be 53")
            heightCounter++
            //print("Height counter is \(heightCounter) and count is \(self.memos.count)")
            if indexPath.row == (self.memos.count - 1) {
                self.collapseCell = false
                heightCounter = 0
                if self.highlightedCellIndexPath != nil {
                    //self.greyOut()
                }
                
            }
            
            return 53
        }
    }
    
    func tableView(tableView: UITableView, editingStyleForRowAtIndexPath indexPath: NSIndexPath) -> UITableViewCellEditingStyle {
        if currentCellIndexPath == indexPath {
            return UITableViewCellEditingStyle.None
        }
        return UITableViewCellEditingStyle.Delete
    }
    
    func tableView(tableView: UITableView, didEndEditingRowAtIndexPath indexPath: NSIndexPath) {
        print("editing finished")
        self.collapseCell = false
    }
    
    func tableView(tableView: UITableView, commitEditingStyle editingStyle: UITableViewCellEditingStyle, forRowAtIndexPath indexPath: NSIndexPath) {
        if editingStyle == .Delete {
            
            //Delete File
            let outNames = self.getListOfOutNames()
            
            if outNames.contains(self.memos[indexPath.row].name){
                //Dont delete
                print("Not deleting since associate with multiple out")
            } else {
                let fileToDelete = self.memos[indexPath.row].file
                self.deleteFile(fileToDelete)
            }
            
            
            
            //Delete Core Data Object
            if let managedObjectContext = (UIApplication.sharedApplication().delegate as! AppDelegate).managedObjectContext {
                let memoToDelete = self.fetchResultController.objectAtIndexPath(indexPath) as! Memo
                managedObjectContext.deleteObject(memoToDelete)
                
                do {
                    try managedObjectContext.save()
                } catch {
                    fatalError("Failure to save context: \(error)")
                }
            }
        }
        
        
        
        //for debug purposes
        print("Total items: \(self.memos.count)")
    }
    
    func tableView(tableView: UITableView, canEditRowAtIndexPath indexPath: NSIndexPath) -> Bool {
        
        return true
    }

    
    //MARK: - Custom Methods Not UITableview
    
    
    //MARK: functions related to recording meter
    
    func greyOut(){
        print("Grey out called")
        let cell = tableView.cellForRowAtIndexPath(self.highlightedCellIndexPath) as! CustomTableViewCell
        let rectOfCellInTableView = self.tableView.rectForRowAtIndexPath(self.highlightedCellIndexPath)
        let rectOfCellInSuperview = self.tableView.convertRect(rectOfCellInTableView, toView: tableView.superview)
        
        print("Current position of cell is \(rectOfCellInSuperview.origin.y)")
        
        let viewWidth = self.view.bounds.width
        //let rowHeight = 53
        let expandedRowHeight : CGFloat = 140
        
        var firstTime : CGFloat = 280
        if (!firstRun){
            firstTime = 0
        }
        
        self.viewAbove = UIView(frame: CGRectMake(0, self.topView.bounds.height - firstTime, viewWidth, (rectOfCellInSuperview.origin.y - (self.topView.bounds.height))))
        self.viewBelow = UIView(frame: CGRectMake(0, self.topView.bounds.height - firstTime + (rectOfCellInSuperview.origin.y - (self.topView.bounds.height)) + expandedRowHeight, viewWidth, self.view.bounds.height - (cell.frame.origin.y + expandedRowHeight) ))
        
        self.viewAbove.backgroundColor = UIColor.lightGrayColor().colorWithAlphaComponent(0.5)
        self.viewBelow.backgroundColor = UIColor.lightGrayColor().colorWithAlphaComponent(0.5)
        self.tapToCollapse = UITapGestureRecognizer(target: self, action: "minimizeCell")
        self.tapToCollapse2 = UITapGestureRecognizer(target: self, action: "minimizeCell")
        self.viewAbove.addGestureRecognizer(self.tapToCollapse)
        self.viewBelow.addGestureRecognizer(self.tapToCollapse2)
        
        
        self.view.addSubview(self.viewBelow)
        
        if (rectOfCellInSuperview.origin.y - self.topView.bounds.height) > 5 {
            self.view.addSubview(self.viewAbove)
        }
        
        
        self.tableView.scrollEnabled = false
        
        //Add view over recording meter that is black but alpha set to 0.5
        self.recordingOverview = UIView(frame: CGRectMake(0, 55, self.view.bounds.width, 100))
        self.recordingOverview.backgroundColor = UIColor.blackColor().colorWithAlphaComponent(0.5)
        self.view.addSubview(self.recordingOverview)
        
        UIView.animateWithDuration(0.3, delay: 0.0, options: UIViewAnimationOptions.CurveEaseIn, animations: {
            self.viewAbove.backgroundColor = UIColor.lightGrayColor().colorWithAlphaComponent(0.5)
            self.viewBelow.backgroundColor = UIColor.lightGrayColor().colorWithAlphaComponent(0.5)
            self.recordingOverview.backgroundColor = UIColor.blackColor().colorWithAlphaComponent(0.5)
            
            }, completion: { finished in
                
        })
    }
    
    @IBAction func recordButtonToggle(){
        print("recordButtonToggle isRecordButton is \(self.recordButton.isRecordButton)")
        var height : CGFloat = 280
        self.cropButton.hidden = false
        
        if self.recordButton.isRecordButton == true {
            self.doneButton.enabled = false
            self.selectedCellIndexPath = nil
            self.doneButton.removeTarget(self, action: "collapseOnce", forControlEvents: UIControlEvents.TouchUpInside)
            self.doneButton.addTarget(self, action: "donePressed", forControlEvents: UIControlEvents.TouchUpInside)
            
            UIView.animateWithDuration(0.4, delay: 0.0, options: UIViewAnimationOptions.CurveLinear, animations: {
                self.recordButton.alpha = 0.0
                }, completion: { finished in
                    print("animation completed, isRecording: \(self.isRecording), firstRun: \(self.firstRun) ")
                    self.recordButton.isRecordButton = false
                    self.recordButton.alpha = 1.0
                    
                    
                
                    
                    if (self.isRecording == false) && (!self.firstRun){
                        
                        //Move TableView Down
                        //self.tableViewHeight.constant = self.tableViewHeight.constant - height
                        self.tableViewTop.constant = self.tableViewTop.constant + height
                        
                        //Expand Top View
                        self.topViewHeight.constant = self.topViewHeight.constant + height
                        //self.topViewBottom.constant = self.topViewBottom.constant - height
                        
                        //Rename top Label
                        self.topLabel.text = "Record"
                        
                        //Unhide recording meter
                        self.recordingMeter.hidden = false
                        self.levelLabel1.hidden = false
                        self.levelLabel2.hidden = false
                        self.levelLabel3.hidden = false
                        self.levelLabel4.hidden = false
                        self.levelLabel5.hidden = false
                        self.levelLabel6.hidden = false
                        self.levelLabel7.hidden = false
                        self.levelLabel8.hidden = false
                        self.levelLabel9.hidden = false
                        self.levelLabel10.hidden = false
                        self.levelLabel11.hidden = false
                        self.levelLabel12.hidden = false
                        self.levelLabel13.hidden = false
                        self.levelLabel14.hidden = false
                        
                        let distance = self.recordingMeter.frame.width / 6
                        print("frame is \(self.recordingMeter.frame.width), distance is \(distance)")
                        //let startPoint : CGFloat = 36
                        /*self.timeStamp0Left.constant = startPoint
                        self.timeStamp1Left.constant = startPoint + (1 * distance)
                        self.timeStamp2Left.constant = startPoint + (2 * distance)
                        self.timeStamp3Left.constant = startPoint + (3 * distance)
                        self.timeStamp4Left.constant = startPoint + (4 * distance)
                        self.timeStamp5Left.constant = startPoint + (5 * distance)
                        self.timeStamp6Left.constant = startPoint + (6 * distance)
                        
                        
                        self.timeStamp0.hidden = false
                        self.timeStamp1.hidden = false
                        self.timeStamp2.hidden = false
                        self.timeStamp3.hidden = false
                        self.timeStamp4.hidden = false
                        self.timeStamp5.hidden = false
                        self.timeStamp6.hidden = false*/
                        
                        
                        
                    } else {
                        self.firstRun = false
                        height = 0
                    }
                    
                    self.doneButton.hidden = false
                    
                    self.cropButton.hidden = false
                    self.cropButtonOverview = UIView(frame: CGRectMake(0, 0, self.cropButton.frame.width, self.cropButton.frame.height))
                    self.cropButtonOverview.backgroundColor = UIColor.blackColor().colorWithAlphaComponent(0.5)
                    self.cropButton.addSubview(self.cropButtonOverview)
                    
                    self.meterPlayButton.hidden = false
                    self.meterPlayButtonOverview = UIView(frame: CGRectMake(0, 0, self.meterPlayButton.frame.width, self.meterPlayButton.frame.height))
                    self.meterPlayButtonOverview.backgroundColor = UIColor.blackColor().colorWithAlphaComponent(0.5)
                    self.meterPlayButton.addSubview(self.meterPlayButtonOverview)
                    
                    print("Should add bottom view \(self.view.bounds.height - (self.topView.bounds.height + height))")
                    print("view height: \(self.view.bounds.height)")
                    print("topview height: \(self.topView.bounds.height)")
                    let bottomViewHeight = self.view.bounds.height - (self.topView.bounds.height + height)
                    self.tableOverview = UIView(frame: CGRectMake(0, self.topView.bounds.height + height, self.view.bounds.width, bottomViewHeight))
                    self.tableOverview.backgroundColor = UIColor.lightGrayColor().colorWithAlphaComponent(0.5)
                    self.view.addSubview(self.tableOverview)
                    
                    self.speakerButton.enabled = false
                    
                    
                    //start recording
                    self.recordTapped()
                    
                    self.timerCounter = 0
                    self.recordingTimer = NSTimer.scheduledTimerWithTimeInterval(0.01, target: self, selector: "updateRecordingDuration", userInfo: nil, repeats: true)
                    
                    self.editButton.hidden = true
                    
                    if let defaults = NSUserDefaults(suiteName: "group.prophesy") {
                        let recordingNumber = defaults.integerForKey("recordingNumber")
                        print("Recording Number is \(recordingNumber)")
                        if recordingNumber == 0 {
                            self.newRecordingLabel.text = "My Recording 1"
                        } else {
                            self.newRecordingLabel.text = "My Recording " + String(recordingNumber)
                        }
                        
                    }
                    
                    let date = NSDate()
                    let formatter = NSDateFormatter()
                    formatter.dateStyle = .ShortStyle
                    self.newRecordingDateLabel.text = formatter.stringFromDate(date)
            
            })
            print("animation should have completed, recording meter should be visible")
            
            
        } else {
            print("pause recording")
            //pause recording
            self.recorder.pause()
            
            //enable done button
            self.doneButton.enabled = true
            
            //make crop and play regular colored
            self.cropButtonOverview.removeFromSuperview()
            self.meterPlayButtonOverview.removeFromSuperview()
            
            //invalidate timer
            self.recordingTimer.invalidate()
            
            //stop the display link
            //self.displayLink.removeFromRunLoop(NSRunLoop.mainRunLoop(), forMode: NSRunLoopCommonModes)
            self.displayLink.paused = true
            self.recordButton.isRecordButton = true
            
            self.recordingPaused = true
        }
    }
    
    func donePressed(){
        //Preset alert with text field and two options: Delete and Save
        //self.stopTapped()
        //self.savePressed()
        self.doneButton.enabled = false
        
        self.cropButton.hidden = true
        
        self.isRecording = false
        self.speakerButton.enabled = true
        self.recordingMeter.offset = 0
        
        let alertController = UIAlertController(title: "Save Voice Memo", message: nil, preferredStyle: UIAlertControllerStyle.Alert)
        
        alertController.addTextFieldWithConfigurationHandler({ (textField : UITextField) in
            if let textField = alertController.textFields?.first {
                if let defaults = NSUserDefaults(suiteName: "group.prophesy") {
                    let recordingNumber = defaults.integerForKey("recordingNumber")
                    print("Recording Number is \(recordingNumber)")
                    if recordingNumber > 0 {
                        self.textToPresent = "My Recording " + String(recordingNumber)
                        defaults.setInteger(recordingNumber + 1 , forKey: "recordingNumber")
                        defaults.synchronize()
                    } else {
                        self.textToPresent = "My Recording " + String(1)
                        defaults.setInteger(2 , forKey: "recordingNumber")
                        defaults.synchronize()
                    }
                }
                textField.text = self.textToPresent
                textField.placeholder = self.textToPresent
                textField.clearButtonMode = UITextFieldViewMode.WhileEditing
                
                
            }
        })
        
        let deleteAction = UIAlertAction(title: "Delete", style: .Cancel) { (action) in
            print("delete selected")
            let filename = self.recordingTitle
            let deleteController = UIAlertController(title: "Delete Recording", message: "Are you sure you want to delete\n\"\(self.textToPresent)\"?", preferredStyle: UIAlertControllerStyle.Alert)
            let cancelDeleteAction = UIAlertAction(title: "Cancel", style: .Cancel, handler: { (action) in
                //Cancel Delete
                self.presentViewController(alertController, animated: true){}
                self.doneButton.enabled = true
            })
            let deleteConfirmAction = UIAlertAction(title: "Delete", style: UIAlertActionStyle.Destructive, handler: { (action) in
                print("user confirms delete")
                self.deletePressed(filename)
                self.collapseMeter()
            })
            
            deleteController.addAction(cancelDeleteAction)
            deleteController.addAction(deleteConfirmAction)
            
            self.presentViewController(deleteController, animated: true, completion: nil)
            
        }
        alertController.addAction(deleteAction)
        
        let saveAction = UIAlertAction(title: "Save", style: .Default) { (action) in
            print("save selected")
            if let textField = alertController.textFields?.first {
                self.textToPresent = textField.text
                if self.textToPresent.isEmpty {
                    self.textToPresent = textField.placeholder
                }
            }
            
            
            
            print("name to be saved is \(self.textToPresent)")
            self.savePressed()
        }
        alertController.addAction(saveAction)
        
        self.presentViewController(alertController, animated: true) {
            
        }
    }
    
    func deletePressed(filename : String!){
        self.deleteFile(filename)
    }
    
    func collapseOnce(){
        self.collapseMeter()

        self.doneButton.removeTarget(self, action: "collapseOnce", forControlEvents: UIControlEvents.TouchUpInside)
        self.doneButton.addTarget(self, action: "donePressed", forControlEvents: UIControlEvents.TouchUpInside)
    }
    
    func savePressed(){

        self.collapseMeter()
        
        //stop recording
        self.stopTapped()
        
        self.recordingTimer.invalidate()
    }
    
    func quickCollapse(){
        print("quick collapse")
        
        let height : CGFloat = 280
        self.recordButton.isRecordButton = true
        //Move TableView Up
        //self.topViewBottom.constant = self.topViewBottom.constant + height
        self.topViewHeight.constant = self.topViewHeight.constant - height
        
        //Collapse Top View
        self.tableViewTop.constant = self.tableViewTop.constant - height
        //self.tableViewHeight.constant = self.tableViewHeight.constant + height
        
        //Rename top Label
        self.topLabel.text = "Voice Memos"
        
        //Hide recording meter
        self.recordingMeter.hidden = true
        self.levelLabel1.hidden = true
        self.levelLabel2.hidden = true
        self.levelLabel3.hidden = true
        self.levelLabel4.hidden = true
        self.levelLabel5.hidden = true
        self.levelLabel6.hidden = true
        self.levelLabel7.hidden = true
        self.levelLabel8.hidden = true
        self.levelLabel9.hidden = true
        self.levelLabel10.hidden = true
        self.levelLabel11.hidden = true
        self.levelLabel12.hidden = true
        self.levelLabel13.hidden = true
        self.levelLabel14.hidden = true
        self.editButton.hidden = false
        self.cropButton.hidden = true
        self.meterPlayButton.hidden = true
        self.doneButton.hidden = true
        
        self.timeStamp0.hidden = true
        self.timeStamp0.text = "00:00"
        self.timeStamp1.hidden = true
        self.timeStamp1.text = "00:01"
        self.timeStamp2.hidden = true
        self.timeStamp2.text = "00:02"
        self.timeStamp3.hidden = true
        self.timeStamp3.text = "00:03"
        self.timeStamp4.hidden = true
        self.timeStamp4.text = "00:04"
        self.timeStamp5.hidden = true
        self.timeStamp5.text = "00:05"
        self.timeStamp6.hidden = true
        self.timeStamp6.text = "00:06"
        
        self.timeStamp0Left.constant = 40
        self.timeStamp1Left.constant = 100
        self.timeStamp2Left.constant = 160
        self.timeStamp3Left.constant = 220
        self.timeStamp4Left.constant = 280
        self.timeStamp5Left.constant = 340
        self.timeStamp6Left.constant = 400
        
        self.timeStampCounter = 0
        self.recordingDurationLocation.constant = 5
        
        self.greyOut()
    }
    
    func collapseMeter(){
        let height : CGFloat = 280
        self.recordButton.isRecordButton = true
        
        UIView.animateWithDuration(0.4, delay: 0, options: [.AllowUserInteraction, .CurveEaseIn], animations: {
            self.recordButton.alpha = 0.9
            }, completion: { _ in
                print("animation completed")
                self.recordButton.alpha = 1.0
                //Move TableView Up
                //self.topViewBottom.constant = self.topViewBottom.constant + height
                self.topViewHeight.constant = self.topViewHeight.constant - height
                
                //Collapse Top View
                self.tableViewTop.constant = self.tableViewTop.constant - height
                //self.tableViewHeight.constant = self.tableViewHeight.constant + height
                
                //Rename top Label
                self.topLabel.text = "Voice Memos"
                
                //Hide recording meter
                self.recordingMeter.hidden = true
                self.levelLabel1.hidden = true
                self.levelLabel2.hidden = true
                self.levelLabel3.hidden = true
                self.levelLabel4.hidden = true
                self.levelLabel5.hidden = true
                self.levelLabel6.hidden = true
                self.levelLabel7.hidden = true
                self.levelLabel8.hidden = true
                self.levelLabel9.hidden = true
                self.levelLabel10.hidden = true
                self.levelLabel11.hidden = true
                self.levelLabel12.hidden = true
                self.levelLabel13.hidden = true
                self.levelLabel14.hidden = true
                self.editButton.hidden = false
                self.cropButton.hidden = true
                self.meterPlayButton.hidden = true
                self.doneButton.hidden = true
                
                self.timeStamp0.hidden = true
                self.timeStamp0.text = "00:00"
                self.timeStamp1.hidden = true
                self.timeStamp1.text = "00:01"
                self.timeStamp2.hidden = true
                self.timeStamp2.text = "00:02"
                self.timeStamp3.hidden = true
                self.timeStamp3.text = "00:03"
                self.timeStamp4.hidden = true
                self.timeStamp4.text = "00:04"
                self.timeStamp5.hidden = true
                self.timeStamp5.text = "00:05"
                self.timeStamp6.hidden = true
                self.timeStamp6.text = "00:06"
                
                self.timeStamp0Left.constant = 40
                self.timeStamp1Left.constant = 100
                self.timeStamp2Left.constant = 160
                self.timeStamp3Left.constant = 220
                self.timeStamp4Left.constant = 280
                self.timeStamp5Left.constant = 340
                self.timeStamp6Left.constant = 400
                
                self.timeStampCounter = 0
                
                if !self.firstRun {
                    self.tableOverview.removeFromSuperview()
                    self.tableView.reloadData()
                } else {
                    self.firstRun = false
                }
                
                self.recordingMeter.timeStamps = ["00:00", "00:01", "00:02", "00:03", "00:04", "00:05"]
                self.recordingMeter.timeStampCounter = 5
                
                self.recordingDurationLocation.constant = 5
            })
        
        //self.tableView.reloadData()
        
        
    }
    
    @IBAction func speakerToggle(){
        print("speaker toggle")
        
        if self.speaker == true {
            self.speaker = false
            self.speakerButton.titleLabel?.textColor = UIColor.blueColor()
            if player != nil {
                if player.playing {
                    do {
                        try self.session.overrideOutputAudioPort(AVAudioSessionPortOverride.None)
                    } catch _ {
                    }
                }
            }
        } else {
            self.speaker = true
            self.speakerButton.titleLabel?.textColor = UIColor.whiteColor()
            if player.playing {
                do {
                    try self.session.overrideOutputAudioPort(AVAudioSessionPortOverride.Speaker)
                } catch _ {
                }
            }
        }
    }
    
    func updateRecordingDuration(){
        //println("func updateRecordingDuration")
        //Set duration label
        self.newRecordingDurationLabel.text = stringFromTimeIntervalWithMS(self.recorder.currentTime, needMinuteZero: true)
        self.timerCounter = self.timerCounter + 1
        
    }
    
    func pauseTapped(recordButton: UIButton!){
        recorder.pause()
        recordButton.setTitle("Record", forState: .Normal)
    }
    
    func recordTapped(){
        
        if isRecording == true {
            recorder.record()
            //self.displayLink = CADisplayLink(target: self, selector: "recordTimerTask:")
            //self.displayLink.frameInterval = 2
            //self.displayLink.addToRunLoop(NSRunLoop.mainRunLoop(), forMode: NSRunLoopCommonModes)
            self.displayLink.paused = false
            
        } else {
            //Setup File Name
            let date = NSDate()
            let formatter = NSDateFormatter()
            formatter.dateFormat = "yyyy-MM-dd_hh_mm_ss"
            recordingDate = formatter.stringFromDate(date)
            
            path = NSSearchPathForDirectoriesInDomains(.DocumentDirectory, .UserDomainMask, true)[0] as NSString as String
            recordingTitle = "recording_" + recordingDate + ".m4a"
            fullpath = path + "/" + recordingTitle
            
            print("String is \(path)")
            
            
            
            // Setup Audio Session
            soundFileURL = NSURL(fileURLWithPath: fullpath)
            session = AVAudioSession.sharedInstance()
            do {
                try session.setCategory("AVAudioSessionCategoryPlayAndRecord")
            } catch _ {
            }
            
            
            var error: NSError?
            do {
                recorder = try AVAudioRecorder(URL: soundFileURL, settings: recordSettings )
            } catch let error1 as NSError {
                error = error1
                recorder = nil
            }
            if let e = error {
                print(e.localizedDescription)
            } else {
                //recorder.delegate = self
                recorder.meteringEnabled = true
                recorder.prepareToRecord() // creates/overwrites the file at soundFileURL
                isRecording = true
                print("Ready to record!")
                do {
                    try session.setActive(true )
                } catch _ {
                }
                recorder.record()
                //recordButton.setTitle("Pause", forState: .Normal)
                print("We are recording!")
                //let size  = Int(floor(self.recordingMeter.frame.width/2))
                
                self.levelArray = []
                self.recordingMeter.levelArray = [Float](count: 85, repeatedValue: 0.0)
                //self.recordingMeter.number = size
                self.recordingMeter.counter = 0
                self.displayLink = CADisplayLink(target: self, selector: "recordTimerTask:")
                self.displayLink.frameInterval = 2
                self.displayLink.addToRunLoop(NSRunLoop.mainRunLoop(), forMode: NSRunLoopCommonModes)
            }
        }
        
    }
    
    func recordTimerTask(sender : AnyObject!) {
        self.recorder.updateMeters()
        
        //Items for minimal meter
        let level = self.recorder.averagePowerForChannel(0)
        //println("Level added is \(level)")
        
        self.levelArray.append(level)
        
        
        
        //call method in view controller to update drawing
        self.updateMeter()
        
    }
    
    func updateMeter(){
        
        if self.recordingMeter.counter > 2 {
            for layer in self.recordingMeter.layer.sublayers! {
                layer.removeFromSuperlayer()
            }
        }
        //Items for RecordingMeter Object
        //println("level is \(records.levelArray[self.recordingMeter.counter])")
        if self.recordingMeter.counter < 85 {
            self.recordingMeter.levelArray[self.recordingMeter.counter] = self.levelArray[self.recordingMeter.counter]
            
            //move recording duration label
            if self.recordingDurationLocation.constant  < ((self.view.bounds.width/2) - (self.newRecordingDurationLabel.frame.width/2)) {
                self.recordingDurationLocation.constant = self.recordingDurationLocation.constant + 1.5
            }
            
    
            
        } else {
            //Add new value to the end and remove from the front. Like a shift register
            self.recordingMeter.levelArray.append(self.levelArray[self.recordingMeter.counter])
            self.recordingMeter.levelArray.removeAtIndex(0)
            
            //Move recording duration label
            self.recordingDurationLocation.constant = (self.view.bounds.width/2) - (self.newRecordingDurationLabel.frame.width/2) - 2//(self.recordingMeter.frame.width/2) - (self.newRecordingDurationLabel.frame.width/2) + 4
            
            //Move timestamps
            //print("meter frame width is: \(self.recordingMeter.frame.width)")
            //let offScreen : CGFloat = -51
            /*if self.timeStamp0Left.constant < offScreen {
                self.timeStamp0Left.constant = self.view.bounds.width + padding
                self.timeStampCounter += 7
                self.timeStamp0.text = self.stringToTimeStamp(self.timeStampCounter, offset: 0)
            } else {
                self.timeStamp0Left.constant = self.timeStamp0Left.constant - 2
            }
            
            if self.timeStamp1Left.constant < offScreen {
                self.timeStamp1Left.constant = self.view.bounds.width + padding
                self.timeStamp1.text = self.stringToTimeStamp(self.timeStampCounter, offset: 1)
            } else {
                self.timeStamp1Left.constant = self.timeStamp1Left.constant - 2
            }
            
            if self.timeStamp2Left.constant < offScreen {
                self.timeStamp2Left.constant = self.view.bounds.width + padding
                self.timeStamp2.text = self.stringToTimeStamp(self.timeStampCounter, offset: 2)
            } else {
                self.timeStamp2Left.constant = self.timeStamp2Left.constant - 2
            }
            
            if self.timeStamp3Left.constant < offScreen {
                self.timeStamp3Left.constant = self.view.bounds.width + padding
                self.timeStamp3.text = self.stringToTimeStamp(self.timeStampCounter, offset: 3)
            } else {
                self.timeStamp3Left.constant = self.timeStamp3Left.constant - 2
            }
            
            if self.timeStamp4Left.constant < offScreen {
                self.timeStamp4Left.constant = self.view.bounds.width + padding
                self.timeStamp4.text = self.stringToTimeStamp(self.timeStampCounter, offset: 4)
            } else {
                self.timeStamp4Left.constant = self.timeStamp4Left.constant - 2
            }
            
            if self.timeStamp5Left.constant < offScreen {
                self.timeStamp5Left.constant = self.view.bounds.width + padding
                self.timeStamp5.text = self.stringToTimeStamp(self.timeStampCounter, offset: 5)
            } else {
                self.timeStamp5Left.constant = self.timeStamp5Left.constant - 2
            }
            
            if self.timeStamp6Left.constant < offScreen {
                self.timeStamp6Left.constant = self.view.bounds.width + padding
                self.timeStamp6.text = self.stringToTimeStamp(self.timeStampCounter, offset: 6)
                self.offScreen = self.offScreen + 1
                self.padding = self.padding + 1
            } else {
                self.timeStamp6Left.constant = self.timeStamp6Left.constant - 2
            }
            */
            
            
        }
        
        
        //Blue line
        let shapeView = CAShapeLayer()
        shapeView.strokeColor = UIColor.blueColor().CGColor
        shapeView.fillColor = UIColor.blueColor().CGColor
        shapeView.path = self.createLinePath(CGFloat(2 * self.recordingMeter.counter)).CGPath
        self.recordingMeter.layer.addSublayer(shapeView)
        
        //Blue circle attached to line on top
        let radius : CGFloat = 3.0
        let shapeView2 = CAShapeLayer()
        shapeView2.strokeColor = UIColor.blueColor().CGColor
        shapeView2.fillColor = UIColor.blueColor().CGColor
        shapeView2.path = self.circlePathWithCenter(CGPoint(x:  11 + CGFloat(2 * self.recordingMeter.counter), y: 32 - radius), radius: radius).CGPath
        self.recordingMeter.layer.addSublayer(shapeView2)
        
        //Blue circle attached to line on bottom
        let shapeView3 = CAShapeLayer()
        shapeView3.strokeColor = UIColor.blueColor().CGColor
        shapeView3.fillColor = UIColor.blueColor().CGColor
        shapeView3.path = self.circlePathWithCenter(CGPoint(x: 11 + CGFloat(2 * self.recordingMeter.counter), y: self.recordingMeter.bounds.height - 8), radius: radius).CGPath
        self.recordingMeter.layer.addSublayer(shapeView3)
        
        
        self.view.setNeedsDisplay()
        
    
        self.recordingMeter.counter++
    }
    
    func createLinePath(x : CGFloat) -> UIBezierPath{
        let blueLinePath = UIBezierPath()
        var xComponent : CGFloat = 1
        if x > (self.recordingMeter.bounds.width/2 - 11) {
            xComponent = self.recordingMeter.bounds.width/2 - 11
        } else {
            xComponent = x
        }
        blueLinePath.moveToPoint(CGPoint(x: 11 + xComponent, y: 32))
        blueLinePath.addLineToPoint(CGPoint(x: 11 + xComponent, y: self.recordingMeter.bounds.height - 10))
        blueLinePath.closePath()
        UIColor.orangeColor().setStroke()
        blueLinePath.stroke()
        return blueLinePath
    }
    
    func circlePathWithCenter(center: CGPoint, radius: CGFloat) -> UIBezierPath {
        let circlePath = UIBezierPath()
        
        var component : CGPoint = center
        if center.x > ((2 * radius) + self.recordingMeter.bounds.width/2 - 6 ) {
            component.x = (2 * radius) + self.recordingMeter.bounds.width/2 - 6
        } else {
            component.x = center.x
        }
        
        circlePath.addArcWithCenter(component, radius: radius, startAngle: -CGFloat(M_PI), endAngle: -CGFloat(M_PI/2), clockwise: true)
        circlePath.addArcWithCenter(component, radius: radius, startAngle: -CGFloat(M_PI/2), endAngle: 0, clockwise: true)
        circlePath.addArcWithCenter(component, radius: radius, startAngle: 0, endAngle: CGFloat(M_PI/2), clockwise: true)
        circlePath.addArcWithCenter(component, radius: radius, startAngle: CGFloat(M_PI/2), endAngle: CGFloat(M_PI), clockwise: true)
        circlePath.closePath()
        return circlePath
    }
    
    
    //MARK : functions related to the cells in the tableview

    func stopPlaying(){
        //Stop player if playing
        if self.player != nil {
            
            if self.player.playing {
                let cell = tableView.cellForRowAtIndexPath(currentCellIndexPath) as! CustomTableViewCell
                print("player stopped because new cell selected")
                self.player.stop()
                timer.invalidate()
                currentSliderValue = 0
                cell.audioSlider.setValue(0, animated: false)
                isPaused = false
                isPlaying = false
                cell.playPauseToggleButton.isPlayButton = true
            }
        }
    }
    
    func shareTapped(shareButton: UIBarButtonItem!){
        
        if self.player != nil {
            if player.playing {
                player.stop()
                isPaused = false
            }
        }
        print("share tapped")
        
        let activityViewController = self.createActivityController()
        print("present activity view controller")
        presentViewController(activityViewController, animated: true, completion: nil)
        //self.navigationController?.presentViewController(activityViewController, animated: true, completion: nil)
    }
    
    func createActivityController() -> UIActivityViewController {
        
        let recordingFile:NSURL = fileToURL()
        print("Recording file is \(recordingFile)")

        self.activityArray = [recordingFile]
        
        // let's add a String and an NSURL
        let activityViewController = UIActivityViewController(
            activityItems: self.activityArray,
            applicationActivities: nil)
        
        
        //activityViewController.completionWithItemsHandler = doneSharingHandler
        activityViewController.completionWithItemsHandler = {
            (activityType, completed, returnedItems, error) in
            print("Activity: \(activityType) Success: \(completed) Items: \(returnedItems) Error: \(error)")
            var error: NSError?
            let displayName = self.memos[self.currentCellIndexPath.row].name
            let currentPath = NSSearchPathForDirectoriesInDomains(.DocumentDirectory, .UserDomainMask, true)[0] as NSString
            let filePath2 = (currentPath as String) + "/" + displayName + ".m4a"
            
            //let's attempt to rename file to what is listed in the name rather than the original filename
            let filemgr = NSFileManager.defaultManager()
            
            
            do {
                try filemgr.removeItemAtPath(filePath2)
                print("Remove successful")
            } catch let error1 as NSError {
                error = error1
                print("Remove failed: \(error!.localizedDescription)")
            }
            
            if !completed {
                print("cancelled")
                //activityArray = []
                
                return
            }
            
            if activityType == UIActivityTypePostToTwitter {
                print("twitter")
                
            }
            
            if activityType == UIActivityTypeMail {
                print("mail")
                
            }
            
            if activityType == UIActivityTypePostToFacebook {
                print("facebook")
                
            }
            
            if activityType == UIActivityTypeMessage {
                print("sms")
                
            }
        }
        
        
        // you can specify these if you'd like.
        activityViewController.excludedActivityTypes =  [
            UIActivityTypePrint,
            UIActivityTypeCopyToPasteboard,
            UIActivityTypeAssignToContact,
            UIActivityTypeSaveToCameraRoll,
            UIActivityTypeAddToReadingList,
            UIActivityTypePostToFlickr,
            UIActivityTypePostToVimeo,
            UIActivityTypePostToTencentWeibo
        ]
        
        //UIActivityTypePostToTwitter, UIActivityTypeMessage, UIActivityTypeMail, UIActivityTypePostToWeibo, UIActivityTypePostToFacebook,
        
        print("Activity View Controller: \(activityViewController)")
        return activityViewController
    }
    
    func doneSharingHandler(activityType: String!, completed: Bool, returnedItems: [AnyObject]!, error: NSError!){
        
        
        var error: NSError?
        let displayName = memos[currentCellIndexPath.row].name
        let currentPath = NSSearchPathForDirectoriesInDomains(.DocumentDirectory, .UserDomainMask, true)[0] as NSString
        let filePath2 = (currentPath as String) + "/" + displayName + ".m4a"
        
        //let's attempt to rename file to what is listed in the name rather than the original filename
        let filemgr = NSFileManager.defaultManager()
        
        
        do {
            try filemgr.removeItemAtPath(filePath2)
            print("Remove successful")
        } catch let error1 as NSError {
            error = error1
            print("Remove failed: \(error!.localizedDescription)")
        }
        
        if !completed {
            print("cancelled")
            //activityArray = []
            
            return
        }
        
        if activityType == UIActivityTypePostToTwitter {
            print("twitter")
            
        }
        
        if activityType == UIActivityTypeMail {
            print("mail")
            
        }
        
        if activityType == UIActivityTypePostToFacebook {
            print("facebook")
            
        }
        
        if activityType == UIActivityTypeMessage {
            print("sms")
            
        }
        
    }
    
    func fileToURL() -> NSURL {
        //let fileComponents = filename.componentsSeparatedByString(".")
        print("Row is \(currentCellIndexPath.row)")
        
        let currentPath = NSSearchPathForDirectoriesInDomains(.DocumentDirectory, .UserDomainMask, true)[0] as NSString
        print("test path is \(currentPath)")
        let fileName = memos[currentCellIndexPath.row].file
        print("Filename is: \(fileName)")
        let returnString = (currentPath as String) + "/" + fileName
        
        //let's attempt to rename file to what is listed in the name rather than the original filename
        let filemgr = NSFileManager.defaultManager()
        
        if filemgr.fileExistsAtPath(returnString) {
            print("File exists")
        } else {
            print("File not found")
        }
        
        var error: NSError?
        let displayName = memos[currentCellIndexPath.row].name
        let filePath1 = returnString
        let filePath2 = (currentPath as String) + "/" + displayName + ".m4a"
        
        
        do {
            try filemgr.copyItemAtPath(filePath1, toPath: filePath2)
            print("Copy successful")
        } catch let error1 as NSError {
            error = error1
            print("Copy failed with error: \(error!.localizedDescription)")
        }
        
        let returnObject = NSURL(fileURLWithPath: filePath2)
        print("Returned URL is \(returnObject)")
        return returnObject
    }
    
    func deleteFromBar(sender : UIBarButtonItem!) {
        print("Delete from bar \(self.currentCellIndexPath.row)")
        let alertController = UIAlertController(title: nil, message: nil, preferredStyle: UIAlertControllerStyle.ActionSheet)
        let title = memos[currentCellIndexPath.row].name
        let deleteAction = UIAlertAction(title: "Delete " + title, style: UIAlertActionStyle.Destructive) { (action:UIAlertAction) -> Void in
            //Delete File
            
            if self.player != nil {
                if self.player.playing == true {
                    self.player.stop()
                    self.isPaused = false
                    self.timer.invalidate()
                }
            }
            
            //Delete File
            let outNames = self.getListOfOutNames()
            
            if outNames.contains(self.memos[self.currentCellIndexPath.row].name){
                //Dont delete
                print("Not deleting since associate with multiple out")
            } else {
                let fileToDelete = self.memos[self.currentCellIndexPath.row].file
                self.deleteFile(fileToDelete)
            }
            
    
            
            //Delete Core Data Object
            if let managedObjectContext = (UIApplication.sharedApplication().delegate as! AppDelegate).managedObjectContext {
                let memoToDelete = self.fetchResultController.objectAtIndexPath(self.currentCellIndexPath) as! Memo
                managedObjectContext.deleteObject(memoToDelete)
                //self.tableView.deleteRowsAtIndexPaths([self.currentCellIndexPath], withRowAnimation: .Fade)
                
                /*var e: NSError?
                if managedObjectContext.save() != true {
                    print("delete error: \(e!.localizedDescription)")
                }*/
                
                do {
                    try managedObjectContext.save()
                } catch {
                    fatalError("Failure to save context: \(error)")
                }
                
                self.minimizeCell()
                
                //self.tableView.reloadData()
            }
        }
        
        let cancelAction = UIAlertAction(title: "Cancel", style: UIAlertActionStyle.Cancel, handler: nil)
        
        alertController.addAction(deleteAction)
        alertController.addAction(cancelAction)
        
        self.presentViewController(alertController, animated: true, completion: nil)
        
        
        
    }
    
    func playPauseToggle(playPauseButton : PlayPauseButtonView!){
        print("play pause toggle")
        if playPauseButton.isPlayButton{
            //change to pause
            playPauseButton.isPlayButton = false
            
            //play audio
            playTapped(playPauseButton)
        } else {
            //change to play
            playPauseButton.isPlayButton = true
            
            //pause audio
            pauseEnabled(playPauseButton)
            
        }
    }
    
    func playTapped(playButton: UIButton!) {
        print("play tapped on \(currentCellIndexPath.row) isPaused is \(self.isPaused)")
        //delegate.stopTapped(playButton)
        
        //tableView.beginUpdates()
        
        //let cellIdentifier = "Cell"
        //let cell = tableView.dequeueReusableCellWithIdentifier(cellIdentifier, forIndexPath: currentCellIndexPath) as! CustomTableViewCell
        
        let cell = tableView.cellForRowAtIndexPath(currentCellIndexPath) as! CustomTableViewCell
        cell.nameLabel.enabled = false
        
        if isPaused == true {
            print("is paused")
            player.currentTime = NSTimeInterval(currentSliderValue)
            player.play()
            isPaused = false
            isPlaying = true
            //need to restart timer from current time
            timer = NSTimer.scheduledTimerWithTimeInterval(NSTimeInterval(interval), target: self, selector: "updateProgressBar:", userInfo: nil, repeats: true)
        } else {
            print("Play from beginning")
            let index = playButton.tag
        
            print("Index is: \(playButton.tag)")
            print("Path is: \(memos[index].file)")
            let localPath = NSSearchPathForDirectoriesInDomains(.DocumentDirectory, .UserDomainMask, true)[0] as NSString as String
            self.currentPath = localPath + "/" + memos[index].file
            print("full path is \(self.currentPath)")
            
            let filemgr = NSFileManager.defaultManager()
            
            if filemgr.fileExistsAtPath(self.currentPath) {
                print("File exists")
                
                
                self.soundFileURL = NSURL(fileURLWithPath: self.currentPath)
                do {
                    
                    
                    
                    /*//test of reverse playback
                    let url = self.soundFileURL
                    
                    
                    let playerItem = AVPlayerItem(URL: url)
                    playerItem.canPlayReverse
                    player2 = AVPlayer(playerItem: playerItem)
                    let duration2 = player2.currentItem?.asset.duration
                    player2.seekToTime(duration2!, toleranceBefore: kCMTimeZero, toleranceAfter: kCMTimeZero)
                    player2.currentItem?.canPlayReverse
                    
                    
                    player2.rate = -1.0
                    
                
                    
                    player2.play()
                    
                    
                    
                    
                    /*let player2 = AVPlayer(URL: url)
                    let playerItem = AVPlayerItem(URL: url)
                    //let playerItem = AVPlayerItem( URL:NSURL( string:url ) )
                    self.player2 = AVPlayer(playerItem:playerItem)
                    let duration2 = self.player2.currentItem?.asset.duration
                    let durPrint = CMTimeGetSeconds(duration2!)
                    print("Duration is \(durPrint)")
                    self.player2.seekToTime(duration2!, completionHandler: {finished in
                        print("Seek completed")
                        self.player2.rate = -1
                        self.player2.play()
                        })
                    //self.player2.seekToTime(duration2!, toleranceBefore: kCMTimeZero, toleranceAfter: kCMTimeZero)
                    
                    
                    //end of test of reverse playback*/*/
                    
                    self.player = try AVAudioPlayer(contentsOfURL: self.soundFileURL)
                    //self.player.currentTime = NSTimeInterval(currentSliderValue)
                    self.player.currentTime = NSTimeInterval(0)
                    player.play()
                    startToPlay = true
                    print("Duration is: \(player.duration)")
                    interval = 0.05
                    duration = player.duration
                    isPlaying = true
                    
                    timer = NSTimer.scheduledTimerWithTimeInterval(NSTimeInterval(interval), target: self, selector: "updateProgressBar:", userInfo: nil, repeats: true)
                } catch {
                    print("new player could not be initialized")
                    
                }
                //self.player = try? AVAudioPlayer(contentsOfURL: self.soundFileURL)
                
                //player = AVPlayer(URL: soundFileURL) //when using AVPlayer type
                
                
            }
            
            
            //tableView.reloadRowsAtIndexPaths([currentCellIndexPath], withRowAnimation: .Automatic)
            
            //Animate Slider Bar
            /*if startToPlay == true {
                UIView.animateWithDuration(Double(player.duration) - Double(player.currentTime), delay: 0, options: .AllowUserInteraction | .BeginFromCurrentState, animations: {
                    cell.audioSlider.setValue(Float(self.duration) - Float(self.player.currentTime), animated: true)
                    self.startToPlay = false
                    }, completion: { _ in
                        cell.audioSlider.setValue(Float(self.player.currentTime), animated: true)})
            }*/
            
            //tableView.reloadRowsAtIndexPaths([currentCellIndexPath], withRowAnimation: .None)
        }
        
        //tableView.endUpdates()
    }

    func updateProgressBar(timer : NSTimer!) {
        //println("Update progress bar on \(currentCellIndexPath.row)")
        //This function will calculate the value necessary for the update of the audio slider and time labels, runs when playTapped() is called
        //tableView.beginUpdates()
        
        let cell = tableView.cellForRowAtIndexPath(currentCellIndexPath) as! CustomTableViewCell
        cell.nameLabel.enabled = false
        
        //Stop the timer if this is the last tick of the timer
        //Else calculate currentTimeLabel and timeLeftLabel from currenttime
        if (player.currentTime + NSTimeInterval(interval*1.5)) >= player.duration {
            print("end of playback")
            timer.invalidate()
            //tableView.deselectRowAtIndexPath(currentCellIndexPath, animated: true)
            isPlaying = false
            isPaused = false
            currentSliderValue = 0
            cell.audioSlider.setValue(Float(memos[currentCellIndexPath.row].durationValue), animated: false)
            //cell.playButton.hidden = false
            //cell.pauseButton.hidden = true
            cell.playPauseToggleButton.isPlayButton = true
            cell.nameLabel.enabled = true
            
            
            
        } else {
            currentTimeLabel = stringFromTimeInterval(player.currentTime, needMinuteZero: false)
            timeLeftLabel = "-" + stringFromTimeInterval(player.duration - player.currentTime, needMinuteZero: false)
            cell.audioSlider.setValue(Float(player.currentTime), animated: false)
            
        }
        
        cell.timeLeft.text = timeLeftLabel
        cell.currentTime.text = currentTimeLabel
        //cell.audioSlider.setValue(Float(player.currentTime), animated: false)
        
        
        //tableView.endUpdates()

    }
    
    func sliderTouched(sender : AnyObject!){
        print("Slider touched on \(currentCellIndexPath.row)")
        //When the user touches the slider the audio will pause and timer will be invalidated
        //tableView.beginUpdates()
        let cell = tableView.cellForRowAtIndexPath(currentCellIndexPath) as! CustomTableViewCell
        if isPlaying == true {
            //cell.playButton.hidden = true
            //cell.pauseButton.hidden = false
            player.pause()
            timer.invalidate()
            timer = nil
            pauseEnabled(cell.pauseButton)
            isPlaying = true
        }
        print("Slider Touched")
        currentSliderValue = sender.value
        print("Slider value will be: \(currentSliderValue)")
        cell.audioSlider.setValue(Float(currentSliderValue), animated: false)
        //Flurry.logEvent("Recording_SliderUsed")
        
        //tableView.endUpdates()
        
    }
    
    func sliderDragged(sender : AnyObject!) {
        print("Slider dragged on \(currentCellIndexPath.row)")
        //When the user drags the slider, the values on screen should be updated as well as the player start time
        //tableView.beginUpdates()
        let cell = tableView.cellForRowAtIndexPath(currentCellIndexPath) as! CustomTableViewCell
        

        currentSliderValue = sender.value
        print("Slider is showing: \(currentSliderValue)")
        currentTimeLabel = stringFromFloat(currentSliderValue)
        timeLeftLabel = "-" + stringFromFloat(Float(memos[currentCellIndexPath.row].durationValue) - currentSliderValue)
        
        cell.audioSlider.setValue(Float(currentSliderValue), animated: false)
        cell.timeLeft.text = timeLeftLabel
        cell.currentTime.text = currentTimeLabel
        
        if isPlaying == true {
            player.currentTime = NSTimeInterval(currentSliderValue)
        }
        
        //indexing is hard man
        //currentCellIndexPath = NSIndexPath(forRow: sender.tag, inSection: 0)
        //tableView.reloadRowsAtIndexPaths([currentCellIndexPath], withRowAnimation: .None)
        //tableView.endUpdates()
    }
    
    func pauseEnabled(pauseButton: UIButton!) {
        print("pause enabled on \(currentCellIndexPath.row)")
        tableView.beginUpdates()
        
        let cell = tableView.cellForRowAtIndexPath(currentCellIndexPath) as! CustomTableViewCell
        
        player.pause()
        isPaused = true
        isPlaying = false
        if timer != nil {
            timer.invalidate()
            timer = nil
        }
        
        currentSliderValue = Float(player.currentTime)
        cell.audioSlider.setValue(Float(currentSliderValue), animated: false)
        
        //currentCellIndexPath = NSIndexPath(forRow: pauseButton.tag, inSection: 0)
        tableView.endUpdates()
        
        //tableView.reloadRowsAtIndexPaths([currentCellIndexPath], withRowAnimation: .None)
    }
    
    func stringFromTimeInterval(timeInterval: NSTimeInterval!, needMinuteZero : Bool!) -> String {
        let ti = Int(timeInterval)
        //println("ti: \(ti)")
        let seconds = ti % 60
        let minutes = (ti / 60) % 60
        var returnSeconds = ""
        var returnMinutes = ""
        
        
        if (minutes < 10) && (needMinuteZero == true) {
            returnMinutes = "0" + String(minutes)
        } else {
            returnMinutes = String(minutes)
        }
        
        if seconds < 10 {
            returnSeconds = ":0" + String(seconds)
        } else {
            returnSeconds = ":" + String(seconds)
        }
        
        if needMinuteZero == true {
            return (returnMinutes + returnSeconds + ".") //+ String(self.timerCounter % 100))
        } else {
            return (returnMinutes + returnSeconds )
        }
        
        //return (returnMinutes + returnSeconds + ".") //+ String(self.timerCounter % 100))
    }
    
    func stringFromTimeIntervalWithMS(timeInterval: NSTimeInterval!, needMinuteZero : Bool!) -> String {
        let ti = Int(timeInterval)
        //println("ti: \(ti)")
        let seconds = ti % 60
        let minutes = (ti / 60) % 60
        var returnSeconds = ""
        var returnMinutes = ""
        
        
        if (minutes < 10) && (needMinuteZero == true) {
            returnMinutes = "0" + String(minutes)
        } else {
            returnMinutes = String(minutes)
        }
        
        if seconds < 10 {
            returnSeconds = ":0" + String(seconds)
        } else {
            returnSeconds = ":" + String(seconds)
        }
        
        var msValueString : String!
        let msValue = self.timerCounter % 100
        if msValue < 10 {
            msValueString = "0" + String(msValue)
        } else {
            msValueString = String(msValue)
        }
        
        if needMinuteZero == true {
            return ((returnMinutes + returnSeconds + ".") + msValueString)
        } else {
            return (returnMinutes + returnSeconds )
        }
        
        //return ((returnMinutes + returnSeconds + ".") + msValueString)
    }
    
    func stringFromFloat(timeFloat : Float!) -> String {
        //This function takes in a float and returns a String friendly result
        
        let ti = Int(timeFloat)
        //println("ti: \(ti)")
        let seconds = ti % 60
        let minutes = (ti / 60) //% 60
        var returnSeconds = ""
        
        
        if seconds < 10 {
            returnSeconds = ":0" + String(seconds)
        } else {
            returnSeconds = ":" + String(seconds)
        }
        
        
        
        
        
        return (String(minutes) + returnSeconds)
    }
    
    func stringToTimeStamp(time : Int!, offset : Int!) -> String {
        let seconds = (time + offset) % 60
        let minutes = ((time + offset) / 60)
        var returnSeconds = ""
        var returnMinutes = ""
        
        if seconds < 10 {
            returnSeconds = ":0" + String(seconds)
        } else {
            returnSeconds = ":" + String(seconds)
        }
        
        if minutes < 10 {
            returnMinutes = "0" + String(minutes)
        } else {
            returnMinutes =  String(minutes)
        }
        
        return (returnMinutes + returnSeconds)
        
        
    }
    
    func stopTapped(){
        recorder.stop()
        session = AVAudioSession.sharedInstance()
        do {
            try session.setActive(false)
        } catch _ {
        }
        isRecording = false
        
        //stop the display link

        self.displayLink.paused = true
        
        AudioServicesPlayAlertSound(SystemSoundID(kSystemSoundID_Vibrate))
        
        // After recording is finished, we will insert New Recording into table
        if let managedObjectContext = (UIApplication.sharedApplication().delegate as! AppDelegate).managedObjectContext {
            
            //create new
            memo = NSEntityDescription.insertNewObjectForEntityForName("Memo", inManagedObjectContext: managedObjectContext) as! Memo
            
            //set the date of the recording to a value in the past determined in the settings
            //memo.date = "2 days ago"
            let date = NSDate()
            print("Date is \(date)")
            memo.dateOrder = date
            
            
            /*if let defaults = NSUserDefaults(suiteName: "group.prophesy") {
                let recordingNumber = defaults.integerForKey("recordingNumber")
                println("Recording Number is \(recordingNumber)")
                if recordingNumber > 0 {
                    memo.name = "My Recording " + String(recordingNumber)
                    defaults.setInteger(recordingNumber + 1 , forKey: "recordingNumber")
                    defaults.synchronize()
                } else {
                    memo.name = "My Recording " + String(1)
                    defaults.setInteger(2 , forKey: "recordingNumber")
                    defaults.synchronize()
                }
            }*/
            
            memo.name = self.textToPresent
            
            
            
            let formatter = NSDateFormatter()
            formatter.dateStyle = NSDateFormatterStyle.ShortStyle
            memo.date = formatter.stringFromDate(date)
            //print("Date is \(memo.date)")
            
            //memo.duration = "0:00:01"
            audioAsset = AVURLAsset(URL: recorder.url, options: nil)
            let durationCM = audioAsset.duration
            let dTotalSeconds = CMTimeGetSeconds(durationCM)
            let dHours = floor(dTotalSeconds / 3600) as NSNumber
            let dMinutes = floor(dTotalSeconds % 3600 / 60) as NSNumber
            let dSeconds = floor(dTotalSeconds % 3600 % 60) as NSNumber
            
            if (Int(dMinutes) < 10) {
                firstColon = ":0"
            } else {
                firstColon = ":"
            }
            
            if (Int(dSeconds) < 10) {
                secondColon = ":0"
            } else {
                secondColon = ":"
            }
            
            memo.duration = dHours.stringValue + firstColon + dMinutes.stringValue + secondColon + dSeconds.stringValue
            memo.durationValue = dTotalSeconds
            
            memo.path = fullpath
            //memo.file = recordingTitle
            memo.file = recordingTitle
            memo.sliderValue = 0.0
            
            /*var e: NSError?
            if managedObjectContext.save() != true {
                print("insert error: \(e!.localizedDescription)")
            }*/
            
            do {
                try managedObjectContext.save()
            } catch {
                fatalError("Failure to save context: \(error)")
            }
            
        }

        
    }
    
    @IBAction func seekTime(sender: AnyObject!){
        print("Seek time")
        //This function is run when the slider value is changed
        //tableView.beginUpdates()
        let cell = tableView.cellForRowAtIndexPath(currentCellIndexPath) as! CustomTableViewCell
        currentSliderValue = sender.value
        cell.audioSlider.setValue(Float(currentSliderValue), animated: false)
        
        print("Slider value will be: \(currentSliderValue)")
        if isPlaying == true {
            playTapped(cell.playButton)
            //isPaused = true
            //isPlaying = false
        }
        
        //currentCellIndexPath = NSIndexPath(forRow: sender.tag, inSection: 0)
        //tableView.reloadRowsAtIndexPaths([currentCellIndexPath], withRowAnimation: .None)
        //tableView.endUpdates()
        
    }
    
    func minimizeCell(){
        print("minimize cell")
        
        self.stopPlaying()
        tableView.beginUpdates()
        
        self.tableView.scrollEnabled = true
        
        
        
        self.collapseCell = true
        
        let currentIndex = tableView.indexPathForSelectedRow
        print("Minimizing \(currentIndex?.row)")
        if currentIndex != nil {
            let cell = tableView.cellForRowAtIndexPath(currentIndex!) as! CustomTableViewCell
            cell.nameLabel.enabled = false
            tableView.deselectRowAtIndexPath(currentIndex!, animated: true)
            cell.playPauseToggleButton.hidden = true
            cell.playPauseToggleButton.enabled = false
        }
        
        //tableView.removeGestureRecognizer(self.tapToCollapse)
        self.viewAbove.removeGestureRecognizer(self.tapToCollapse)
        self.viewBelow.removeGestureRecognizer(self.tapToCollapse)
        self.viewAbove.removeFromSuperview()
        self.viewBelow.removeFromSuperview()
        self.recordingOverview.removeFromSuperview()
        
        tableView.endUpdates()
    }
    
    func textFieldShouldBeginEditing(textField: UITextField) -> Bool {
        print("text field should begin editing")
        let pointInTable:CGPoint = textField.superview!.convertPoint(textField.frame.origin, toView: self.tableView)
        var contentOffset:CGPoint = self.tableView.contentOffset
        contentOffset.y  = pointInTable.y
        if let accessoryView = textField.inputAccessoryView {
            contentOffset.y -= accessoryView.frame.size.height
        }
        self.tableView.contentOffset = contentOffset

        return true
    }
    
    func textFieldDidBeginEditing(textField: UITextField) {
        //This function runs when editing of the textField has begun
        print("Editing has begun")
        //print("current row is \(self.currentCellIndexPath.row)")
        editingCellIndexPath = self.currentCellIndexPath
        //textField.selectAll(self)
        textField.autocapitalizationType = UITextAutocapitalizationType.Words
        
        
        tableView.scrollToRowAtIndexPath(tableView.indexPathForSelectedRow!, atScrollPosition: UITableViewScrollPosition.None, animated: true)
        print("current row is \(self.currentCellIndexPath.row)")
        let testRow = tableView.indexPathForSelectedRow
        print("current row is \(testRow?.row)")
        
        self.viewAbove.removeFromSuperview()
        self.viewBelow.removeFromSuperview()
        
        let rectOfCellInTableView = self.tableView.rectForRowAtIndexPath(self.currentCellIndexPath)
        let rectOfCellInSuperview = self.tableView.convertRect(rectOfCellInTableView, toView: tableView.superview)
        print("Cell is at \(rectOfCellInSuperview.origin.y)")
        
        //self.greyOut()
        let expandedRowHeight : CGFloat = 140
        self.viewBelow = UIView(frame: CGRectMake(0, self.topView.bounds.height + expandedRowHeight + 5, self.view.bounds.width, self.view.bounds.height - (expandedRowHeight) ))
        
        self.viewBelow.backgroundColor = UIColor.lightGrayColor().colorWithAlphaComponent(0.5)
        self.tapToCollapse2 = UITapGestureRecognizer(target: self, action: "minimizeCell")
        self.viewBelow.addGestureRecognizer(self.tapToCollapse2)
        self.view.addSubview(self.viewBelow)
        
        
        //Setting up tap recognizer for when keyboard is dismissed without hitting return
        //Looks for single or multiple taps.
        self.currentTextField = textField
        self.tap = UITapGestureRecognizer(target: self, action: "DismissKeyboard")
        //var tap:UITapGestureRecognizer = UITapGestureRecognizer(target: self, action: "textFieldShouldReturn:")
        //tableView.addGestureRecognizer(tap)
        //self.view.addGestureRecognizer(self.tap)
        self.tapToCloseKeyboardView = UIView(frame: CGRectMake(0, 0, self.view.bounds.width, self.view.bounds.height))
        //self.tapToCloseKeyboardView.backgroundColor = UIColor.orangeColor()
        self.tapToCloseKeyboardView.addGestureRecognizer(self.tap)
        self.view.addSubview(self.tapToCloseKeyboardView)
        
        
        
        
        
    }
    
    func textFieldShouldReturn(textField: UITextField) -> Bool {
        //This function handles what happens when the return button is pressed on the keyboard
        //This function will resign the keyboard, then save the edited text field into core data
        
        //tableView.beginUpdates()
        //tableView.removeGestureRecognizer(self.tap)
        //self.view.removeGestureRecognizer(self.tap)
        textField.resignFirstResponder()
        
        //Setup core data request
        let fetchRequest = NSFetchRequest(entityName: "Memo")
        //fetchRequest.predicate = NSPredicate(format: "file contains[c] %@", self.memos[self.editingCellIndexPath.row].file)
        let sortDescriptor = NSSortDescriptor(key: "file", ascending: true)
        fetchRequest.sortDescriptors = [sortDescriptor]
        
        //Set the name to the textField value
        print("current row is \(self.editingCellIndexPath.row)")
        let printname = self.memos[editingCellIndexPath.row].name
        print("old name is: \(printname)")
        print("new name will be: \(textField.text)")
        self.memos[editingCellIndexPath.row].name = textField.text
        //self.memos[currentCellIndexPath.row].name = self.currentTextField.text
        
        //Save to core data
        if let managedObjectContext = (UIApplication.sharedApplication().delegate as! AppDelegate).managedObjectContext {
            
            /*var e: NSError?
            if managedObjectContext.save() != true {
                print("Name edit error: \(e!.localizedDescription)")
            }*/
            
            do {
                try managedObjectContext.save()
            } catch {
                fatalError("Failure to save context: \(error)")
            }
            
        } else {
            print("Couldnt save name!")
        }
        

        
        self.tapToCloseKeyboardView.removeFromSuperview()
        
        return true
    }
    
    func textFieldShouldEndEditing(textField: UITextField) -> Bool {
        print("should end editing")
        self.renameFlag = true
        
        return true
    }
    
    func scrollViewDidScroll(scrollView: UIScrollView) {
        print("scroll view did scroll")
    }
    
    func DismissKeyboard(){
        //Causes the view (or one of its embedded text fields) to resign the first responder status.
        
        print("dismiss keyboard")
        let success = textFieldShouldReturn(self.currentTextField)
        print("Success is \(success)")
        tableView.endEditing(true)
        //tableView.removeGestureRecognizer(self.tap)
        //self.tapToCloseKeyboardView.removeFromSuperview()
    }
    
    @IBAction func enterEditMode(sender : AnyObject!){
        if self.tableView.editing == true {
            //If the tableView is already in edit mode, turn it off.
            self.tableView.setEditing(false, animated: true)
            
            //deselect all that were selected
        } else {
            //First deslect any selected cell
            tableView.deselectRowAtIndexPath(self.currentCellIndexPath, animated: true)
            
            //Turn on edit mode
            self.tableView.setEditing(true, animated: true)
            
        }
    }
    
    @IBAction func deleteToReset(){
        print("Delete to reset")
        
        if player != nil {
            if player.playing == true {
                player.stop()
                isPaused = false
                self.timer.invalidate()
            }
        }
        
        
        //Get string of recording suffix
        if let defaults = NSUserDefaults(suiteName: "group.prophesy") {
            let appendState = defaults.boolForKey("appendState")
            
            var appendFile : String!
            var appendDuration : String!
            var appendDurationValue : NSNumber!
            self.appendCount = defaults.integerForKey("appendCount")
            print("append is \(appendState) for \(self.appendCount)")
            
            if (self.appendCount > 1) && (appendState == true) {
                appendFile = defaults.objectForKey("originalFile") as? String
                appendDuration = defaults.objectForKey("originalDuration") as? String
                appendDurationValue = defaults.objectForKey("originalDurationValue") as? NSNumber
            }
            
            if (self.appendCount == 1) && (appendState == true) {
                appendFile = defaults.objectForKey("fileToAppend") as? String
                appendDuration = defaults.objectForKey("durationToAppend") as? String
                appendDurationValue = defaults.objectForKey("durationValueToAppend") as? NSNumber
            }
            
            let appendName = defaults.objectForKey("nameToAppend") as? String
            
            var recordingSuffix = defaults.objectForKey("recordingSuffix") as? String
            
            if recordingSuffix == nil {
                recordingSuffix = "Morning Cafe"
                defaults.setObject("Morning Cafe", forKey: "recordingSuffix")
                defaults.synchronize()
            }
            
            print("Recording suffix to match is \(recordingSuffix)")
            
            //Get list of multiple out names
            // get sequences from core data
            let outNames = getListOfOutNames()
            print("Out names: \(outNames)")
            
            for memo in memos {
                //Delete any appended recordings
                if (appendState == true) && (memo.name.rangeOfString(appendName!) != nil) {
                    
                    //Delete appended recording then revert to original file
                    //Delete File
                    let fileToDelete = memo.file
                    self.deleteFile(fileToDelete)
                    
                    print("Reverting \(memo.file) to \(appendFile)")
                    memo.file = appendFile
                    memo.duration = appendDuration
                    memo.durationValue = appendDurationValue
                    
                    
                }
                
                //Delete any regular recordings
                if memo.name.rangeOfString(recordingSuffix!) != nil {
                    print("Exists \(memo.name)")
                    
                    //Delete File
                    let fileToDelete = memo.file
                    self.deleteFile(fileToDelete)
                    
                    //Delete Core Data Object
                    if let managedObjectContext = (UIApplication.sharedApplication().delegate as! AppDelegate).managedObjectContext {
                        let memoToDelete = memo
                        managedObjectContext.deleteObject(memoToDelete)

                        do {
                            try managedObjectContext.save()
                        } catch {
                            fatalError("Failure to save context: \(error)")
                        }
                        
                        self.tableView.reloadData()
                    }
                }
                
                //Delete any multiple out recordings
                print("memo name is \(memo.name)")
                if memo.name != nil {
                    if outNames.contains(memo.name) {
                        print("Exists \(memo.name)")
                        
                        //Delete Core Data Object
                        if let managedObjectContext = (UIApplication.sharedApplication().delegate as! AppDelegate).managedObjectContext {
                            let memoToDelete = memo
                            managedObjectContext.deleteObject(memoToDelete)
                            
                            do {
                                try managedObjectContext.save()
                            } catch {
                                fatalError("Failure to save context: \(error)")
                            }
                            
                            self.tableView.reloadData()
                        }
                    }
                }
                
            }
            
            //reset append count to 0
            self.appendCount = 0
            defaults.setInteger(0, forKey: "appendCount")
            defaults.setBool(false, forKey: "appendState")
            defaults.synchronize()
        }
        
        
        
        
        self.dismissViewControllerAnimated(true, completion: nil)
        
        
        
    }
    
    func getListOfOutNames() -> [String] {
        var outNames : [String] = []
        let fetchRequest = NSFetchRequest(entityName: "Sequence")
        let sortDescriptor1 = NSSortDescriptor(key: "dateOrder", ascending: true)
        fetchRequest.sortDescriptors = [sortDescriptor1]
        
        if let managedObjectContext = (UIApplication.sharedApplication().delegate as! AppDelegate).managedObjectContext {
            let fetchResultController = NSFetchedResultsController(fetchRequest: fetchRequest, managedObjectContext: managedObjectContext, sectionNameKeyPath: nil, cacheName: nil)
            fetchResultController.delegate = self
            
            do {
                try fetchResultController.performFetch()
                let sequences = fetchResultController.fetchedObjects as! [Sequence]
                outNames = sequences.map{sequence in sequence.name}
                print("Number of total Sequences: \(sequences.count)")
            } catch  {
                print("Could not retrieve Sequences")
            }
        }
        
        return outNames
    }
    
    func setupAppend(sender : AnyObject!){
        
        if let defaults = NSUserDefaults(suiteName: "group.prophesy") {
            //get append value from user defaults
            self.appendCount = defaults.integerForKey("appendCount")
            self.appendCount = self.appendCount + 1
            print("setup append: \(self.appendCount)")
            
            let currentName = memos[currentCellIndexPath.row].name
            let currentFile = memos[currentCellIndexPath.row].file
            let currentDate = memos[currentCellIndexPath.row].date
            let currentDurationValue = memos[currentCellIndexPath.row].durationValue
            let currentDuration = memos[currentCellIndexPath.row].duration
            
            defaults.setBool(true, forKey: "appendState")
            defaults.setObject(currentName, forKey: "nameToAppend")
            defaults.setObject(currentFile, forKey: "fileToAppend")
            defaults.setObject(currentDate, forKey: "dateToAppend")
            defaults.setObject(currentDuration, forKey: "durationToAppend")
            defaults.setObject(currentDurationValue, forKey: "durationValueToAppend")
            
            if self.appendCount == 1 {
                //this is the file we will revert to at the very end
                print("Saving original file info for \(currentFile)")
                defaults.setObject(currentFile, forKey: "originalFile")
                defaults.setObject(currentDuration, forKey: "originalDuration")
                defaults.setObject(currentDurationValue, forKey: "originalDurationValue")
                
            }
            
            defaults.setInteger(self.appendCount, forKey: "appendCount")
            
            defaults.synchronize()
            self.performSegueWithIdentifier("unwindAndAppend", sender: self)
            
            
        } else {
            print("Defaults failed")
        }
        
    }
    
    func deleteFile(filename : String!){
        print("Delete file for \(filename)")
        let localPath = NSSearchPathForDirectoriesInDomains(.DocumentDirectory, .UserDomainMask, true)[0] as NSString as String
        let fullFilePath = localPath + "/" + filename
        print("full path is \(fullFilePath)")
        
        let filemgr = NSFileManager.defaultManager()
        
        do {
            try filemgr.removeItemAtPath(fullFilePath)
            print("Remove successful")
            let filelist: [AnyObject]?
            filelist = try filemgr.contentsOfDirectoryAtPath(localPath)
            print("Current directory listing:")
            for filename in filelist! {
                print(filename)
            }
            
            self.tableView.reloadData()
        } catch{
            print("Remove failed")
            return
        }
        
        
    }

    //MARK: - Core Data Methods
    func controllerWillChangeContent(controller: NSFetchedResultsController) {
        print("controller will change content")
        // Necessary method for NSFetchedResultsControllerDelegate
        if self.renameFlag != true {
            tableView.beginUpdates()
        }
        
    }
    
    func controller(controller: NSFetchedResultsController, didChangeObject anObject: AnyObject, atIndexPath indexPath: NSIndexPath?, forChangeType type: NSFetchedResultsChangeType, newIndexPath: NSIndexPath?) {
        print("Controller did change object")
        // Necessary method for NSFetchedResultsControllerDelegate
        switch type {
        case .Insert:
            self.tableView.insertRowsAtIndexPaths([newIndexPath!], withRowAnimation: UITableViewRowAnimation.Fade)
        case .Delete:
            tableView.deleteRowsAtIndexPaths([indexPath!], withRowAnimation: .Fade)
        case .Update:
            print("table update occurred")
            
        default:
            tableView.reloadData()
        }
        
        memos = controller.fetchedObjects as! [Memo]
    }
    
    func controllerDidChangeContent(controller: NSFetchedResultsController) {
        print("controller did change content")
        // Necessary method for NSFetchedResultsControllerDelegate
        if self.renameFlag != true {
            tableView.endUpdates()
        } else {
            self.renameFlag = false
        }
        
    }

}
