//
//  SequenceTableViewCell.swift
//  Prophesy Voice
//
//  Created by Lee Lerner on 10/29/15.
//  Copyright © 2015 Lee Lerner. All rights reserved.
//

import UIKit

class SequenceTableViewCell: UITableViewCell {
    
    @IBOutlet weak var sequenceName : UILabel!
    @IBOutlet weak var sequenceNumber : UILabel!

    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
