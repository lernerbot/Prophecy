//
//  CustomTableViewCell.swift
//  SleightRecord
//
//  Created by Lee Lerner on 10/21/14.
//  Copyright (c) 2014 Lee Lerner. All rights reserved.
//

import UIKit

class CustomTableViewCell: UITableViewCell {

    @IBOutlet weak var nameLabel:UITextField!
    @IBOutlet weak var dateLabel:UILabel!
    @IBOutlet weak var durationLabel:UILabel!
    @IBOutlet weak var playButton:UIButton!
    @IBOutlet weak var recordButton:UIButton!
    @IBOutlet weak var stopButton:UIButton!
    @IBOutlet weak var audioSlider:UISlider!
    @IBOutlet weak var pauseButton:UIButton!
    @IBOutlet weak var deleteButton:UIBarButtonItem!
    @IBOutlet weak var currentTime:UILabel!
    @IBOutlet weak var timeLeft:UILabel!
    @IBOutlet weak var shareButton:UIBarButtonItem!
    @IBOutlet weak var editButton:UIBarButtonItem!
    @IBOutlet weak var playPauseToggleButton : PlayPauseButtonView!
    @IBOutlet weak var toolBar: UIToolbar!
    

    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
