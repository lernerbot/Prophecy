//
//  SequenceViewController.swift
//  Prophesy Voice
//
//  Created by Lee Lerner on 10/28/15.
//  Copyright © 2015 Lee Lerner. All rights reserved.
//

import UIKit
import CoreData

class SequenceViewController: UIViewController, UITableViewDataSource, UITableViewDelegate, NSFetchedResultsControllerDelegate {
    
    @IBOutlet weak var addButton : UIBarButtonItem!
    @IBOutlet var tableView : UITableView!
    var fetchResultController:NSFetchedResultsController!
    var sequence : Sequence!
    var sequences : [Sequence] = []
    var emptyText : String = "Empty"
    var fileNames = [String](count: 20, repeatedValue: "Empty")
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.title = "Outs"
        
        // get sequences from core data
        let fetchRequest = NSFetchRequest(entityName: "Sequence")
        let sortDescriptor1 = NSSortDescriptor(key: "dateOrder", ascending: true)
        fetchRequest.sortDescriptors = [sortDescriptor1]
        
        if let managedObjectContext = (UIApplication.sharedApplication().delegate as! AppDelegate).managedObjectContext {
            fetchResultController = NSFetchedResultsController(fetchRequest: fetchRequest, managedObjectContext: managedObjectContext, sectionNameKeyPath: nil, cacheName: nil)
            fetchResultController.delegate = self
            
            do {
                try fetchResultController.performFetch()
                sequences = fetchResultController.fetchedObjects as! [Sequence]
                print("Number of total Sequences: \(sequences.count)")
            } catch  {
                print("Could not retrieve Sequences")
            }
        }
        
        self.checkSequenceCount()
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    func tableView(tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return sequences.count
    }
    
    func tableView(tableView: UITableView, cellForRowAtIndexPath indexPath: NSIndexPath) -> UITableViewCell {
        let cellIdentifier = "SequenceCell"
        let cell = tableView.dequeueReusableCellWithIdentifier(cellIdentifier, forIndexPath: indexPath) as! SequenceTableViewCell
        
        cell.sequenceName.text = sequences[indexPath.row].name
        let sequenceRow = indexPath.row
        cell.sequenceNumber.text = "1" + String(sequenceRow) + " _ _"
        return cell
    }
    
    func tableView(tableView: UITableView, commitEditingStyle editingStyle: UITableViewCellEditingStyle, forRowAtIndexPath indexPath: NSIndexPath) {
        print("Total items: \(self.sequences.count)")
        if editingStyle == .Delete {
            self.deleteFilesInSequence(self.sequences[indexPath.row])
            self.sequences.removeAtIndex(indexPath.row)
            self.deleteSequence(indexPath)
            self.tableView.reloadData()
            self.checkSequenceCount()
            print("Total items: \(self.sequences.count)")
        }
    }
    
    func tableView(tableView: UITableView, didSelectRowAtIndexPath indexPath: NSIndexPath) {
        self.tableView.deselectRowAtIndexPath(indexPath, animated: true)
    }
    
    @IBAction func addSequence(){
        let alertController = UIAlertController(title: "Name Your Out", message: nil, preferredStyle: UIAlertControllerStyle.Alert)
        
        alertController.addTextFieldWithConfigurationHandler({ (textField : UITextField) in
            if let textField = alertController.textFields?.first {
                textField.autocapitalizationType = UITextAutocapitalizationType.Words
                textField.text = ""
                textField.placeholder = "Name Your Out"
            }
        })
        
        let deleteAction = UIAlertAction(title: "Cancel", style: .Cancel) { (action) in
            print("Cancel selected")
            
            
        }
        alertController.addAction(deleteAction)
        
        let saveAction = UIAlertAction(title: "Save", style: .Default) { (action) in
            print("save selected")
            if let textField = alertController.textFields?.first {
                
                if textField.text!.isEmpty {
                    self.createSequence("New Out")
                    //let newSequence = Sequence(name: "New Out", fileNames: self.fileNames, filePaths: self.fileNames)
                    //self.sequences.append(newSequence)
                } else {
                    self.createSequence(textField.text!)
                    //let newSequence = Sequence(name: textField.text!, fileNames: self.fileNames, filePaths: self.fileNames)
                    //self.sequences.append(newSequence)
                    //self.sequences[self.sequences.count - 1].fileNames[0] = "test0"
                    //self.sequences[self.sequences.count - 1].fileNames[1] = "test1"
                    //self.sequences[self.sequences.count - 1].fileNames[2] = "test2"
                }
                print("name to be saved is \(self.sequences[self.sequences.count - 1].name)")
                self.checkSequenceCount()
                //self.tableView.reloadData()
                
            }

        }
        alertController.addAction(saveAction)
        
        self.presentViewController(alertController, animated: true) {
            
        }

    }
    
    func checkSequenceCount(){
        //We only want to have a max of 10 sequences
        if self.sequences.count == 10 {
            self.addButton.enabled = false
        } else {
            self.addButton.enabled = true
        }
    }
    
    func deleteSequence(indexPath:NSIndexPath!){
        //Delete Core Data Object
        if let managedObjectContext = (UIApplication.sharedApplication().delegate as! AppDelegate).managedObjectContext {
            let sequenceToDelete = self.fetchResultController.objectAtIndexPath(indexPath) as! Sequence
            managedObjectContext.deleteObject(sequenceToDelete)
            
            do {
                try managedObjectContext.save()
                print("Delete successful")
            } catch {
                fatalError("Failure to save context: \(error)")
            }
            
        }
    }
    
    func createSequence(name:String!){
        // After recording is finished, we will insert New Recording into table
        if let managedObjectContext = (UIApplication.sharedApplication().delegate as! AppDelegate).managedObjectContext {
            
            //create new
            let newSequence = NSEntityDescription.insertNewObjectForEntityForName("Sequence", inManagedObjectContext: managedObjectContext) as! Sequence
            
            //Add date
            let date = NSDate()
            print("Date is \(date)")
            newSequence.dateOrder = date
    
            //Add name
            print("Name is \(name)")
            newSequence.name = name
            
            //Add blank filenames and paths
            newSequence.fileNames = "Empty,Empty,Empty,Empty,Empty,Empty,Empty,Empty,Empty,Empty,Empty,Empty,Empty,Empty,Empty,Empty,Empty,Empty,Empty,Empty"
            newSequence.filePaths = "Empty,Empty,Empty,Empty,Empty,Empty,Empty,Empty,Empty,Empty,Empty,Empty,Empty,Empty,Empty,Empty,Empty,Empty,Empty,Empty"
            
            print("File: \(newSequence.fileNames) \(newSequence.filePaths)")
            
            
            do {
                try managedObjectContext.save()
            } catch {
                fatalError("Failure to save context: \(error)")
            }
            
        }
    }
    
    func deleteFilesInSequence(sequence : Sequence!){
        let filePaths = sequence.filePaths.componentsSeparatedByString(",").filter{$0 != self.emptyText}
        print("File Paths to be deleted: \(filePaths.count)")
        if filePaths.count > 0 {
            for fileName in filePaths {
                self.deleteFile(fileName)
            }
        }
    }
    
    func deleteFile(filename : String!){
        print("Delete file for \(filename)")
        let localPath = NSSearchPathForDirectoriesInDomains(.DocumentDirectory, .UserDomainMask, true)[0] as NSString as String
        let fullFilePath = localPath + "/" + filename
        print("full path is \(fullFilePath)")
        
        let filemgr = NSFileManager.defaultManager()
        
        do {
            try filemgr.removeItemAtPath(fullFilePath)
            print("Remove successful")
            /*let filelist: [AnyObject]?
            filelist = try filemgr.contentsOfDirectoryAtPath(localPath)
            print("Current directory listing:")
            for filename in filelist! {
                print(filename)
            }*/
            
        } catch{
            print("Remove failed")
            return
        }
        
        
    }
    
    //MARK: - Core Data Methods
    func controllerWillChangeContent(controller: NSFetchedResultsController) {
        print("controller will change content")
        tableView.beginUpdates()
    }
    
    func controller(controller: NSFetchedResultsController, didChangeObject anObject: AnyObject, atIndexPath indexPath: NSIndexPath?, forChangeType type: NSFetchedResultsChangeType, newIndexPath: NSIndexPath?) {
        print("Controller did change object")
        // Necessary method for NSFetchedResultsControllerDelegate
        switch type {
        case .Insert:
            self.tableView.insertRowsAtIndexPaths([newIndexPath!], withRowAnimation: UITableViewRowAnimation.Fade)
        case .Delete:
            tableView.deleteRowsAtIndexPaths([indexPath!], withRowAnimation: .Fade)
            //let fileToDelete = self.memos[indexPath.row].file
            //self.deleteFile(fileToDelete)
        case .Update:
            //tableView.reloadRowsAtIndexPaths([indexPath!], withRowAnimation: .None)
            print("table update occurred sequence view")
            
        default:
            tableView.reloadData()
        }
        
        sequences = controller.fetchedObjects as! [Sequence]
    }
    
    func controllerDidChangeContent(controller: NSFetchedResultsController) {
        print("controller did change content")
        tableView.endUpdates()
    }

    
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepareForSegue(segue: UIStoryboardSegue, sender: AnyObject?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
        if segue.identifier == "showSequenceDetail" {
            if let indexPath = self.tableView.indexPathForSelectedRow {
                let destinationController = segue.destinationViewController as! DetailViewController
                
                destinationController.sequence = sequences[indexPath.row]
                destinationController.sequenceName = sequences[indexPath.row].name
                destinationController.sequenceNumber = indexPath.row
                print("Sequence should be \(destinationController.sequence)")
            }
        }
    }
    

}
