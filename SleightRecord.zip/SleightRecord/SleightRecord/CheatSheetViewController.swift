//
//  CheatSheetViewController.swift
//  Prophesy Voice
//
//  Created by Lee Lerner on 11/17/15.
//  Copyright © 2015 Lee Lerner. All rights reserved.
//

import UIKit
import CoreData
import CoreMotion

class CheatSheetViewController: UIViewController, NSFetchedResultsControllerDelegate, UITableViewDataSource, UITableViewDelegate {
    let motionManager: CMMotionManager = CMMotionManager()
    var fetchResultController:NSFetchedResultsController!
    var pinList : [String] = []
    var fileNameList : [String] = []
    var outNameList : [String] = []
    @IBOutlet weak var tableView : UITableView!
    var choice : Int = 0
    var delayFlag = false
    var timer : NSTimer!

    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        self.title = "Cheat Sheet"
        let quitButton : UIBarButtonItem = UIBarButtonItem(title: "Done", style: UIBarButtonItemStyle.Plain, target: self, action: "exitCheatSheet")
        self.navigationItem.rightBarButtonItem = quitButton
        
        if let defaults = NSUserDefaults(suiteName: "group.prophesy"){
            choice = defaults.integerForKey("multipleOutChoice")
            defaults.synchronize()
        }
        
        (pinList, fileNameList, outNameList) = getPinList()
        
        timer = NSTimer(timeInterval: 0.3, target: self, selector: "startMotionUpdates", userInfo: nil, repeats: false)
        NSRunLoop.currentRunLoop().addTimer(timer, forMode: NSRunLoopCommonModes)
    }
    

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    //Custom Methods
    func exitCheatSheet(){
        self.navigationController?.dismissViewControllerAnimated(false, completion: nil)
        self.motionManager.stopDeviceMotionUpdates()
    }
    
    func getPinList() -> ([String], [String], [String]){
        var pinList : [String] = []
        var fileNameList: [String] = []
        var outNameList:[String] = []
        //Get sequences from core data
        let fetchRequest = NSFetchRequest(entityName: "Sequence")
        let sortDescriptor1 = NSSortDescriptor(key: "dateOrder", ascending: true)
        fetchRequest.sortDescriptors = [sortDescriptor1]
        
        if let managedObjectContext = (UIApplication.sharedApplication().delegate as! AppDelegate).managedObjectContext {
            fetchResultController = NSFetchedResultsController(fetchRequest: fetchRequest, managedObjectContext: managedObjectContext, sectionNameKeyPath: nil, cacheName: nil)
            //fetchResultController.delegate = self
            
            do {
                try fetchResultController.performFetch()
                let sequences = fetchResultController.fetchedObjects as! [Sequence]
                print("Number of total Sequences: \(sequences.count)")
                let fileNames = sequences.map{ sequence in sequence.fileNames}.map{fileString in fileString.componentsSeparatedByString(",").filter{$0 != "Empty"}}
                let outNames = sequences.map{sequence in sequence.name}
                
                //print("File names \(fileNames)")
                //print("Out names \(outNames)")
                
                for (index1, out) in fileNames.enumerate() {
                    if index1 == choice {
                        self.title = outNames[index1]
                        for (index2, element) in out.enumerate() {
                            let value = 1000 + (100 * index1) + index2
                            pinList.append(String(value))
                            fileNameList.append(element)
                            outNameList.append(outNames[index1])
                        }
                    }
                }
                
                print("pinList is \(pinList)")
                print("fileList is \(fileNameList)")
                print("outNameList is \(outNameList)")
                
                
                
            } catch  {
                print("Could not retrieve Sequences")
                pinList = ["9999"]
            }
        }
        
        
        return (pinList, fileNameList, outNameList)
    }
    
    func startMotionUpdates(){
        if motionManager.deviceMotionAvailable {
            print("Device Motion Available")
            motionManager.deviceMotionUpdateInterval = 0.05
            //let initialAttitude = motionManager.deviceMotion?.attitude
            //print("initial Attitude is \(initialAttitude)")
            
            motionManager.startDeviceMotionUpdatesToQueue(NSOperationQueue.mainQueue(), withHandler: {
                (data, error) in
                
                //print("data is \(data)")
                print("pitch: \(data?.attitude.pitch) yaw: \(data?.attitude.yaw)")
                
                //Sometimes on initialization the pitch reads a really tiny number
                if !(abs((data?.attitude.pitch)!) < 0.001) {
                    self.delayFlag = true
                }
                
                
                if ((data?.attitude.pitch < 1.0) && (self.delayFlag)) /*|| (abs((data?.attitude.yaw)!) > 0.2)*/ {
                    self.exitCheatSheet()
                    
                }
                
            })
            
        }
    }
    
    //TableView Methods
    func tableView(tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return self.fileNameList.count
    }
    
    func tableView(tableView: UITableView, cellForRowAtIndexPath indexPath: NSIndexPath) -> UITableViewCell {
        let cellIdentifier = "Cell"
        let cell = tableView.dequeueReusableCellWithIdentifier(cellIdentifier) as! CheatSheetTableViewCell
        
        cell.pinNumber.text = pinList[indexPath.row]
        cell.fileName.text = fileNameList[indexPath.row]
        cell.outName.text = outNameList[indexPath.row]
        
        //cell.pinNumber.textColor = UIColor.whiteColor()
        //cell.fileName.textColor = UIColor.whiteColor()
        //cell.outName.textColor = UIColor.whiteColor()
        //cell.backgroundColor = UIColor.blackColor()
        
        return cell
    }



}
