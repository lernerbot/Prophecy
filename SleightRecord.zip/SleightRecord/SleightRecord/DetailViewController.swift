//
//  DetailViewController.swift
//  Prophesy Voice
//
//  Created by Lee Lerner on 10/29/15.
//  Copyright © 2015 Lee Lerner. All rights reserved.
//

import UIKit
import CoreData

class DetailViewController: UIViewController, UITableViewDataSource, UITableViewDelegate, UIPickerViewDataSource, UIPickerViewDelegate, NSFetchedResultsControllerDelegate {
    
    @IBOutlet weak var tableView : UITableView!
    @IBOutlet weak var addButton : UIBarButtonItem!
    //@IBOutlet weak var pickerView : UIPickerView!
    var sequenceName : String!
    var sequenceNumber : Int!
    var sequence : Sequence!
    var sequences : [Sequence] = []
    var selectedIndexPath : NSIndexPath!
    var tableData : [String] = []
    var MAXROWS = 20
    var fetchResultController : NSFetchedResultsController!
    var memos : [Memo] = []
    var actionView: UIView = UIView()
    var pickerView = UIPickerView()
    var fileNames : [String] = []
    var filePaths : [String] = []
    var totalFiles : Int = 0
    var emptyText : String = "Empty"
    
    

    override func viewDidLoad() {
        super.viewDidLoad()
        
        print("Width is \(self.view.bounds.width)")
        
        // Do any additional setup after loading the view.
        self.title = self.sequence.name
        
        //Fill out file arrays from sequence strings
        if sequence.fileNames == "" {
            fileNames = [String](count: 20, repeatedValue: "")
            filePaths = [String](count: 20, repeatedValue: "")
        } else {
            fileNames = sequence.fileNames.componentsSeparatedByString(",")
            filePaths = sequence.filePaths.componentsSeparatedByString(",")
            totalFiles = fileNames.filter{$0 != self.emptyText}.count
            print("Number of files is \(totalFiles)")
            
            //Check total number of files and disable add button if we reached MAXROWS
            self.checkFileCount()
        }
        
        
        //Load Available Memos File Names from Core Data
        self.fetchMemos()
        
        
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
        
    }
    
    func tableView(tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return MAXROWS
    }
    
    func tableView(tableView: UITableView, cellForRowAtIndexPath indexPath: NSIndexPath) -> UITableViewCell {
        //print("Cell for row \(indexPath.row)")
        
        let cellIdentifier = "DetailCell"
        let cell = tableView.dequeueReusableCellWithIdentifier(cellIdentifier) as! DetailTableViewCell
        
        
        if (fileNames[indexPath.row] == "") || (fileNames.isEmpty) {
            cell.detailName.text = self.emptyText
        } else {
            cell.detailName.text = fileNames[indexPath.row]
        }
        
        var suffix : String = ""
        if indexPath.row < 10 {
            suffix = "0" + String(indexPath.row)
        } else {
            suffix = String(indexPath.row)
        }
        
        cell.detailNumber.text = "1" + String(sequenceNumber) + suffix
        
        if self.view.bounds.width <= 320 {
            cell.detailNumberRightConstraint.constant -= 60
        }

        return cell
    }
    
    func tableView(tableView: UITableView, didSelectRowAtIndexPath indexPath: NSIndexPath) {
        print("Row picked is \(indexPath.row)")
        selectedIndexPath = indexPath
        
        if tableData.count > 0 {
            let kSCREEN_WIDTH  =    UIScreen.mainScreen().bounds.size.width
            
            pickerView.frame = CGRectMake(0.0, 44.0,kSCREEN_WIDTH, 216.0)
            pickerView.delegate = self
            pickerView.dataSource = self
            pickerView.showsSelectionIndicator = true
            pickerView.selectRow(0, inComponent: 0, animated: true)
            pickerView.backgroundColor = UIColor.whiteColor()
            //pickerView.layer.borderWidth = 1
            //pickerView.layer.borderColor = UIColor.darkGrayColor().CGColor
            
            let pickerToolBar = UIToolbar(frame: CGRectMake(0, 0, kSCREEN_WIDTH, 44))
            pickerToolBar.barStyle = UIBarStyle.Default
            pickerToolBar.barTintColor = UIColor.blackColor()
            pickerToolBar.layer.borderWidth = 1
            pickerToolBar.layer.borderColor = UIColor.darkGrayColor().CGColor
            pickerToolBar.translucent = true
            
            var barItems : [UIBarButtonItem] = []
            let cancelItem = UIBarButtonItem(title: "Cancel", style: UIBarButtonItemStyle.Plain, target: self, action: "cancelPicker")
            barItems.append(cancelItem)
            
            let flexSpace = UIBarButtonItem(barButtonSystemItem: UIBarButtonSystemItem.FlexibleSpace, target: self, action: nil)
            barItems.append(flexSpace)
            
            let doneButton = UIBarButtonItem(title: "Select", style: UIBarButtonItemStyle.Plain, target: self, action: "selectItem")
            barItems.append(doneButton)
            
            pickerToolBar.setItems(barItems, animated: true)
            
            actionView.addSubview(pickerToolBar)
            actionView.addSubview(pickerView)
            self.view.addSubview(actionView)
            
            UIView.animateWithDuration(0.2, animations: {
                
                self.actionView.frame = CGRectMake(0, UIScreen.mainScreen().bounds.size.height - 260.0, UIScreen.mainScreen().bounds.size.width, 260.0)
                
            })

        } else {
            let alertController = UIAlertController(title: "No Recordings Found", message: "Please make some recordings on the playback page", preferredStyle: UIAlertControllerStyle.Alert)
            let defaultAction = UIAlertAction(title: "OK", style: UIAlertActionStyle.Default, handler: nil)
            alertController.addAction(defaultAction)
            presentViewController(alertController, animated: true, completion: nil)
            self.tableView.deselectRowAtIndexPath(selectedIndexPath, animated: true)
        }
        
    }
    
    @IBAction func addOut(){
        
        selectedIndexPath = NSIndexPath(forRow: totalFiles, inSection: 0)
        print("Table data \(tableData) with count \(tableData.count)")
        
        if tableData.count > 0 {
            print("Adding file to row \(selectedIndexPath.row)")
            let kSCREEN_WIDTH  =    UIScreen.mainScreen().bounds.size.width
            
            pickerView.frame = CGRectMake(0.0, 44.0,kSCREEN_WIDTH, 216.0)
            pickerView.delegate = self
            pickerView.dataSource = self
            pickerView.showsSelectionIndicator = true
            pickerView.selectRow(0, inComponent: 0, animated: true)
            pickerView.backgroundColor = UIColor.whiteColor()
            //pickerView.layer.borderWidth = 1
            //pickerView.layer.borderColor = UIColor.darkGrayColor().CGColor
            
            let pickerToolBar = UIToolbar(frame: CGRectMake(0, 0, kSCREEN_WIDTH, 44))
            pickerToolBar.barStyle = UIBarStyle.Default
            pickerToolBar.barTintColor = UIColor.blackColor()
            pickerToolBar.layer.borderWidth = 1
            pickerToolBar.layer.borderColor = UIColor.darkGrayColor().CGColor
            pickerToolBar.translucent = true
            
            var barItems : [UIBarButtonItem] = []
            let cancelItem = UIBarButtonItem(title: "Cancel", style: UIBarButtonItemStyle.Plain, target: self, action: "cancelPicker")
            barItems.append(cancelItem)
            
            let flexSpace = UIBarButtonItem(barButtonSystemItem: UIBarButtonSystemItem.FlexibleSpace, target: self, action: nil)
            barItems.append(flexSpace)
            
            let doneButton = UIBarButtonItem(title: "Select", style: UIBarButtonItemStyle.Plain, target: self, action: "selectItem")
            barItems.append(doneButton)
            
            pickerToolBar.setItems(barItems, animated: true)
            
            actionView.addSubview(pickerToolBar)
            actionView.addSubview(pickerView)
            self.view.addSubview(actionView)
            
            UIView.animateWithDuration(0.2, animations: {
                
                self.actionView.frame = CGRectMake(0, UIScreen.mainScreen().bounds.size.height - 260.0, UIScreen.mainScreen().bounds.size.width, 260.0)
                
            })
            
        } else {
            let alertController = UIAlertController(title: "No Recordings Found", message: "Please make some recordings on the playback page", preferredStyle: UIAlertControllerStyle.Alert)
            let defaultAction = UIAlertAction(title: "OK", style: UIAlertActionStyle.Default, handler: nil)
            alertController.addAction(defaultAction)
            presentViewController(alertController, animated: true, completion: nil)
        
        }
    }
    
    func checkFileCount(){
        
        totalFiles = fileNames.filter{$0 != self.emptyText}.count
        
        //We only want to have a max of 20 files
        if totalFiles == MAXROWS {
            self.addButton.enabled = false
        } else {
            self.addButton.enabled = true
        }
    }
    
    func fetchMemos(){
        print("Func Fetch Memos")
        //Load Available Memos File Names from Core Data
        let fetchRequest = NSFetchRequest(entityName: "Memo")
        let sortDescriptor1 = NSSortDescriptor(key: "dateOrder", ascending: false)
        fetchRequest.sortDescriptors = [sortDescriptor1]
        if let managedObjectContext = (UIApplication.sharedApplication().delegate as! AppDelegate).managedObjectContext {
            fetchResultController = NSFetchedResultsController(fetchRequest: fetchRequest, managedObjectContext: managedObjectContext, sectionNameKeyPath: nil, cacheName: nil)
            fetchResultController.delegate = self
            
            do {
                try fetchResultController.performFetch()
                
                memos = fetchResultController.fetchedObjects as! [Memo]
                print("Number of total Memos: \(memos.count)")
                tableData = memos.map{ memo in memo.name}
                print("Table data \(tableData) with count \(tableData.count)")
            } catch  {
                print("Could not retrieve memos")
            }
            
        }
    }
    
    
    // MARK: UIPickerDelegate
    
    func numberOfComponentsInPickerView(pickerView: UIPickerView) -> Int {
        return 1
    }
    
    func pickerView(pickerView: UIPickerView, numberOfRowsInComponent component: Int) -> Int {
        return tableData.count
    }
    
    func pickerView(pickerView: UIPickerView, titleForRow row: Int, forComponent component: Int) -> String? {
        return tableData[row]
    }
    
    func pickerView(pickerView: UIPickerView, didSelectRow row: Int, inComponent component: Int) {
        print("Row picked is \(row)")
    }
    
    //MARK: - Custom Methods
    func cancelPicker(){
        self.dismissPickerView()
    }
    
    func selectItem(){
        let pickerRow = pickerView.selectedRowInComponent(0)
        let cell = tableView.cellForRowAtIndexPath(selectedIndexPath) as! DetailTableViewCell
        cell.detailName.text = tableData[pickerRow]
        cell.detailName.textColor = UIColor.blackColor()
        fileNames[selectedIndexPath.row] = tableData[pickerRow]
        print("File \(memos[pickerRow].file) will be placed in row \(selectedIndexPath.row)")
        filePaths[selectedIndexPath.row] = memos[pickerRow].file
        
        self.saveFileToSequence(self.fileNames, filePaths: self.filePaths)
        
        self.deleteMemoFromPlaybackList(pickerRow)
        
        //tableData.removeAtIndex(pickerRow)
        
        self.dismissPickerView()
        
        //This will disable the add button if we reached the limit
        self.checkFileCount()
        
    }
    
    func deleteMemoFromPlaybackList(index : Int!){
        let indexPath = NSIndexPath(forRow: index, inSection: 0)
        //Delete Core Data Object
        if let managedObjectContext = (UIApplication.sharedApplication().delegate as! AppDelegate).managedObjectContext {
            let memoToDelete = self.fetchResultController.objectAtIndexPath(indexPath) as! Memo
            print("memo to delete is \(memoToDelete.name)")
            managedObjectContext.deleteObject(memoToDelete)
            
            do {
                try managedObjectContext.save()
            } catch {
                fatalError("Failure to save context: \(error)")
                return
            }
            
            //memos.removeAtIndex(index)
            let memoList = memos.map{ memo in memo.name}
            print("Memo list is \(memoList)")
            
            self.fetchMemos()
        }
    }
    
    func dismissPickerView(){
        
        self.tableView.deselectRowAtIndexPath(selectedIndexPath, animated: true)
        UIView.animateWithDuration(0.2, animations: {
            
            self.actionView.frame = CGRectMake(0, UIScreen.mainScreen().bounds.size.height, UIScreen.mainScreen().bounds.size.width, 260.0)
            
            }, completion: { _ in
                for obj: AnyObject in self.actionView.subviews {
                    if let view = obj as? UIView
                    {
                        view.removeFromSuperview()
                    }
                }
        })
    }
    
    func saveFileToSequence(fileNames : [String], filePaths : [String]){
        let fileNameString = fileNames.joinWithSeparator(",")
        let filePathString = filePaths.joinWithSeparator(",")
        
        let fetchRequest = NSFetchRequest(entityName: "Sequence")
        fetchRequest.predicate = NSPredicate(format: "name contains[c] %@", self.sequence.name)
        let sortDescriptor = NSSortDescriptor(key: "name", ascending: true)
        fetchRequest.sortDescriptors = [sortDescriptor]
        
        if let managedObjectContext = (UIApplication.sharedApplication().delegate as! AppDelegate).managedObjectContext {
            let fetchResultController = NSFetchedResultsController(fetchRequest: fetchRequest, managedObjectContext: managedObjectContext, sectionNameKeyPath: nil, cacheName: nil)
            
            do {
                try fetchResultController.performFetch()
    
            } catch  {
                print("Couldn't perform fetch")
                return
            }
            
            sequences = fetchResultController.fetchedObjects as! [Sequence]
            
            print("Number of total Sequences: \(sequences.count)")
            if sequences.count == 0 {
                print("Warning: Unable to retrieve from memory")
            } else {
                //Set new file name
                sequences[0].fileNames = fileNameString
                sequences[0].filePaths = filePathString
                
                do {
                    try managedObjectContext.save()
                } catch {
                    fatalError("Failure to save context: \(error)")
                }
            }
            
        }
    }
    
    //MARK: - Core Data Methods
    func controllerWillChangeContent(controller: NSFetchedResultsController) {
        print("controller will change content")
        tableView.beginUpdates()
    }
    
    func controller(controller: NSFetchedResultsController, didChangeObject anObject: AnyObject, atIndexPath indexPath: NSIndexPath?, forChangeType type: NSFetchedResultsChangeType, newIndexPath: NSIndexPath?) {
        print("Controller did change object")
        // Necessary method for NSFetchedResultsControllerDelegate
        switch type {
        case .Insert:
            //self.tableView.insertRowsAtIndexPaths([newIndexPath!], withRowAnimation: UITableViewRowAnimation.Fade)
            print("Detail Insert")
        case .Delete:
            //tableView.deleteRowsAtIndexPaths([indexPath!], withRowAnimation: .Fade)
            //let fileToDelete = self.memos[indexPath.row].file
            //self.deleteFile(fileToDelete)
            print("Detail Delete")
        case .Update:
            //tableView.reloadRowsAtIndexPaths([indexPath!], withRowAnimation: .None)
            print("table update occurred detail view")
            
        default:
            tableView.reloadData()
        }
        
        memos = fetchResultController.fetchedObjects as! [Memo]

    }
    
    func controllerDidChangeContent(controller: NSFetchedResultsController) {
        print("controller did change content")
        tableView.endUpdates()
    }
    
    
    
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepareForSegue(segue: UIStoryboardSegue, sender: AnyObject?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
