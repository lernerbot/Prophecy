//
//  SettingsTableViewController.swift
//  SleightRecord
//
//  Created by Lee Lerner on 9/1/15.
//  Copyright (c) 2015 Lee Lerner. All rights reserved.
//

import UIKit
import CoreData

protocol setBackgroundDelegate{
    func setBackground(backgroundImage : UIImage!)
    func setLockImage(lockImage : UIImage!)
    func refresh()
    
}



class SettingsTableViewController: UITableViewController, UIImagePickerControllerDelegate, UINavigationControllerDelegate, UITextFieldDelegate, UIPickerViewDelegate, UIPickerViewDataSource {
    
    @IBOutlet weak var nameOutput : UILabel!
    var fetchResultController:NSFetchedResultsController!
    @IBOutlet weak var homeThumbnail : UIButton!
    @IBOutlet weak var lockThumbnail : UIButton!
    var tag : Int!
    @IBOutlet weak var subtleSwitch : UISwitch!
    var bgImage : UIImage!
    var imagePicked : Bool!
    var delegate : setBackgroundDelegate! = nil
    @IBOutlet weak var textField : UITextField!
    var currentTextField : UITextField!
    var tap:UITapGestureRecognizer!
    @IBOutlet weak var picker : UIPickerView!
    var pickerData : [Int] = [Int()]
    @IBOutlet weak var dayTextField : UITextField!
    
    var images : Images!
    //var fetchResultController:NSFetchedResultsController!
    

    override func viewDidLoad() {
        super.viewDidLoad()
        
        //Show navigation bar
        self.navigationController?.setNavigationBarHidden(false , animated: false)
        
        self.title = "Settings"
        
        //Set Keyboard Stuff
        //self.textField.borderStyle = .None
        self.textField.enablesReturnKeyAutomatically = true
        self.textField.returnKeyType = UIReturnKeyType.Done
        self.textField.keyboardAppearance = UIKeyboardAppearance.Default
        self.textField.keyboardType = UIKeyboardType.Default
        self.textField.resignFirstResponder()
        self.textField.delegate = self
        
        self.dayTextField.enablesReturnKeyAutomatically = true
        self.dayTextField.returnKeyType = UIReturnKeyType.Default
        self.dayTextField.keyboardAppearance = UIKeyboardAppearance.Default
        self.dayTextField.keyboardType = UIKeyboardType.NumberPad
        self.dayTextField.resignFirstResponder()
        self.dayTextField.delegate = self
        
        //Set pickerview stuff
        
        //self.picker.delegate = self
        //self.picker.dataSource = self
        self.pickerData = [1,2,3,4,5,6]
        //self.dayTextField.inputView = picker
        
        self.addDoneButtonOnKeyboard()
        
        /*if let defaults = NSUserDefaults(suiteName: "group.prophesy"){
            let subtle = defaults.boolForKey("subtleMode")
            if subtle == true {
                self.subtleSwitch.on = false
            } else {
                self.subtleSwitch.on = true
            }
        }*/
        
        if let defaults = NSUserDefaults(suiteName: "group.prophesy"){
            let useBackground = defaults.boolForKey("useBackgroundImage")
            if useBackground == true {
                print("use image for background")
                
                let fetchRequest = NSFetchRequest(entityName: "Images")
                let sortDescriptor = NSSortDescriptor(key: "backgroundImage", ascending: true)
                fetchRequest.sortDescriptors = [sortDescriptor]
                
                if let managedObjectContext = (UIApplication.sharedApplication().delegate as! AppDelegate).managedObjectContext {
                    fetchResultController = NSFetchedResultsController(fetchRequest: fetchRequest, managedObjectContext: managedObjectContext, sectionNameKeyPath: nil, cacheName: nil)
                    
                    do {
                        try fetchResultController.performFetch()
                        let returnedItems = fetchResultController.fetchedObjects as! [Images]
                        print("Number of total Images: \(returnedItems.count)")
                        
                        if returnedItems.count == 0 {
                            print("Warning: Unable to retrieve from memory")
                        } else {
                            
                            let backgroundImage = UIImage(data: returnedItems[0].backgroundImage)
                            self.homeThumbnail.setImage(backgroundImage, forState: .Normal)
                            self.homeThumbnail.imageView!.layer.minificationFilter = kCAFilterTrilinear
                            self.homeThumbnail.imageView?.contentMode = .ScaleAspectFit
                            
                            let useLockImage = defaults.boolForKey("useLockImage")
                            if useLockImage == true {
                                let lockImage = UIImage(data: returnedItems[0].lockScreenImage)
                                self.lockThumbnail.setImage(lockImage, forState: .Normal)
                                self.lockThumbnail.imageView!.layer.minificationFilter = kCAFilterTrilinear
                                self.lockThumbnail.imageView?.contentMode = .ScaleAspectFit
                            } else {
                                self.lockThumbnail.setTitle("Not Set", forState: .Normal)
                                self.lockThumbnail.setTitleColor(UIColor.whiteColor(), forState: .Normal)
                            }
                            
                            
                        }
                        
                    } catch  {
                        print("Failed to retrieve anything from core data")
                        return
                    }
                }
                
            } else {
                self.homeThumbnail.setTitle("Not Set", forState: .Normal)
                self.homeThumbnail.setTitleColor(UIColor.whiteColor(), forState: .Normal)
                
                let useLockImage = defaults.boolForKey("useLockImage")
                if useLockImage == false {
                    self.lockThumbnail.setTitle("Not Set", forState: .Normal)
                    self.lockThumbnail.setTitleColor(UIColor.whiteColor(), forState: .Normal)
                }
            }
        }
        
        

        
    }
    
    override func viewWillAppear(animated: Bool) {
        if let defaults = NSUserDefaults(suiteName: "group.prophesy"){
            if let textFieldText = defaults.objectForKey("recordingSuffix") as? String! {
                self.textField.text = textFieldText
            } else {
                self.textField.text = "Prophecy"
            }
            
            
            let dayText = defaults.integerForKey("recordingPrefix")
            print("daytext is \(dayText)")
            if dayText == 0 {
               self.dayTextField.text = String("1")
                defaults.setInteger(1, forKey: "recordingPrefix")
            } else {
                self.dayTextField.text = String(dayText)
            }
            
        }
        
        
        self.nameOutput.textAlignment = NSTextAlignment.Center
        self.nameOutput.numberOfLines = 0
        
        self.nameOutput.text = "Recording Name Will Be:\n" + weekday() + " " + self.textField.text!
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    override func tableView(tableView: UITableView, didSelectRowAtIndexPath indexPath: NSIndexPath) {
        tableView.deselectRowAtIndexPath(indexPath, animated: true)
    }
    
    @IBAction func backgroundPicker(sender: AnyObject!) {
        //Let's give the user the option to set a background or set none (set none allows the user to unselect a background previously chosen)
        //We will provide a menu of two choices and a cancel button when the background button is selected
        
        print("Tag is \(sender.tag)")
        if sender.tag == 1 {
            self.tag = 1
            
        }
        
        if sender.tag == 2 {
            self.tag = 2
        }
        
        //let alertController = UIAlertController(title: nil , message: NSLocalizedString("Set background to:", comment: "Set background to:"), preferredStyle: UIAlertControllerStyle.ActionSheet)
        
        
        //let imagePickerAction = UIAlertAction(title: NSLocalizedString("Photo", comment: "Photo"), style: UIAlertActionStyle.Default, handler: { (action:UIAlertAction) -> Void in
            if UIImagePickerController.isSourceTypeAvailable(.PhotoLibrary) {
                let imagePicker = UIImagePickerController()
                //imagePicker.allowsEditing = true
                imagePicker.sourceType = .PhotoLibrary
                imagePicker.delegate = self
                //Flurry.logEvent("Background_Custom")
                
                
                self.presentViewController(imagePicker, animated: true, completion: nil)
            }
        //})
        
        //This action will deselect the image previously chosen and set background back to default setting
        /*let noneAction = UIAlertAction(title: NSLocalizedString("Black Screen", comment: "Black Screen"), style: UIAlertActionStyle.Default, handler: { (action:UIAlertAction) -> Void in
            //self.imageView.image = UIImage(named: "camera-1.png")
            //self.imagePicked = false
            //self.delegate!.setBackground(self, backgroundImage: nil)
            //Flurry.logEvent("Background_None")
            
            if self.tag == 1 {
                if let defaults = NSUserDefaults(suiteName: "group.prophesy"){
                    defaults.setBool(false, forKey: "useBackgroundImage")
                    defaults.synchronize()
                }
                self.delegate!.setBackground(nil)
            }
            
            if self.tag == 2 {
                if let defaults = NSUserDefaults(suiteName: "group.prophesy"){
                    defaults.setBool(false, forKey: "useLockImage")
                    defaults.synchronize()
                }
                //self.delegate!.setLockImage(nil)
            }
            
            
            
        })*/
        
        //The cancel Action will handle dismissing the UIAlert
        /*let cancelAction = UIAlertAction(title: NSLocalizedString("Cancel", comment: "Cancel"), style: UIAlertActionStyle.Cancel, handler: { (action:UIAlertAction) -> Void in
            //Flurry.logEvent("Background_Cancel")
        })*/
        
        //alertController.addAction(imagePickerAction)
        //alertController.addAction(noneAction)
        //alertController.addAction(cancelAction)
        
        //self.presentViewController(alertController, animated: true , completion: nil)
    }
    
    func imagePickerController(picker: UIImagePickerController, didFinishPickingImage image: UIImage!, editingInfo: [NSObject : AnyObject]!) {
        //imageView.image = image
        if image != nil {
            bgImage = image
        } else {
            print("image picked is nil")
        }
        
        imagePicked = true
        print("description of photo \(bgImage)")
        
        if self.tag == 1 {
            
            //set thumbnail
            self.homeThumbnail.imageView!.layer.minificationFilter = kCAFilterTrilinear
            self.homeThumbnail.imageView?.contentMode = .ScaleAspectFit
            self.homeThumbnail.setImage(image, forState: UIControlState.Normal)
            
           
            let imageData = UIImageJPEGRepresentation(image, 1)
            let relativePath = "image_\(NSDate.timeIntervalSinceReferenceDate()).jpg"
            let sharedPath = NSFileManager.defaultManager()
            let appGroupName = "group.prophesy" //make this a constant
            if let groupContainerURL = sharedPath.containerURLForSecurityApplicationGroupIdentifier(appGroupName) {
                
                let directoryPath = groupContainerURL.URLByAppendingPathComponent(relativePath)
                imageData?.writeToURL(directoryPath, atomically: true)
                print("Image written to \(directoryPath)")
                
                // Save  image to core data
                let fetchRequest = NSFetchRequest(entityName: "Images")
                //fetchRequest.predicate = NSPredicate(format: "name contains[c] %@", originalRecordingName)
                let sortDescriptor = NSSortDescriptor(key: "backgroundImage", ascending: true)
                fetchRequest.sortDescriptors = [sortDescriptor]
                
                if let managedObjectContext = (UIApplication.sharedApplication().delegate as! AppDelegate).managedObjectContext {
                    let fetchResultController = NSFetchedResultsController(fetchRequest: fetchRequest, managedObjectContext: managedObjectContext, sectionNameKeyPath: nil, cacheName: nil)
                    
                    do {
                        try fetchResultController.performFetch()
                        let returnedItems = fetchResultController.fetchedObjects as! [Images]
                        print("Number of total Images: \(returnedItems.count)")
                        
                        if returnedItems.count == 0 {
                            print("Warning: Unable to retrieve from memory")
                            let newImageObject = NSEntityDescription.insertNewObjectForEntityForName("Images", inManagedObjectContext: managedObjectContext) as! Images
                            newImageObject.backgroundImage = imageData
                            
                            do {
                                try managedObjectContext.save()
                            } catch {
                                fatalError("Failure to save context: \(error)")
                                
                            }
                            
                        } else {
                            
                            returnedItems[0].backgroundImage = imageData
                            
                            do {
                                try managedObjectContext.save()
                            } catch {
                                fatalError("Failure to save context: \(error)")
                                
                            }
                            
                        }
                        
                    } catch  {
                        print("Failed to retrieve anything from core data")
                        return
                    }
                }
                
                /*if let managedObjectContext = (UIApplication.sharedApplication().delegate as! AppDelegate).managedObjectContext {
                    let newImageObject = NSEntityDescription.insertNewObjectForEntityForName("Images", inManagedObjectContext: managedObjectContext) as! Images
                    newImageObject.backgroundImage = imageData
                    
                    do {
                        try managedObjectContext.save()
                    } catch {
                        fatalError("Failure to save context: \(error)")
                    }
                    
                }*/
                
                if let defaults = NSUserDefaults(suiteName: "group.prophesy"){
                    defaults.setBool(true, forKey: "useBackgroundImage")
                    //defaults.setObject(directoryPath, forKey: "backgroundImage") stopped working in swift 2.0
                    defaults.synchronize()
                    delegate!.setBackground(image)
                }
                
                
                
            } else {
                print("Group container failed to load")
            }
        }
        
        if self.tag == 2 {
            //delegate!.setLockImage(image)
            
            //set thumbnail
            self.lockThumbnail.imageView!.layer.minificationFilter = kCAFilterTrilinear
            self.lockThumbnail.imageView?.contentMode = .ScaleAspectFit
            self.lockThumbnail.setImage(image, forState: UIControlState.Normal)
            
            
            let imageData = UIImageJPEGRepresentation(image, 1)
            let relativePath = "image_\(NSDate.timeIntervalSinceReferenceDate()).jpg"
            let sharedPath = NSFileManager.defaultManager()
            let appGroupName = "group.prophesy" //make this a constant
            if let groupContainerURL = sharedPath.containerURLForSecurityApplicationGroupIdentifier(appGroupName) {
                /*let directoryPath = groupContainerURL.path
                let path = directoryPath!.stringByAppendingPathComponent(relativePath)
                imageData.writeToFile(path, atomically: true)*/
                
                let directoryPath = groupContainerURL.URLByAppendingPathComponent(relativePath)
                imageData?.writeToURL(directoryPath, atomically: true)
                print("Image written to \(directoryPath)")
                
                // Save new image to core data
                let fetchRequest = NSFetchRequest(entityName: "Images")
                //fetchRequest.predicate = NSPredicate(format: "name contains[c] %@", originalRecordingName)
                let sortDescriptor = NSSortDescriptor(key: "lockScreenImage", ascending: true)
                fetchRequest.sortDescriptors = [sortDescriptor]
                
                if let managedObjectContext = (UIApplication.sharedApplication().delegate as! AppDelegate).managedObjectContext {
                    let fetchResultController = NSFetchedResultsController(fetchRequest: fetchRequest, managedObjectContext: managedObjectContext, sectionNameKeyPath: nil, cacheName: nil)
                    
                    do {
                        try fetchResultController.performFetch()
                        let returnedItems = fetchResultController.fetchedObjects as! [Images]
                        print("Number of total Images: \(returnedItems.count)")
                        
                        if returnedItems.count == 0 {
                            print("Warning: Unable to retrieve from memory")
                            let newImageObject = NSEntityDescription.insertNewObjectForEntityForName("Images", inManagedObjectContext: managedObjectContext) as! Images
                            newImageObject.lockScreenImage = imageData
                            
                            do {
                                try managedObjectContext.save()
                            } catch {
                                fatalError("Failure to save context: \(error)")
                            }
                        } else {
                            
                            returnedItems[0].lockScreenImage = imageData
                            
                            do {
                                try managedObjectContext.save()
                            } catch {
                                fatalError("Failure to save context: \(error)")
                            }
                            
                        }
                        
                    } catch  {
                        print("Failed to retrieve anything from core data")
                        return
                    }
                }
                
                /*if let managedObjectContext = (UIApplication.sharedApplication().delegate as! AppDelegate).managedObjectContext {
                    let newImageObject = NSEntityDescription.insertNewObjectForEntityForName("Images", inManagedObjectContext: managedObjectContext) as! Images
                    newImageObject.lockScreenImage = imageData
                    
                    do {
                        try managedObjectContext.save()
                    } catch {
                        fatalError("Failure to save context: \(error)")
                    }
                    
                }*/
                
                if let defaults = NSUserDefaults(suiteName: "group.prophesy"){
                    defaults.setBool(true, forKey: "useLockImage")
                    //defaults.setObject(directoryPath, forKey: "lockImage")
                    defaults.synchronize()
                }
                
            }
        }
        

        
        
        dismissViewControllerAnimated(true , completion: nil)
        
    }
    
    func textFieldDidBeginEditing(textField: UITextField) {
        //This function runs when editing of the textField has begun
        print("Editing has begun")
        
        if textField.tag == 1 {
            print("Recording Suffix Text Field Selected")
            textField.selectAll(self)
            textField.autocapitalizationType = UITextAutocapitalizationType.Words
            
            //Setting up tap recognizer for when keyboard is dismissed without hitting return
            //Looks for single or multiple taps.
            self.currentTextField = textField
            self.tap = UITapGestureRecognizer(target: self, action: "DismissKeyboard")
            tableView.addGestureRecognizer(tap)
        }
        
        if textField.tag == 2 {
            print("Day Chooser Selected")
            
            
            
        }
        
        
        
        
    }
    
    func textFieldShouldReturn(textField: UITextField) -> Bool {
        //This function handles what happens when the return button is pressed on the keyboard
        //This function will resign the keyboard, then save the edited text field into core data
        
        print("text field should return")
        tableView.beginUpdates()
        tableView.removeGestureRecognizer(self.tap)
        textField.resignFirstResponder()
        
        if let defaults = NSUserDefaults(suiteName: "group.prophesy"){
            var textFieldText = self.textField.text
            if textFieldText == "" {
                textFieldText = "Premonition"
            }
            
            print("Text will be \(textFieldText)")
            defaults.setObject(textFieldText, forKey: "recordingSuffix")
            defaults.synchronize()
        }
        
        //This should refresh the output label
        self.viewWillAppear(false)
        
        return true
    }
    
    func DismissKeyboard(){
        //Causes the view (or one of its embedded text fields) to resign the first responder status.
        let success = textFieldShouldReturn(self.currentTextField)
        if success == true {
            print("Keyboard Dismissed")
        }
        
        tableView.endEditing(true)
        tableView.removeGestureRecognizer(self.tap)
    }
    
    func textFieldShouldBeginEditing(textField: UITextField) -> Bool {
        print("should begin editing")
        let pointInTable:CGPoint = textField.superview!.convertPoint(textField.frame.origin, toView: self.tableView)
        var contentOffset:CGPoint = self.tableView.contentOffset
        contentOffset.y  = pointInTable.y - 200
        if let accessoryView = textField.inputAccessoryView {
            contentOffset.y -= accessoryView.frame.size.height
        }
        self.tableView.contentOffset = contentOffset
        
        return true
    }
    
    func numberOfComponentsInPickerView(pickerView: UIPickerView) -> Int {
        return 1
    }
    
    func pickerView(pickerView: UIPickerView, numberOfRowsInComponent component: Int) -> Int {
        return pickerData.count
    }
    
    func pickerView(pickerView: UIPickerView, didSelectRow row: Int, inComponent component: Int) {
        if let defaults = NSUserDefaults(suiteName: "group.prophesy"){
            let dayChosen = pickerData[row]
            print("Day chosen is \(dayChosen)")
            defaults.setInteger(dayChosen, forKey: "recordingPrefix")
            defaults.synchronize()
        }
    }
    
    /*func pickerView(pickerView: UIPickerView, titleForRow row: Int, forComponent component: Int) -> String! {
        return String(pickerData[row])
    }*/
    
    func addDoneButtonOnKeyboard()
    {
        let doneToolbar: UIToolbar = UIToolbar(frame: CGRectMake(0, 0, 320, 50))
        doneToolbar.barStyle = UIBarStyle.Default
        
        let flexSpace = UIBarButtonItem(barButtonSystemItem: UIBarButtonSystemItem.FlexibleSpace, target: nil, action: nil)
        let done: UIBarButtonItem = UIBarButtonItem(title: "Done", style: UIBarButtonItemStyle.Done, target: self, action: Selector("doneButtonAction"))
        
        let items = [flexSpace, done]
        
        doneToolbar.items = items
        doneToolbar.sizeToFit()
        
        self.dayTextField.inputAccessoryView = doneToolbar
        
    }
    
    func doneButtonAction()
    {
        self.dayTextField.resignFirstResponder()
        if let defaults = NSUserDefaults(suiteName: "group.prophesy"){
            if self.dayTextField.text == "" {
                self.dayTextField.text = "2"
            }
            
            let dayText = self.dayTextField.text
            
            
            
            print("Text will be \(dayText)")
            defaults.setInteger(Int(dayText!)!, forKey: "recordingPrefix")
            defaults.synchronize()
        }
        
        //This should refresh the output label
        self.viewWillAppear(false)
    }
    
    @IBAction func subtleModeToggle(){
        if let defaults = NSUserDefaults(suiteName: "group.prophesy"){
            if subtleSwitch.on == true {
                //was off
                defaults.setBool(false, forKey: "subtleMode")
                defaults.synchronize()
                delegate!.refresh()
            } else {
                //was on
                defaults.setBool(true, forKey: "subtleMode")
                defaults.synchronize()
                delegate!.refresh()
            }
            
        }
    }
    
    func weekday() -> String!{
        //set the date of the recording to a value in the past determined in the settings
        var returnString : String!
        var dayChosen : Int!
        if let defaults = NSUserDefaults(suiteName: "group.prophesy"){
            dayChosen = defaults.integerForKey("recordingPrefix")
            
        } else {
            dayChosen = 2
        }
        let date = NSDate()
        
        let components = NSDateComponents()
        components.setValue(-dayChosen, forComponent: NSCalendarUnit.Day)
        let olderDate = NSCalendar.currentCalendar().dateByAddingComponents(components, toDate: date, options: NSCalendarOptions(rawValue: 0))
        let myCalendar = NSCalendar(calendarIdentifier: NSCalendarIdentifierGregorian)
        let myComponents = myCalendar!.components(NSCalendarUnit.Weekday, fromDate: olderDate!)
        
        
        let weekDay = myComponents.weekday
        
        switch weekDay {
        case 1:  returnString = "Sunday"
        case 2:  returnString = "Monday"
        case 3:  returnString = "Tuesday"
        case 4:  returnString = "Wednesday"
        case 5:  returnString = "Thursday"
        case 6:  returnString = "Friday"
        case 7:  returnString = "Saturday"
            
        default: break
            
        }
        return returnString
    }
    
    



}
