//
//  EnhancedRecordingMeter.swift
//  SleightRecord
//
//  Created by Lee Lerner on 9/2/15.
//  Copyright (c) 2015 Lee Lerner. All rights reserved.
//

import UIKit

@IBDesignable class EnhancedRecordingMeter: UIView {
    
    
    @IBInspectable var fillColor: UIColor = UIColor.blackColor()
    @IBInspectable var lineColor: UIColor = UIColor.whiteColor()
    
    @IBInspectable var counter: Int = 0 {
        didSet {
            setNeedsDisplay()
        }
    }
    
    //5 seconds divided by bounds.width/2
    
    @IBInspectable var number : Int = 85 {
        didSet {
            setNeedsDisplay()
        }
    }
    
    var offset : CGFloat = 0
    var timeStampCounter : Int = 5
    var width : CGFloat = 0
    
    var timeStamps = ["00:00", "00:01", "00:02", "00:03", "00:04", "00:05"]
    

    var levelArray = [Float](count: 85, repeatedValue: 0.0)
    
    override func drawRect(rect: CGRect) {
        //print("Rect drawn for enhanced recording meter")
        //self.width = self.frame.width

        
        //let viewWidth = bounds.width/2
        
        
        let path = UIBezierPath(roundedRect: rect, cornerRadius: 0)
        fillColor.setFill()
        path.fill()
        
        //bottomCirclePath.stroke()
        
        
        //set up width and height variables

        var height : CGFloat!
        let width : CGFloat = 1.0
        
        var xoffset : Int!
        if self.frame.width <= 340{
            xoffset = 12
        } else {
            xoffset = 1
        }

        
        for index in 0...(number - xoffset) {
            let meterPath = UIBezierPath()

            
            let minDB = -50.0 as Float
            let minAmp = powf(10.0, minDB * 0.05)
            let ampRange = 1.0 - minAmp
            let invAmpRange = 1.0 / ampRange
            
            
            let amp = (pow(10.0, 0.05 * levelArray[index])) as Float
            height = 100*CGFloat((amp - minAmp) * invAmpRange)
            
            
            if height < 1.0 {
                height = 1.0
            }
            
            if levelArray[index] == 0.0 {
                height = 0
            }
            
            
            //print("Height is \(height)")
            
            //set the path's line width to the height of the stroke
            meterPath.lineWidth = width
            
            //move the initial point of the path to start the vertical stroke
            //meterPath.moveToPoint(CGPoint(
            //    x:(bounds.width/CGFloat(number)) + (CGFloat(index) * bounds.width/CGFloat(number)),
            //    y:bounds.height/2 + 12 + height))
            
            meterPath.moveToPoint(CGPoint(
                x:(10) + 2*CGFloat(index),
                y:bounds.height/2 + 12 + height))
            
            //add a point to the path at the end of the stroke
            meterPath.addLineToPoint(CGPoint(
                x:(10) + 2*CGFloat(index),
                y:bounds.height/2 + 12 - height))
            
            
            //set the stroke color
            //UIColor.whiteColor().setStroke()
            lineColor.setStroke()
            
            //draw the stroke
            meterPath.stroke()
            
            
            
            
        }
        
        self.createDashmark()
        
        self.drawBorders()
        

    }
    

    
    func drawBorders(){
        //print("draw borders")
        let topPath = UIBezierPath()
        let middlePath = UIBezierPath()
        let bottomPath = UIBezierPath()
        let lineHeight :CGFloat = 1.0
        
        //set paths line width
        topPath.lineWidth = lineHeight
        middlePath.lineWidth = lineHeight
        bottomPath.lineWidth = lineHeight
        
        //move the initial point of the path
        //to the start of the horizontal stroke
        topPath.moveToPoint(CGPoint(x: 0, y: 32))
        middlePath.moveToPoint(CGPoint(x: 0, y: bounds.height/2 + 12))
        bottomPath.moveToPoint(CGPoint(x: 0, y: bounds.height - 10))
        
        //add a point to the path at the end of the stroke
        topPath.addLineToPoint(CGPoint(x: bounds.width, y: 32))
        middlePath.addLineToPoint(CGPoint(x: bounds.width, y: bounds.height/2 + 12))
        bottomPath.addLineToPoint(CGPoint(x: bounds.width, y: bounds.height - 10))
        
        //Set the stroke color
        UIColor.darkGrayColor().setStroke()
        
        //draw the stroke
        topPath.stroke()
        middlePath.stroke()
        bottomPath.stroke()
    }
    
    func createDashmark(){
        let dashMark = UIBezierPath()
        let lineWidth : CGFloat = 1.0
        dashMark.lineWidth = lineWidth
        
        let distance : CGFloat = self.frame.width / 24
        print("frame width is \(self.frame.width)")
        
        if self.counter > self.number {
            self.offset = self.offset + 1
            
            //print("offset is \(self.offset)")
        }
        
        for index in 0...23 {
            var currentX = (10 + CGFloat(index) * distance - (2 * self.offset)) % self.frame.width
            //print("self.offset is \(self.offset)")
            if currentX < 0 {
                currentX = self.frame.width + currentX
                
            }
            
            
            dashMark.moveToPoint(CGPoint(x: currentX , y: 32))
            
            if (index % 4 == 1) {
                dashMark.addLineToPoint(CGPoint(x: currentX, y: 12))
                
            } else if (index % 4 == 3){
                /*if (index == 7) || (index == 11) || (index == 19) || (index == 23){
                    print("index is \(index), currentX: \(floor(currentX))")
                }*/
                if (floor(currentX) == (self.frame.width - 1)) || (floor(currentX) == (self.frame.width - 2)) {
                    print("index is \(index), currentX: \(currentX), timestamp[\((index - 3)/4)]")
                    timeStampCounter++
                    timeStamps[(index - 3)/4] = stringToTimeStamp(timeStampCounter, offset: 0)
                    
                }
                var xoffset : CGFloat!
                if self.frame.width <= 340 {
                    xoffset = 20
                } else {
                    xoffset = 29
                }
                let textRect = CGRectMake(currentX - xoffset, 10, 42, 21)
                let textStyle = NSMutableParagraphStyle.defaultParagraphStyle().mutableCopy()
                let font = UIFont.systemFontOfSize(12)
                let textFontAttributes = [
                    NSFontAttributeName: font,
                    NSForegroundColorAttributeName: UIColor.whiteColor(),
                    NSParagraphStyleAttributeName: textStyle
                ]
                
                let text : NSString = timeStamps[(index - 3)/4]
                //let text : NSString = stringToTimeStamp(timeStampCounter, offset: 0)
                //increment for the first 6 that are shown immediately ("00:00" - "00:05")
                
                
                text.drawInRect(textRect, withAttributes: textFontAttributes)
                dashMark.addLineToPoint(CGPoint(x: currentX, y: 29))
                
            } else {
                dashMark.addLineToPoint(CGPoint(x: currentX, y: 29))
            }
            
            
            
            dashMark.closePath()
            UIColor.darkGrayColor().setStroke()
            dashMark.stroke()
        }
        
        
        
        
        
    }
    
    func stringToTimeStamp(time : Int!, offset : Int!) -> String {
        let seconds = (time + offset) % 60
        let minutes = ((time + offset) / 60)
        var returnSeconds = ""
        var returnMinutes = ""
        
        if seconds < 10 {
            returnSeconds = ":0" + String(seconds)
        } else {
            returnSeconds = ":" + String(seconds)
        }
        
        if minutes < 10 {
            returnMinutes = "0" + String(minutes)
        } else {
            returnMinutes =  String(minutes)
        }
        
        return (returnMinutes + returnSeconds)
        
        
    }
    
    
    
    
    
}
