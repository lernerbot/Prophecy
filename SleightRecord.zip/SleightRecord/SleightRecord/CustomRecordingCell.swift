//
//  CustomRecordingCell.swift
//  SleightRecord
//
//  Created by Lee Lerner on 7/30/15.
//  Copyright (c) 2015 Lee Lerner. All rights reserved.
//

import UIKit

class CustomRecordingCell: UITableViewCell {
    
    
    @IBOutlet weak var recordButton:UIButton!
    @IBOutlet weak var speakerToggleButton:UIButton!
    @IBOutlet weak var editButton : UIButton!
    @IBOutlet weak var playButton:UIButton!
    @IBOutlet weak var doneButton : UIButton!
    
    
    
    
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }
    
    override func setSelected(selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)
        
        // Configure the view for the selected state
    }
    
}